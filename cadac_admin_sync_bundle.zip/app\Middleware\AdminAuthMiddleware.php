<?php

class AdminAuthMiddleware
{
    private mysqli $db;

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }

    /**
     * Extract Bearer token from incoming request headers
     */
    public function getBearerToken(): ?string
    {
        $authHeader = $_SERVER["HTTP_AUTHORIZATION"] 
            ?? $_SERVER["REDIRECT_HTTP_AUTHORIZATION"] 
            ?? "";

        if (!$authHeader && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            $authHeader = $headers['Authorization'] 
                ?? $headers['authorization'] 
                ?? "";
        }

        if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
            return $matches[1];
        }

        return null;
    }

    /**
     * Authenticate the current administrator via Session or Bearer Token.
     * Terminates with 401 Unauthorized if not authenticated.
     */
    public function authenticate(): array
    {
        $admin = null;
        $token = $this->getBearerToken();

        // 1. Check PHP Session
        if (isset($_SESSION["admin"]) && is_array($_SESSION["admin"]) && !empty($_SESSION["admin"]["id"])) {
            $admin = $_SESSION["admin"];
        }

        // 2. Check Bearer Token against session or database
        if ($token) {
            if (isset($_SESSION["admin_token"]) && hash_equals($_SESSION["admin_token"], $token) && !empty($_SESSION["admin"])) {
                $admin = $_SESSION["admin"];
            } else {
                // Check database for active token or fallback lookup
                try {
                    $tokenEsc = $this->db->real_escape_string($token);
                    $res = $this->db->query("
                        SELECT id, name, email, role, status 
                        FROM admin_users 
                        WHERE auth_token = '$tokenEsc' 
                        LIMIT 1
                    ");
                    if ($res && $res->num_rows > 0) {
                        $row = $res->fetch_assoc();
                        $admin = [
                            "id"    => (int)$row["id"],
                            "name"  => $row["name"],
                            "email" => $row["email"],
                            "role"  => $row["role"],
                            "status"=> $row["status"]
                        ];
                    }
                } catch (Throwable $e) {
                    // Silently continue if column doesn't exist
                }
            }
        }

        // If still unauthenticated, reject immediately
        if (!$admin) {
            http_response_code(401);
            echo json_encode([
                "status"  => false,
                "success" => false,
                "error"   => "UNAUTHORIZED",
                "message" => "Authentication required. Please sign in to access administration services."
            ]);
            exit;
        }

        // Check account active status
        if (isset($admin["status"]) && (int)$admin["status"] === 0) {
            http_response_code(403);
            echo json_encode([
                "status"  => false,
                "success" => false,
                "error"   => "ACCOUNT_INACTIVE",
                "message" => "Your administrator account has been deactivated."
            ]);
            exit;
        }

        // Standardize Super Admin role
        $email = strtolower(trim($admin["email"] ?? ""));
        $role = strtolower(trim($admin["role"] ?? ""));
        if ($role === "super_admin" || $email === "admin@broadbeachlearning.com") {
            $admin["role"] = "super_admin";
        }

        return $admin;
    }

    /**
     * Authorize authenticated administrator against allowed roles for a module.
     * Super Admin has unconditional authorization to ALL modules and actions.
     * Non-authorized roles receive 403 Forbidden.
     */
    public function authorize(array $allowedRoles = [], string $moduleName = ""): array
    {
        $admin = $this->authenticate();

        // 1. Super Admin is authoritatively permitted across all modules
        if ($admin["role"] === "super_admin") {
            return $admin;
        }

        // If no role restrictions were specified, any authenticated admin is permitted
        if (empty($allowedRoles)) {
            return $admin;
        }

        // 2. Role normalization & alias mapping
        $currentRole = strtolower(trim($admin["role"]));
        $normalizedAllowed = array_map(fn($r) => strtolower(trim($r)), $allowedRoles);

        // Aliases
        $hasAccess = in_array($currentRole, $normalizedAllowed, true);

        if (!$hasAccess && ($currentRole === "admin" || $currentRole === "cert_manager")) {
            if (in_array("admin", $normalizedAllowed, true) || in_array("cert_manager", $normalizedAllowed, true)) {
                $hasAccess = true;
            }
        }

        if (!$hasAccess && ($currentRole === "support" || $currentRole === "support_agent" || $currentRole === "staff")) {
            if (in_array("support", $normalizedAllowed, true) || in_array("support_agent", $normalizedAllowed, true) || in_array("staff", $normalizedAllowed, true)) {
                $hasAccess = true;
            }
        }

        if (!$hasAccess) {
            http_response_code(403);
            echo json_encode([
                "status"   => false,
                "success"  => false,
                "error"    => "FORBIDDEN_ROLE",
                "message"  => "Access restricted: Insufficient administrative privileges for module " . ($moduleName ? "'$moduleName'" : "") . ".",
                "current_role" => $currentRole,
                "required_roles" => $allowedRoles
            ]);
            exit;
        }

        return $admin;
    }

    /**
     * Handle Admin password change/rotation
     * POST /api/admin/change-password
     */
    public function handlePasswordChange(): void
    {
        $actor = $this->authenticate();
        $input = json_decode(file_get_contents("php://input"), true) ?? [];

        $currentPassword = $input["current_password"] ?? "";
        $newPassword = $input["new_password"] ?? "";
        $targetUserId = isset($input["user_id"]) ? (int)$input["user_id"] : (int)$actor["id"];

        if (strlen($newPassword) < 8) {
            http_response_code(422);
            echo json_encode([
                "status" => false,
                "success" => false,
                "message" => "New password must be at least 8 characters in length."
            ]);
            exit;
        }

        // If updating own password, verify current password
        if ($targetUserId === (int)$actor["id"]) {
            if (empty($currentPassword)) {
                http_response_code(422);
                echo json_encode([
                    "status" => false,
                    "success" => false,
                    "message" => "Current password is required."
                ]);
                exit;
            }

            $stmt = $this->db->prepare("SELECT password FROM admin_users WHERE id = ? LIMIT 1");
            if ($stmt) {
                $stmt->bind_param("i", $targetUserId);
                $stmt->execute();
                $res = $stmt->get_result();
                $row = $res ? $res->fetch_assoc() : null;
                $stmt->close();

                if (!$row || !password_verify($currentPassword, $row["password"])) {
                    http_response_code(401);
                    echo json_encode([
                        "status" => false,
                        "success" => false,
                        "message" => "Current password is incorrect."
                    ]);
                    exit;
                }
            }
        } else {
            // Only Super Admin can change another user's password
            if ($actor["role"] !== "super_admin") {
                http_response_code(403);
                echo json_encode([
                    "status" => false,
                    "success" => false,
                    "message" => "Only Super Administrators can reset other administrators' passwords."
                ]);
                exit;
            }
        }

        $hash = password_hash($newPassword, PASSWORD_BCRYPT, ["cost" => 12]);
        $updateStmt = $this->db->prepare("
            UPDATE admin_users 
            SET password = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        if ($updateStmt) {
            $updateStmt->bind_param("si", $hash, $targetUserId);
            $updateStmt->execute();
            $updateStmt->close();

            // Log administrative activity
            $logStmt = $this->db->prepare("
                INSERT INTO admin_audit_logs (actor_name, actor_email, actor_role, action_category, action, target_type, target_id, details, created_at)
                VALUES (?, ?, ?, 'SECURITY', 'PASSWORD_CHANGED', 'admin_user', ?, 'Administrator password updated successfully.', NOW())
            ");
            if ($logStmt) {
                $targetIdStr = (string)$targetUserId;
                $logStmt->bind_param("ssss", $actor["name"], $actor["email"], $actor["role"], $targetIdStr);
                $logStmt->execute();
                $logStmt->close();
            }

            echo json_encode([
                "status" => true,
                "success" => true,
                "message" => "Password updated successfully."
            ]);
            exit;
        }

        http_response_code(500);
        echo json_encode([
            "status" => false,
            "success" => false,
            "message" => "Unable to update password."
        ]);
        exit;
    }
}

