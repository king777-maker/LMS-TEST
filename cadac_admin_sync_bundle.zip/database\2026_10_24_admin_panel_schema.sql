-- ============================================================================
-- BROADBEACH ACADEMY — ADMIN PANEL DATABASE SCHEMA MIGRATION
-- Modules:
--   1. Online Cert Master
--   2. Manual Cert Master
--   3. Ticket Master
--   4. Trash Bin
--   5. Admin Access & RBAC
--   6. Immutable Audit Trail
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- 1. ADMIN USERS & RBAC
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(191) NOT NULL,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('super_admin', 'cert_manager', 'support_agent', 'read_only') NOT NULL DEFAULT 'support_agent',
  `status` ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  `auth_token` VARCHAR(255) NULL,
  `token_expires_at` DATETIME NULL,
  `last_login` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_admin_email` (`email`),
  INDEX `idx_admin_role` (`role`),
  INDEX `idx_admin_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 1b. EXTEND EXISTING ADMIN USERS (TOKEN SUPPORT)
ALTER TABLE `admin_users`
  ADD COLUMN IF NOT EXISTS `auth_token` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `token_expires_at` DATETIME NULL;

-- 2. EXTEND CERTIFICATES (ONLINE CERT MASTER)
-- ----------------------------------------------------------------------------
-- Ensure status, revocation, and reissuance fields exist
ALTER TABLE `certificates`
  ADD COLUMN IF NOT EXISTS `status` ENUM('valid', 'revoked', 'deleted') NOT NULL DEFAULT 'valid',
  ADD COLUMN IF NOT EXISTS `verification_status` VARCHAR(50) NOT NULL DEFAULT 'Valid',
  ADD COLUMN IF NOT EXISTS `revoked_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `revoked_by` VARCHAR(191) NULL,
  ADD COLUMN IF NOT EXISTS `revocation_reason` TEXT NULL,
  ADD COLUMN IF NOT EXISTS `reissued_at` DATETIME NULL,
  ADD INDEX IF NOT EXISTS `idx_cert_status` (`status`),
  ADD INDEX IF NOT EXISTS `idx_cert_num` (`certificate_number`);

-- ----------------------------------------------------------------------------
-- 3. MANUAL CERTIFICATES (MANUAL CERT MASTER)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `manual_certificates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `certificate_number` VARCHAR(64) NOT NULL UNIQUE,
  `student_name` VARCHAR(255) NOT NULL,
  `candidate_email` VARCHAR(255) NULL,
  `course_name` VARCHAR(255) NOT NULL,
  `issue_date` DATE NOT NULL,
  `completion_date` DATE NULL,
  `issuing_organization` VARCHAR(255) NOT NULL DEFAULT 'Broadbeach Academy',
  `signatory` VARCHAR(255) NOT NULL DEFAULT 'Academic Director',
  `training_type` VARCHAR(100) NOT NULL DEFAULT 'Offline / Manual',
  `additional_reference` VARCHAR(255) NULL,
  `status` ENUM('valid', 'revoked', 'deleted') NOT NULL DEFAULT 'valid',
  `verification_status` VARCHAR(50) NOT NULL DEFAULT 'Valid',
  `revocation_reason` TEXT NULL,
  `revoked_at` DATETIME NULL,
  `revoked_by` VARCHAR(191) NULL,
  `created_by` VARCHAR(191) NOT NULL,
  `correction_history` JSON NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_mcert_num` (`certificate_number`),
  INDEX `idx_mcert_student` (`student_name`),
  INDEX `idx_mcert_course` (`course_name`),
  INDEX `idx_mcert_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. SUPPORT TICKETS (TICKET MASTER)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `subject` VARCHAR(255) NOT NULL,
  `requester_name` VARCHAR(255) NOT NULL,
  `requester_email` VARCHAR(191) NOT NULL,
  `course_name` VARCHAR(255) NULL,
  `certificate_id` VARCHAR(64) NULL,
  `category` VARCHAR(100) NOT NULL,
  `priority` ENUM('Normal', 'High', 'Urgent') NOT NULL DEFAULT 'Normal',
  `status` ENUM('New', 'Open', 'In Progress', 'Waiting for User', 'Resolved', 'Closed') NOT NULL DEFAULT 'New',
  `assigned_admin` VARCHAR(191) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_ticket_status` (`status`),
  INDEX `idx_ticket_priority` (`priority`),
  INDEX `idx_ticket_category` (`category`),
  INDEX `idx_ticket_email` (`requester_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. TICKET MESSAGES & INTERNAL NOTES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ticket_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ticket_id` VARCHAR(64) NOT NULL,
  `sender_type` ENUM('requester', 'admin', 'system') NOT NULL,
  `sender_name` VARCHAR(191) NOT NULL,
  `sender_email` VARCHAR(191) NOT NULL,
  `message` TEXT NOT NULL,
  `is_internal` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_msg_ticket` (`ticket_id`),
  INDEX `idx_msg_internal` (`is_internal`),
  CONSTRAINT `fk_ticket_msg` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. TRASH RECORDS (TRASH BIN RECOVERABLE STORAGE)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `trash_records` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `record_id` VARCHAR(64) NOT NULL,
  `record_type` ENUM('Online Certificate', 'Manual Certificate', 'Ticket') NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `deleted_by` VARCHAR(191) NOT NULL,
  `deleted_by_email` VARCHAR(191) NOT NULL,
  `deleted_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `original_data` LONGTEXT NOT NULL,
  INDEX `idx_trash_type` (`record_type`),
  INDEX `idx_trash_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. ADMIN AUDIT LOGS (IMMUTABLE AUDIT TRAIL)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `actor_name` VARCHAR(191) NOT NULL,
  `actor_email` VARCHAR(191) NOT NULL,
  `actor_role` VARCHAR(50) NOT NULL,
  `action_category` VARCHAR(50) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target_type` VARCHAR(50) NOT NULL,
  `target_id` VARCHAR(100) NOT NULL,
  `details` TEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audit_cat` (`action_category`),
  INDEX `idx_audit_actor` (`actor_email`),
  INDEX `idx_audit_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
