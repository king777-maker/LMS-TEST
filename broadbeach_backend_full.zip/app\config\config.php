<?php

// =============================================
// DATABASE CONFIGURATION
// =============================================

define("DB_HOST", "localhost");

define("DB_USER", "root");

define('DB_PASSWORD', '');

define(
    "DB_NAME",
    "broad_beach_online"
);

define("DB_PORT", 3306);


// =============================================
// APPLICATION
// =============================================

define(
    "APP_ENV",
    "development"
);


// =============================================
// ERROR REPORTING
// =============================================

if (APP_ENV === "development") {

    error_reporting(E_ALL);

    ini_set(
        "display_errors",
        "1"
    );

} else {

    error_reporting(E_ALL);

    ini_set(
        "display_errors",
        "0"
    );

    ini_set(
        "log_errors",
        "1"
    );

}