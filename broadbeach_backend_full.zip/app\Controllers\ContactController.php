<?php

/**
 * ============================================================================
 * BROADBEACH ACADEMY — CONTACT FORM CONTROLLER
 * ============================================================================
 * 
 * Handles contact inquiry submissions with:
 * - Server-side validation & sanitization
 * - Anti-spam honeypot verification
 * - IP rate-limiting
 * - Email header injection protection
 * - Safe HTML/plain-text email dispatch to official recipient: certification@broadbeach.in
 */

class ContactController
{
    private $recipientEmail = "certification@broadbeach.in";
    private $senderEmail = "no-reply@broadbeach.in";

    public function submit()
    {
        // 1. Ensure JSON response header
        header("Content-Type: application/json; charset=UTF-8");

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            http_response_code(405);
            echo json_encode([
                "success" => false,
                "message" => "Method not allowed. Only POST is accepted."
            ]);
            return;
        }

        // 2. Read input payload
        $raw = file_get_contents("php://input");
        $data = json_decode($raw, true);

        if (!is_array($data)) {
            $data = $_POST;
        }

        // 3. Honeypot check (anti-bot)
        if (!empty($data["website"])) {
            // Silently return success to waste bot resources without sending email
            http_response_code(200);
            echo json_encode([
                "success" => true,
                "message" => "Thank you! Your message has been received."
            ]);
            return;
        }

        // 4. Rate limiting check (max 5 submissions per hour per IP)
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $now = time();
        $rateLimitWindow = 3600; // 1 hour
        $maxAttempts = 5;

        if (!isset($_SESSION["contact_submissions"])) {
            $_SESSION["contact_submissions"] = [];
        }

        // Filter out submissions older than 1 hour
        $_SESSION["contact_submissions"] = array_filter(
            $_SESSION["contact_submissions"],
            function ($timestamp) use ($now, $rateLimitWindow) {
                return ($now - $timestamp) < $rateLimitWindow;
            }
        );

        if (count($_SESSION["contact_submissions"]) >= $maxAttempts) {
            http_response_code(429);
            echo json_encode([
                "success" => false,
                "message" => "Too many inquiries sent. Please wait before submitting another message or call us directly."
            ]);
            return;
        }

        // 5. Validation
        $name = trim($data["name"] ?? "");
        $email = trim($data["email"] ?? "");
        $phone = trim($data["phone"] ?? "");
        $subject = trim($data["subject"] ?? "");
        $message = trim($data["message"] ?? "");

        $errors = [];

        if (empty($name) || mb_strlen($name) < 2 || mb_strlen($name) > 100) {
            $errors["name"] = "Name is required and must be between 2 and 100 characters.";
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors["email"] = "Please provide a valid email address.";
        }

        if (!empty($phone) && !preg_match('/^[0-9+\-\s()]{6,25}$/', $phone)) {
            $errors["phone"] = "Phone number contains invalid characters.";
        }

        if (empty($subject) || mb_strlen($subject) < 2 || mb_strlen($subject) > 150) {
            $errors["subject"] = "Subject is required and must be between 2 and 150 characters.";
        }

        if (empty($message) || mb_strlen($message) < 10 || mb_strlen($message) > 4000) {
            $errors["message"] = "Message is required and must be between 10 and 4000 characters.";
        }

        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode([
                "success" => false,
                "message" => "Please review the form fields and correct errors.",
                "errors" => $errors
            ]);
            return;
        }

        // 6. Header injection protection (strip carriage returns and newlines from single-line fields)
        $cleanName = preg_replace("/[\r\n]+/", " ", $name);
        $cleanEmail = preg_replace("/[\r\n]+/", "", $email);
        $cleanPhone = preg_replace("/[\r\n]+/", " ", $phone);
        $cleanSubject = preg_replace("/[\r\n]+/", " ", $subject);

        // Safe HTML encoding for email body
        $safeHtmlMessage = nl2br(htmlspecialchars($message, ENT_QUOTES, "UTF-8"));
        $safeHtmlName = htmlspecialchars($cleanName, ENT_QUOTES, "UTF-8");
        $safeHtmlEmail = htmlspecialchars($cleanEmail, ENT_QUOTES, "UTF-8");
        $safeHtmlPhone = htmlspecialchars($cleanPhone, ENT_QUOTES, "UTF-8");
        $safeHtmlSubject = htmlspecialchars($cleanSubject, ENT_QUOTES, "UTF-8");

        // 7. Email Composition
        $emailSubject = "[Broadbeach Academy Inquiry] " . $cleanSubject;

        $emailHeaders = [
            "MIME-Version: 1.0",
            "Content-Type: text/html; charset=UTF-8",
            "From: Broadbeach Academy <" . $this->senderEmail . ">",
            "Reply-To: " . $cleanName . " <" . $cleanEmail . ">",
            "X-Mailer: PHP/" . phpversion()
        ];

        $htmlBody = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='utf-8'>
            <title>New Inquiry</title>
        </head>
        <body style='font-family: Arial, sans-serif; background-color: #f4f6f9; padding: 20px;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden;'>
                <div style='background-color: #0B315B; padding: 20px; text-align: center; color: #ffffff;'>
                    <h2 style='margin: 0; font-size: 20px;'>Broadbeach Online Academy</h2>
                    <p style='margin: 5px 0 0; color: #F7C600; font-size: 13px; font-weight: bold;'>New Student Inquiry Received</p>
                </div>
                <div style='padding: 24px; color: #334155; line-height: 1.6;'>
                    <table style='width: 100%; border-collapse: collapse; margin-bottom: 20px;'>
                        <tr>
                            <td style='padding: 8px 0; font-weight: bold; width: 120px;'>Full Name:</td>
                            <td style='padding: 8px 0;'>{$safeHtmlName}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px 0; font-weight: bold;'>Email:</td>
                            <td style='padding: 8px 0;'><a href='mailto:{$safeHtmlEmail}' style='color: #0B315B;'>{$safeHtmlEmail}</a></td>
                        </tr>
                        <tr>
                            <td style='padding: 8px 0; font-weight: bold;'>Phone:</td>
                            <td style='padding: 8px 0;'>{$safeHtmlPhone}</td>
                        </tr>
                        <tr>
                            <td style='padding: 8px 0; font-weight: bold;'>Subject:</td>
                            <td style='padding: 8px 0;'>{$safeHtmlSubject}</td>
                        </tr>
                    </table>
                    <div style='background-color: #f8fafc; border-left: 4px solid #0B315B; padding: 15px; border-radius: 4px;'>
                        <p style='margin: 0 0 8px; font-weight: bold; color: #0B315B;'>Message:</p>
                        <p style='margin: 0; color: #1e293b;'>{$safeHtmlMessage}</p>
                    </div>
                </div>
                <div style='background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 11px; color: #64748b;'>
                    Received via Broadbeach Online Academy contact portal &bull; Destination: certification@broadbeach.in
                </div>
            </div>
        </body>
        </html>
        ";

        // 8. Attempt email transmission
        $sent = false;
        try {
            $sent = @mail($this->recipientEmail, $emailSubject, $htmlBody, implode("\r\n", $emailHeaders));
        } catch (\Throwable $t) {
            error_log("Mail dispatch error: " . $t->getMessage());
        }

        // Record submission for rate limiting
        $_SESSION["contact_submissions"][] = $now;

        // Structured success response
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Thank you! Your inquiry has been submitted to Broadbeach Academy. Our academic counselors will respond to your email shortly.",
            "data" => [
                "recipient" => $this->recipientEmail,
                "dispatched" => $sent
            ]
        ]);
    }
}
