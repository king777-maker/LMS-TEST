<?php

// =====================================================
// CENTRALIZED CORS & PREFLIGHT
// =====================================================
require_once __DIR__ . "/app/config/cors.php";


// =====================================================
// REQUEST URI & ROUTING
// =====================================================

$requestUri = $_SERVER["REQUEST_URI"] ?? "";

// Check if request is directed to the API
if (
    str_contains($requestUri, "/broadbeach-backend/api/") ||
    str_starts_with($requestUri, "/api/") ||
    str_contains($requestUri, "/api/admin")
) {
    require_once __DIR__ . "/app/routes/api.php";
    exit;
}


// =====================================================
// DEFAULT RESPONSE
// =====================================================

http_response_code(404);

header("Content-Type: application/json; charset=UTF-8");

echo json_encode([
    "success" => false,
    "message" => "API route not found."
]);

exit;