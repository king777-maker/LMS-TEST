<?php

class Menu
{
    private mysqli $conn;

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->conn = $db;
    }

    // =====================================================
    // HELPER: GENERATE SLUG
    // =====================================================

    private function generateSlug(string $name): string
    {
        $slug = strtolower(trim($name));

        $slug = preg_replace(
            '/[^a-z0-9]+/i',
            '-',
            $slug
        );

        $slug = trim($slug, '-');

        return $slug ?: 'menu-item';
    }

    // =====================================================
    // HELPER: CHECK CATEGORY
    // =====================================================

    private function categoryExists(int $id): bool
    {
        $sql = "
            SELECT id
            FROM course_menu_categories
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Category check error: " . $this->conn->error
            );
        }

        $stmt->bind_param("i", $id);

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Category check failed: " . $error
            );
        }

        $result = $stmt->get_result();

        $exists = $result->num_rows > 0;

        $stmt->close();

        return $exists;
    }

    // =====================================================
    // HELPER: CHECK SUBCATEGORY
    // =====================================================

    private function subcategoryExists(int $id): bool
    {
        $sql = "
            SELECT id
            FROM course_menu_items
            WHERE id = ?
            AND subcategory_id IS NULL
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Subcategory check error: " . $this->conn->error
            );
        }

        $stmt->bind_param("i", $id);

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Subcategory check failed: " . $error
            );
        }

        $result = $stmt->get_result();

        $exists = $result->num_rows > 0;

        $stmt->close();

        return $exists;
    }

    // =====================================================
    // GET COMPLETE HEADER MENU
    // =====================================================

    public function getHeaderMenu(): array
    {
        $menu = [];

        $sql = "
            SELECT
                id,
                name,
                slug,
                menu_type,
                sort_order
            FROM course_menu_categories
            WHERE status = 'active'
            ORDER BY sort_order ASC, id ASC
        ";

        $result = $this->conn->query($sql);

        if (!$result) {
            throw new Exception(
                "Header category query error: " .
                $this->conn->error
            );
        }

        while ($category = $result->fetch_assoc()) {

            $categoryId = (int) $category["id"];

            $category["id"] = $categoryId;

            $category["sort_order"] =
                (int) $category["sort_order"];

            // =================================================
            // SIMPLE MENU
            // =================================================

            if ($category["menu_type"] === "simple") {

                $category["items"] =
                    $this->getItems(
                        $categoryId,
                        null
                    );

                $category["subcategories"] = [];
            }

            // =================================================
            // GROUPED MENU
            // =================================================
            elseif ($category["menu_type"] === "grouped") {

                $category["items"] = [];

                $category["subcategories"] =
                    $this->getActiveSubcategories(
                        $categoryId
                    );
            }

            // =================================================
            // UNKNOWN MENU TYPE
            // =================================================
            else {

                $category["items"] = [];

                $category["subcategories"] = [];
            }

            $menu[] = $category;
        }

        return $menu;
    }

    // =====================================================
    // GET ALL CATEGORIES - ADMIN
    // =====================================================

    public function getAllCategories(): array
    {
        $sql = "
            SELECT
                id,
                name,
                slug,
                menu_type,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_menu_categories
            ORDER BY sort_order ASC, id ASC
        ";

        $result = $this->conn->query($sql);

        if (!$result) {
            throw new Exception(
                "Get categories error: " .
                $this->conn->error
            );
        }

        $categories = [];

        while ($row = $result->fetch_assoc()) {

            $row["id"] =
                (int) $row["id"];

            $row["sort_order"] =
                (int) $row["sort_order"];

            $categories[] = $row;
        }

        return $categories;
    }

    // =====================================================
    // GET CATEGORY BY ID
    // =====================================================

    public function getCategoryById(int $id): ?array
    {
        $sql = "
            SELECT
                id,
                name,
                slug,
                menu_type,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_menu_categories
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Get category error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param("i", $id);

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Get category failed: " . $error
            );
        }

        $result = $stmt->get_result();

        $row = $result->fetch_assoc();

        $stmt->close();

        if (!$row) {
            return null;
        }

        $row["id"] =
            (int) $row["id"];

        $row["sort_order"] =
            (int) $row["sort_order"];

        return $row;
    }

    // =====================================================
    // CREATE CATEGORY
    // =====================================================

    public function createCategory(array $data): int
    {
        $name = trim(
            (string) ($data["name"] ?? "")
        );

        if ($name === "") {
            throw new Exception(
                "Category name is required."
            );
        }

        $slug = trim(
            (string) ($data["slug"] ?? "")
        );

        if ($slug === "") {
            $slug = $this->generateSlug($name);
        } else {
            $slug = $this->generateSlug($slug);
        }

        $menuType = trim(
            (string) ($data["menu_type"] ?? "simple")
        );

        if (
            !in_array(
                $menuType,
                ["simple", "grouped"],
                true
            )
        ) {
            $menuType = "simple";
        }

        $sortOrder =
            isset($data["sort_order"])
            ? (int) $data["sort_order"]
            : 0;

        $status = trim(
            (string) ($data["status"] ?? "active")
        );

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {
            $status = "active";
        }

        // =================================================
        // CHECK DUPLICATE SLUG
        // =================================================

        $checkSql = "
            SELECT id
            FROM course_menu_categories
            WHERE slug = ?
            LIMIT 1
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Slug check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "s",
            $slug
        );

        $checkStmt->execute();

        $checkResult =
            $checkStmt->get_result();

        if ($checkResult->num_rows > 0) {

            $checkStmt->close();

            throw new Exception(
                "A category with this slug already exists."
            );
        }

        $checkStmt->close();

        // =================================================
        // INSERT CATEGORY
        // =================================================

        $sql = "
            INSERT INTO course_menu_categories
            (
                name,
                slug,
                menu_type,
                sort_order,
                status,
                created_at,
                updated_at
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                NOW(),
                NOW()
            )
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Create category prepare error: " .
                $this->conn->error
            );
        }

        /*
         * name      = s
         * slug      = s
         * menu_type = s
         * sort_order= i
         * status    = s
         */
        $stmt->bind_param(
            "sssis",
            $name,
            $slug,
            $menuType,
            $sortOrder,
            $status
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Create category failed: " .
                $error
            );
        }

        $newId =
            (int) $this->conn->insert_id;

        $stmt->close();

        return $newId;
    }

    // =====================================================
    // UPDATE CATEGORY
    // =====================================================

    public function updateCategory(
        int $id,
        array $data
    ): bool {

        if ($id <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        if (!$this->categoryExists($id)) {
            throw new Exception(
                "Category not found."
            );
        }

        $name = trim(
            (string) ($data["name"] ?? "")
        );

        if ($name === "") {
            throw new Exception(
                "Category name is required."
            );
        }

        $slug = trim(
            (string) ($data["slug"] ?? "")
        );

        if ($slug === "") {
            $slug = $this->generateSlug($name);
        } else {
            $slug = $this->generateSlug($slug);
        }

        $menuType = trim(
            (string) ($data["menu_type"] ?? "simple")
        );

        if (
            !in_array(
                $menuType,
                ["simple", "grouped"],
                true
            )
        ) {
            $menuType = "simple";
        }

        $sortOrder =
            isset($data["sort_order"])
            ? (int) $data["sort_order"]
            : 0;

        $status = trim(
            (string) ($data["status"] ?? "active")
        );

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {
            $status = "active";
        }

        // =================================================
        // CHECK DUPLICATE SLUG
        // =================================================

        $checkSql = "
            SELECT id
            FROM course_menu_categories
            WHERE slug = ?
            AND id != ?
            LIMIT 1
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Slug check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "si",
            $slug,
            $id
        );

        if (!$checkStmt->execute()) {

            $error = $checkStmt->error;

            $checkStmt->close();

            throw new Exception(
                "Slug check failed: " . $error
            );
        }

        $result =
            $checkStmt->get_result();

        if ($result->num_rows > 0) {

            $checkStmt->close();

            throw new Exception(
                "Another category already uses this slug."
            );
        }

        $checkStmt->close();

        // =================================================
        // UPDATE
        // =================================================

        $sql = "
            UPDATE course_menu_categories
            SET
                name = ?,
                slug = ?,
                menu_type = ?,
                sort_order = ?,
                status = ?,
                updated_at = NOW()
            WHERE id = ?
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Update category prepare error: " .
                $this->conn->error
            );
        }

        /*
         * IMPORTANT:
         *
         * SQL has 6 placeholders:
         *
         * name
         * slug
         * menu_type
         * sort_order
         * status
         * id
         *
         * Therefore:
         *
         * s s s i s i
         *
         * = "sssisi"
         */

        $stmt->bind_param(
            "sssisi",
            $name,
            $slug,
            $menuType,
            $sortOrder,
            $status,
            $id
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Update category failed: " .
                $error
            );
        }

        $stmt->close();

        return true;
    }

    // =====================================================
    // DELETE CATEGORY
    // =====================================================

    public function deleteCategory(int $id): bool
    {
        if ($id <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        // =================================================
        // CHECK CATEGORY
        // =================================================

        if (!$this->categoryExists($id)) {
            throw new Exception(
                "Category not found."
            );
        }

        // =================================================
        // START TRANSACTION
        // =================================================

        $this->conn->begin_transaction();

        try {

            // =================================================
            // 1. DELETE MENU ITEMS
            // =================================================

            $sql = "
            DELETE FROM course_menu_items
            WHERE category_id = ?
        ";

            $stmt = $this->conn->prepare($sql);

            if (!$stmt) {
                throw new Exception(
                    "Delete menu items prepare error: " .
                    $this->conn->error
                );
            }

            $stmt->bind_param(
                "i",
                $id
            );

            if (!$stmt->execute()) {

                $error = $stmt->error;

                $stmt->close();

                throw new Exception(
                    "Delete menu items failed: " .
                    $error
                );
            }

            $stmt->close();


            // =================================================
            // 2. DELETE SUBCATEGORIES
            // =================================================

            $sql = "
            DELETE FROM course_menu_items
            WHERE category_id = ?
        ";

            $stmt = $this->conn->prepare($sql);

            if (!$stmt) {
                throw new Exception(
                    "Delete subcategories prepare error: " .
                    $this->conn->error
                );
            }

            $stmt->bind_param(
                "i",
                $id
            );

            if (!$stmt->execute()) {

                $error = $stmt->error;

                $stmt->close();

                throw new Exception(
                    "Delete subcategories failed: " .
                    $error
                );
            }

            $stmt->close();


            // =================================================
            // 3. DELETE CATEGORY
            // =================================================

            $sql = "
            DELETE FROM course_menu_categories
            WHERE id = ?
        ";

            $stmt = $this->conn->prepare($sql);

            if (!$stmt) {
                throw new Exception(
                    "Delete category prepare error: " .
                    $this->conn->error
                );
            }

            $stmt->bind_param(
                "i",
                $id
            );

            if (!$stmt->execute()) {

                $error = $stmt->error;

                $stmt->close();

                throw new Exception(
                    "Delete category failed: " .
                    $error
                );
            }

            // Check whether category was actually deleted
            $deleted = $stmt->affected_rows > 0;

            $stmt->close();


            // =================================================
            // COMMIT
            // =================================================

            $this->conn->commit();

            return $deleted;

        } catch (Throwable $e) {

            // =================================================
            // ROLLBACK
            // =================================================

            $this->conn->rollback();

            throw new Exception(
                $e->getMessage()
            );
        }
    }

    // =====================================================
    // GET ALL SUBCATEGORIES - ADMIN
    // =====================================================

    public function getAllSubcategories(): array
    {
        $sql = "
            SELECT
                s.id,
                s.category_id,
                c.name AS category_name,
                c.slug AS category_slug,
                s.name,
                s.slug,
                s.sort_order,
                s.status,
                s.created_at,
                s.updated_at
            FROM course_menu_items s
            LEFT JOIN course_menu_categories c
                ON c.id = s.category_id
            WHERE s.subcategory_id IS NULL
            ORDER BY
                c.sort_order ASC,
                s.sort_order ASC,
                s.id ASC
        ";

        $result =
            $this->conn->query($sql);

        if (!$result) {
            throw new Exception(
                "Get subcategories error: " .
                $this->conn->error
            );
        }

        $subcategories = [];

        while ($row = $result->fetch_assoc()) {

            $row["id"] =
                (int) $row["id"];

            $row["category_id"] =
                (int) $row["category_id"];

            $row["sort_order"] =
                (int) $row["sort_order"];

            $subcategories[] = $row;
        }

        return $subcategories;
    }

    // =====================================================
    // GET SUBCATEGORIES BY CATEGORY
    // =====================================================

    public function getSubcategories(
        int $categoryId
    ): array {

        if ($categoryId <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        $sql = "
            SELECT
                id,
                category_id,
                name,
                slug,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_menu_items
            WHERE category_id = ?
            AND subcategory_id IS NULL
            ORDER BY sort_order ASC, id ASC
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Get subcategories error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "i",
            $categoryId
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Get subcategories failed: " .
                $error
            );
        }

        $result =
            $stmt->get_result();

        $subcategories = [];

        while ($row = $result->fetch_assoc()) {

            $row["id"] =
                (int) $row["id"];

            $row["category_id"] =
                (int) $row["category_id"];

            $row["sort_order"] =
                (int) $row["sort_order"];

            $subcategories[] = $row;
        }

        $stmt->close();

        return $subcategories;
    }

    // =====================================================
    // GET SUBCATEGORY BY ID
    // =====================================================

    public function getSubcategoryById(
        int $id
    ): ?array {

        $sql = "
            SELECT
                s.id,
                s.category_id,
                c.name AS category_name,
                c.slug AS category_slug,
                s.name,
                s.slug,
                s.sort_order,
                s.status,
                s.created_at,
                s.updated_at
            FROM course_menu_items s
            LEFT JOIN course_menu_categories c
                ON c.id = s.category_id
            WHERE s.id = ?
            AND s.subcategory_id IS NULL
            LIMIT 1
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Get subcategory error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Get subcategory failed: " .
                $error
            );
        }

        $result =
            $stmt->get_result();

        $row =
            $result->fetch_assoc();

        $stmt->close();

        if (!$row) {
            return null;
        }

        $row["id"] =
            (int) $row["id"];

        $row["category_id"] =
            (int) $row["category_id"];

        $row["sort_order"] =
            (int) $row["sort_order"];

        return $row;
    }

    // =====================================================
    // CREATE SUBCATEGORY
    // =====================================================

    public function createSubcategory(
        array $data
    ): int {

        $categoryId =
            (int) ($data["category_id"] ?? 0);

        if ($categoryId <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        if (!$this->categoryExists($categoryId)) {
            throw new Exception(
                "Selected category does not exist."
            );
        }

        $name = trim(
            (string) ($data["name"] ?? "")
        );

        if ($name === "") {
            throw new Exception(
                "Subcategory name is required."
            );
        }

        $slug = trim(
            (string) ($data["slug"] ?? "")
        );

        if ($slug === "") {
            $slug =
                $this->generateSlug($name);
        } else {
            $slug =
                $this->generateSlug($slug);
        }

        $sortOrder =
            isset($data["sort_order"])
            ? (int) $data["sort_order"]
            : 0;

        $status = trim(
            (string) ($data["status"] ?? "active")
        );

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {
            $status = "active";
        }

        // =================================================
        // DUPLICATE SLUG
        // =================================================

        $checkSql = "
            SELECT id
            FROM course_menu_items
            WHERE slug = ?
            AND category_id = ?
            LIMIT 1
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Subcategory slug check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "si",
            $slug,
            $categoryId
        );

        if (!$checkStmt->execute()) {

            $error = $checkStmt->error;

            $checkStmt->close();

            throw new Exception(
                "Subcategory slug check failed: " .
                $error
            );
        }

        $result =
            $checkStmt->get_result();

        if ($result->num_rows > 0) {

            $checkStmt->close();

            throw new Exception(
                "A subcategory with this slug already exists in this category."
            );
        }

        $checkStmt->close();

        // =================================================
        // INSERT
        // =================================================

        // Store admin "subcategory" rows in course_menu_items.
        // These rows are top-level menu items, therefore
        // subcategory_id is NULL.
        $path = trim(
            (string) ($data["path"] ?? "")
        );

        if ($path === "") {
            $path = "/" . ltrim($slug, "/");
        }

        $sql = "
            INSERT INTO course_menu_items
            (
                category_id,
                subcategory_id,
                name,
                slug,
                path,
                sort_order,
                status,
                created_at,
                updated_at
            )
            VALUES
            (
                ?,
                NULL,
                ?,
                ?,
                ?,
                ?,
                ?,
                NOW(),
                NOW()
            )
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Create subcategory error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "isssis",
            $categoryId,
            $name,
            $slug,
            $path,
            $sortOrder,
            $status
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Create subcategory failed: " .
                $error
            );
        }

        $newId =
            (int) $this->conn->insert_id;

        $stmt->close();

        return $newId;
    }

    // =====================================================
    // UPDATE SUBCATEGORY
    // =====================================================

    public function updateSubcategory(
        int $id,
        array $data
    ): bool {

        if ($id <= 0) {
            throw new Exception(
                "Subcategory ID is required."
            );
        }

        if (!$this->subcategoryExists($id)) {
            throw new Exception(
                "Subcategory not found."
            );
        }

        $categoryId =
            (int) ($data["category_id"] ?? 0);

        if ($categoryId <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        if (!$this->categoryExists($categoryId)) {
            throw new Exception(
                "Selected category does not exist."
            );
        }

        $name = trim(
            (string) ($data["name"] ?? "")
        );

        if ($name === "") {
            throw new Exception(
                "Subcategory name is required."
            );
        }

        $slug = trim(
            (string) ($data["slug"] ?? "")
        );

        if ($slug === "") {
            $slug =
                $this->generateSlug($name);
        } else {
            $slug =
                $this->generateSlug($slug);
        }

        $sortOrder =
            isset($data["sort_order"])
            ? (int) $data["sort_order"]
            : 0;

        $status = trim(
            (string) ($data["status"] ?? "active")
        );

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {
            $status = "active";
        }

        // =================================================
        // DUPLICATE SLUG
        // =================================================

        $checkSql = "
            SELECT id
            FROM course_menu_items
            WHERE slug = ?
            AND category_id = ?
            AND id != ?
            LIMIT 1
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Slug check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "sii",
            $slug,
            $categoryId,
            $id
        );

        if (!$checkStmt->execute()) {

            $error = $checkStmt->error;

            $checkStmt->close();

            throw new Exception(
                "Slug check failed: " .
                $error
            );
        }

        $result =
            $checkStmt->get_result();

        if ($result->num_rows > 0) {

            $checkStmt->close();

            throw new Exception(
                "Another subcategory already uses this slug in this category."
            );
        }

        $checkStmt->close();

        // =================================================
        // UPDATE
        // =================================================

        $sql = "
            UPDATE course_menu_items
            SET
                category_id = ?,
                name = ?,
                slug = ?,
                sort_order = ?,
                status = ?,
                updated_at = NOW()
            WHERE id = ?
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Update subcategory error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "issisi",
            $categoryId,
            $name,
            $slug,
            $sortOrder,
            $status,
            $id
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Update subcategory failed: " .
                $error
            );
        }

        $stmt->close();

        return true;
    }

    // =====================================================
    // DELETE SUBCATEGORY
    // =====================================================

    public function deleteSubcategory(
        int $id
    ): bool {

        if ($id <= 0) {
            throw new Exception(
                "Subcategory ID is required."
            );
        }

        if (!$this->subcategoryExists($id)) {
            throw new Exception(
                "Subcategory not found."
            );
        }

        // =================================================
        // CHECK MENU ITEMS
        // =================================================

        $sql = "
            SELECT COUNT(*) AS total
            FROM course_menu_items
            WHERE subcategory_id = ?
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Menu item count error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        $stmt->execute();

        $result =
            $stmt->get_result();

        $row =
            $result->fetch_assoc();

        $stmt->close();

        $itemCount =
            (int) ($row["total"] ?? 0);

        if ($itemCount > 0) {

            throw new Exception(
                "Cannot delete subcategory because it contains menu items. Delete the menu items first."
            );
        }

        // =================================================
        // DELETE
        // =================================================

        $sql = "
            DELETE FROM course_menu_items
            WHERE id = ?
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Delete subcategory error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Delete subcategory failed: " .
                $error
            );
        }

        $deleted =
            $stmt->affected_rows > 0;

        $stmt->close();

        return $deleted;
    }

    // =====================================================
    // GET ACTIVE SUBCATEGORIES
    // =====================================================

    private function getActiveSubcategories(
        int $categoryId
    ): array {

        $subcategories = [];

        // A subcategory is stored in course_menu_items with
        // subcategory_id = NULL. Only return it as a header
        // subcategory when it has at least one active child item.
        $sql = "
            SELECT
                parent.id,
                parent.category_id,
                parent.name,
                parent.slug,
                parent.path,
                parent.sort_order,
                parent.status
            FROM course_menu_items AS parent
            INNER JOIN course_menu_items AS child
                ON child.subcategory_id = parent.id
                AND child.category_id = parent.category_id
                AND child.status = 'active'
            WHERE parent.category_id = ?
              AND parent.subcategory_id IS NULL
              AND parent.status = 'active'
            GROUP BY
                parent.id,
                parent.category_id,
                parent.name,
                parent.slug,
                parent.path,
                parent.sort_order,
                parent.status
            ORDER BY
                parent.sort_order ASC,
                parent.id ASC
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Active subcategory prepare error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "i",
            $categoryId
        );

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Active subcategory query failed: " .
                $error
            );
        }

        $result = $stmt->get_result();

        while (
            $subcategory =
            $result->fetch_assoc()
        ) {

            $subcategoryId =
                (int) $subcategory["id"];

            $subcategory["id"] =
                $subcategoryId;

            $subcategory["category_id"] =
                (int) $subcategory["category_id"];

            $subcategory["sort_order"] =
                (int) $subcategory["sort_order"];

            // =================================================
            // GET ITEMS UNDER SUBCATEGORY
            // =================================================

            $subcategory["items"] =
                $this->getItems(
                    $categoryId,
                    $subcategoryId
                );

            $subcategories[] =
                $subcategory;
        }

        $stmt->close();

        return $subcategories;
    }


    // =====================================================
    // GET MENU ITEMS
    // =====================================================

    // private function getItems(
    //     int $categoryId,
    //     ?int $subcategoryId = null
    // ): array {

    //     $items = [];

    //     // =================================================
    //     // ITEMS UNDER SUBCATEGORY
    //     // =================================================

    //     if ($subcategoryId !== null) {

    //         $sql = "
    //             SELECT
    //                 id,
    //                 category_id,
    //                 subcategory_id,
    //                 name,
    //                 slug,
    //                 path,
    //                 sort_order
    //             FROM course_menu_items
    //             WHERE category_id = ?
    //             AND subcategory_id = ?
    //             AND status = 'active'
    //             ORDER BY sort_order ASC, id ASC
    //         ";

    //         $stmt =
    //             $this->conn->prepare($sql);

    //         if (!$stmt) {
    //             throw new Exception(
    //                 "Subcategory item prepare error: " .
    //                 $this->conn->error
    //             );
    //         }

    //         $stmt->bind_param(
    //             "ii",
    //             $categoryId,
    //             $subcategoryId
    //         );
    //     }

    //     // =================================================
    //     // ITEMS DIRECTLY UNDER CATEGORY
    //     // =================================================
    //     else {

    //         $sql = "
    //             SELECT
    //                 id,
    //                 category_id,
    //                 subcategory_id,
    //                 name,
    //                 slug,
    //                 path,
    //                 sort_order
    //             FROM course_menu_items
    //             WHERE category_id = ?
    //             AND subcategory_id IS NULL
    //             AND status = 'active'
    //             ORDER BY sort_order ASC, id ASC
    //         ";

    //         $stmt =
    //             $this->conn->prepare($sql);

    //         if (!$stmt) {
    //             throw new Exception(
    //                 "Category item prepare error: " .
    //                 $this->conn->error
    //             );
    //         }

    //         $stmt->bind_param(
    //             "i",
    //             $categoryId
    //         );
    //     }

    //     // =================================================
    //     // EXECUTE
    //     // =================================================

    //     if (!$stmt->execute()) {

    //         $error = $stmt->error;

    //         $stmt->close();

    //         throw new Exception(
    //             "Get menu items failed: " .
    //             $error
    //         );
    //     }

    //     $result =
    //         $stmt->get_result();

    //     while (
    //         $item =
    //         $result->fetch_assoc()
    //     ) {

    //         $item["id"] =
    //             (int) $item["id"];

    //         $item["category_id"] =
    //             (int) $item["category_id"];

    //         $item["subcategory_id"] =
    //             $item["subcategory_id"] !== null
    //             ? (int) $item["subcategory_id"]
    //             : null;

    //         $item["sort_order"] =
    //             (int) $item["sort_order"];

    //         $items[] = $item;
    //     }

    //     $stmt->close();

    //     return $items;
    // }
    
    
        private function getItems(
        int $categoryId,
        ?int $subcategoryId = null
    ): array {

        $items = [];

        // =================================================
        // ITEMS UNDER SUBCATEGORY
        // =================================================

        if ($subcategoryId !== null) {

            $sql = "
            SELECT
                id,
                category_id,
                subcategory_id,
                name,
                slug,
                path,
                sort_order,
                status
            FROM course_menu_items
            WHERE category_id = ?
              AND subcategory_id = ?
              AND status = 'active'
            ORDER BY
                sort_order ASC,
                id ASC
        ";

            $stmt = $this->conn->prepare($sql);

            if (!$stmt) {
                throw new Exception(
                    "Subcategory item prepare error: " .
                    $this->conn->error
                );
            }

            $stmt->bind_param(
                "ii",
                $categoryId,
                $subcategoryId
            );

        }

        // =================================================
        // ITEMS DIRECTLY UNDER CATEGORY
        // =================================================
        else {

            /*
             * FREE COURSES
             *
             * Category ID 20 contains the exact
             * 11 courses that should appear in
             * the public Free Courses menu.
             *
             * IDs:
             * 320 - ISO 9001:2026 QMS Awareness
             * 321 - ISO14001: 2026 EMS Awareness
             * 322 - ISO 45001:2018 OHSMS Awareness
             * 323 - ISO 22000:2018 FSMS Awareness
             * 324 - ISO 19011:2026 Awareness
             * 325 - ISO 27001:2022 ISMS Awareness
             * 326 - 5S Workplace Management
             * 327 - 7QC Tools Certification
             * 328 - Project Management Level-1
             * 329 - Lean Six Sigma White belt
             * 330 - Root Cause Analysis
             */

            if ($categoryId === 20) {

                $sql = "
                SELECT
                    id,
                    category_id,
                    subcategory_id,
                    name,
                    slug,
                    path,
                    sort_order,
                    status
                FROM course_menu_items
                WHERE category_id = 20
                  AND id BETWEEN 320 AND 330
                  AND subcategory_id IS NULL
                  AND status = 'active'
                ORDER BY
                    sort_order ASC,
                    id ASC
            ";

                $stmt = $this->conn->prepare($sql);

                if (!$stmt) {
                    throw new Exception(
                        "Free courses menu prepare error: " .
                        $this->conn->error
                    );
                }

            } else {

                /*
                 * ALL OTHER CATEGORIES
                 *
                 * Keep existing dynamic behaviour.
                 */

                $sql = "
                SELECT
                    id,
                    category_id,
                    subcategory_id,
                    name,
                    slug,
                    path,
                    sort_order,
                    status
                FROM course_menu_items
                WHERE category_id = ?
                  AND subcategory_id IS NULL
                  AND status = 'active'
                ORDER BY
                    sort_order ASC,
                    id ASC
            ";

                $stmt = $this->conn->prepare($sql);

                if (!$stmt) {
                    throw new Exception(
                        "Category item prepare error: " .
                        $this->conn->error
                    );
                }

                $stmt->bind_param(
                    "i",
                    $categoryId
                );
            }
        }

        // =================================================
        // EXECUTE
        // =================================================

        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Get menu items failed: " .
                $error
            );
        }

        // =================================================
        // RESULT
        // =================================================

        $result = $stmt->get_result();

        while ($item = $result->fetch_assoc()) {

            $items[] = [
                "id" =>
                    (int) $item["id"],

                "category_id" =>
                    (int) $item["category_id"],

                "subcategory_id" =>
                    $item["subcategory_id"] !== null
                    ? (int) $item["subcategory_id"]
                    : null,

                "name" =>
                    $item["name"],

                "slug" =>
                    $item["slug"],

                "path" =>
                    $item["path"],

                "sort_order" =>
                    (int) $item["sort_order"],

                "status" =>
                    $item["status"]
            ];
        }

        $stmt->close();

        return $items;
    }

    // =====================================================
    // GET SINGLE COURSE MENU ITEM
    // =====================================================

    public function getCourseMenuItemById(int $id): ?array
    {
        if ($id <= 0) {
            throw new Exception(
                "Menu item ID is required."
            );
        }

        $sql = "
            SELECT
                id,
                category_id,
                subcategory_id,
                name,
                slug,
                path,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_menu_items
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Get course menu item error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param("i", $id);

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Get course menu item failed: " . $error
            );
        }

        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $stmt->close();

        if (!$row) {
            return null;
        }

        $row["id"] = (int) $row["id"];
        $row["category_id"] = (int) $row["category_id"];
        $row["subcategory_id"] =
            $row["subcategory_id"] !== null &&
            $row["subcategory_id"] !== ""
            ? (int) $row["subcategory_id"]
            : null;
        $row["sort_order"] = (int) $row["sort_order"];

        return $row;
    }


    // =====================================================
    // CREATE COURSE MENU ITEM
    // =====================================================

    public function createCourseMenuItem(
        array $data
    ): int {

        $categoryId =
            (int) ($data["category_id"] ?? 0);

        if ($categoryId <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        if (!$this->categoryExists($categoryId)) {
            throw new Exception(
                "Selected category does not exist."
            );
        }

        $subcategoryId = null;

        if (
            isset($data["subcategory_id"]) &&
            $data["subcategory_id"] !== "" &&
            $data["subcategory_id"] !== null
        ) {
            $subcategoryId =
                (int) $data["subcategory_id"];

            if ($subcategoryId <= 0) {
                throw new Exception(
                    "Invalid subcategory ID."
                );
            }
        }

        $name = trim(
            (string) ($data["name"] ?? "")
        );

        if ($name === "") {
            throw new Exception(
                "Menu item name is required."
            );
        }

        $slug = trim(
            (string) ($data["slug"] ?? "")
        );

        if ($slug === "") {
            $slug = $this->generateSlug($name);
        } else {
            $slug = $this->generateSlug($slug);
        }

        $path = trim(
            (string) ($data["path"] ?? "")
        );

        if ($path === "") {
            $path = "/" . ltrim($slug, "/");
        }

        $sortOrder =
            isset($data["sort_order"])
            ? (int) $data["sort_order"]
            : 0;

        $status = trim(
            (string) ($data["status"] ?? "active")
        );

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {
            $status = "active";
        }

        // Duplicate slug in the same category.
        $checkSql = "
            SELECT id
            FROM course_menu_items
            WHERE slug = ?
            AND category_id = ?
            AND (
                (subcategory_id = ?)
                OR (
                    subcategory_id IS NULL
                    AND ? IS NULL
                )
            )
            LIMIT 1
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Menu item slug check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "siii",
            $slug,
            $categoryId,
            $subcategoryId,
            $subcategoryId
        );

        if (!$checkStmt->execute()) {
            $error = $checkStmt->error;
            $checkStmt->close();

            throw new Exception(
                "Menu item slug check failed: " .
                $error
            );
        }

        $result =
            $checkStmt->get_result();

        if ($result->num_rows > 0) {
            $checkStmt->close();

            throw new Exception(
                "A menu item with this slug already exists in this category."
            );
        }

        $checkStmt->close();

        $sql = "
            INSERT INTO course_menu_items
            (
                category_id,
                subcategory_id,
                name,
                slug,
                path,
                sort_order,
                status,
                created_at,
                updated_at
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Create course menu item error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "iisssis",
            $categoryId,
            $subcategoryId,
            $name,
            $slug,
            $path,
            $sortOrder,
            $status
        );

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Create course menu item failed: " .
                $error
            );
        }

        $newId =
            (int) $this->conn->insert_id;

        $stmt->close();

        return $newId;
    }


    // =====================================================
    // UPDATE COURSE MENU ITEM
    // =====================================================

    public function updateCourseMenuItem(
        int $id,
        array $data
    ): bool {

        if ($id <= 0) {
            throw new Exception(
                "Menu item ID is required."
            );
        }

        if (!$this->getCourseMenuItemById($id)) {
            throw new Exception(
                "Course menu item not found."
            );
        }

        $categoryId =
            (int) ($data["category_id"] ?? 0);

        if ($categoryId <= 0) {
            throw new Exception(
                "Category ID is required."
            );
        }

        if (!$this->categoryExists($categoryId)) {
            throw new Exception(
                "Selected category does not exist."
            );
        }

        $subcategoryId = null;

        if (
            isset($data["subcategory_id"]) &&
            $data["subcategory_id"] !== "" &&
            $data["subcategory_id"] !== null
        ) {
            $subcategoryId =
                (int) $data["subcategory_id"];

            if ($subcategoryId <= 0) {
                throw new Exception(
                    "Invalid subcategory ID."
                );
            }
        }

        $name = trim(
            (string) ($data["name"] ?? "")
        );

        if ($name === "") {
            throw new Exception(
                "Menu item name is required."
            );
        }

        $slug = trim(
            (string) ($data["slug"] ?? "")
        );

        if ($slug === "") {
            $slug = $this->generateSlug($name);
        } else {
            $slug = $this->generateSlug($slug);
        }

        $path = trim(
            (string) ($data["path"] ?? "")
        );

        if ($path === "") {
            $path = "/" . ltrim($slug, "/");
        }

        $sortOrder =
            isset($data["sort_order"])
            ? (int) $data["sort_order"]
            : 0;

        $status = trim(
            (string) ($data["status"] ?? "active")
        );

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {
            $status = "active";
        }

        $checkSql = "
            SELECT id
            FROM course_menu_items
            WHERE slug = ?
            AND category_id = ?
            AND id != ?
            AND (
                (subcategory_id = ?)
                OR (
                    subcategory_id IS NULL
                    AND ? IS NULL
                )
            )
            LIMIT 1
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Menu item slug check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "siiii",
            $slug,
            $categoryId,
            $id,
            $subcategoryId,
            $subcategoryId
        );

        if (!$checkStmt->execute()) {
            $error = $checkStmt->error;
            $checkStmt->close();

            throw new Exception(
                "Menu item slug check failed: " .
                $error
            );
        }

        $result =
            $checkStmt->get_result();

        if ($result->num_rows > 0) {
            $checkStmt->close();

            throw new Exception(
                "Another menu item already uses this slug in this category."
            );
        }

        $checkStmt->close();

        $sql = "
            UPDATE course_menu_items
            SET
                category_id = ?,
                subcategory_id = ?,
                name = ?,
                slug = ?,
                path = ?,
                sort_order = ?,
                status = ?,
                updated_at = NOW()
            WHERE id = ?
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Update course menu item error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "iisssisi",
            $categoryId,
            $subcategoryId,
            $name,
            $slug,
            $path,
            $sortOrder,
            $status,
            $id
        );

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Update course menu item failed: " .
                $error
            );
        }

        $updated =
            $stmt->affected_rows >= 0;

        $stmt->close();

        return $updated;
    }


    // =====================================================
    // DELETE COURSE MENU ITEM
    // =====================================================

    public function deleteCourseMenuItem(
        int $id
    ): bool {

        if ($id <= 0) {
            throw new Exception(
                "Menu item ID is required."
            );
        }

        $existing =
            $this->getCourseMenuItemById($id);

        if (!$existing) {
            throw new Exception(
                "Course menu item not found."
            );
        }

        // Do not delete a parent menu item if it has
        // child items under subcategory_id.
        $checkSql = "
            SELECT COUNT(*) AS total
            FROM course_menu_items
            WHERE subcategory_id = ?
        ";

        $checkStmt =
            $this->conn->prepare($checkSql);

        if (!$checkStmt) {
            throw new Exception(
                "Child menu item check error: " .
                $this->conn->error
            );
        }

        $checkStmt->bind_param(
            "i",
            $id
        );

        if (!$checkStmt->execute()) {
            $error = $checkStmt->error;
            $checkStmt->close();

            throw new Exception(
                "Child menu item check failed: " .
                $error
            );
        }

        $result =
            $checkStmt->get_result();

        $row =
            $result->fetch_assoc();

        $checkStmt->close();

        $childCount =
            (int) ($row["total"] ?? 0);

        if ($childCount > 0) {
            throw new Exception(
                "Cannot delete this menu item because it contains child menu items. Delete the child items first."
            );
        }

        $sql = "
            DELETE FROM course_menu_items
            WHERE id = ?
        ";

        $stmt =
            $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Delete course menu item error: " .
                $this->conn->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        if (!$stmt->execute()) {
            $error = $stmt->error;
            $stmt->close();

            throw new Exception(
                "Delete course menu item failed: " .
                $error
            );
        }

        $deleted =
            $stmt->affected_rows > 0;

        $stmt->close();

        return $deleted;
    }


    // =====================================================
    // GET COURSE MENU ITEMS - ADMIN
    //
    // DATA SOURCE:
    // course_menu_items
    //
    // Examples:
    //
    // /api/admin/course-menu-items
    //
    // /api/admin/course-menu-items?category_id=19
    //
    // /api/admin/course-menu-items?category_id=19&subcategory_id=5
    //
    // =====================================================

public function getMenuItemsByCategory(int $categoryId): array
{
    if ($categoryId <= 0) {
        throw new Exception(
            "Category ID is required."
        );
    }

    $sql = "
        SELECT
            id,
            category_id,
            subcategory_id,
            name,
            slug,
            path,
            sort_order,
            status
        FROM course_menu_items
        WHERE category_id = ?
          AND status = 'active'
        ORDER BY
            CASE
                WHEN subcategory_id IS NULL THEN 0
                ELSE 1
            END,
            sort_order ASC,
            id ASC
    ";

    $stmt = $this->conn->prepare($sql);

    if (!$stmt) {
        throw new Exception(
            "Get menu items prepare error: " .
            $this->conn->error
        );
    }

    $stmt->bind_param(
        "i",
        $categoryId
    );

    if (!$stmt->execute()) {

        $error = $stmt->error;

        $stmt->close();

        throw new Exception(
            "Get menu items failed: " .
            $error
        );
    }

    $result = $stmt->get_result();

    $items = [];

    while ($row = $result->fetch_assoc()) {

        $items[] = [
            "id" => (int) $row["id"],

            "category_id" =>
                (int) $row["category_id"],

            "subcategory_id" =>
                $row["subcategory_id"] !== null
                    ? (int) $row["subcategory_id"]
                    : null,

            "name" =>
                $row["name"],

            "slug" =>
                $row["slug"],

            "path" =>
                $row["path"],

            "sort_order" =>
                (int) $row["sort_order"],

            "status" =>
                $row["status"]
        ];
    }

    $stmt->close();

    return $items;
}

public function getPublicMenuItemsByCategory(
    int $categoryId
): array {

    if ($categoryId <= 0) {
        throw new Exception(
            "Category ID is required."
        );
    }

    $sql = "
        SELECT
            child.id,
            child.category_id,
            child.subcategory_id,
            child.name,
            child.slug,
            child.path,
            child.sort_order,
            child.status,

            parent.id AS parent_id,
            parent.name AS subcategory_name,
            parent.slug AS subcategory_slug,
            parent.sort_order AS subcategory_sort_order

        FROM course_menu_items AS child

        LEFT JOIN course_menu_items AS parent
            ON parent.id = child.subcategory_id
            AND parent.category_id = child.category_id
            AND parent.subcategory_id IS NULL

        WHERE child.category_id = ?
          AND child.status = 'active'
          AND child.subcategory_id IS NOT NULL

        ORDER BY
            parent.sort_order ASC,
            child.sort_order ASC,
            child.id ASC
    ";

    $stmt = $this->conn->prepare($sql);

    if (!$stmt) {
        throw new Exception(
            "Public menu items prepare error: " .
            $this->conn->error
        );
    }

    $stmt->bind_param(
        "i",
        $categoryId
    );

    if (!$stmt->execute()) {

        $error = $stmt->error;

        $stmt->close();

        throw new Exception(
            "Public menu items query failed: " .
            $error
        );
    }

    $result = $stmt->get_result();

    $items = [];

    while ($row = $result->fetch_assoc()) {

        $items[] = [

            "id" =>
                (int) $row["id"],

            "category_id" =>
                (int) $row["category_id"],

            "subcategory_id" =>
                $row["subcategory_id"] !== null
                    ? (int) $row["subcategory_id"]
                    : null,

            "name" =>
                $row["name"],

            "slug" =>
                $row["slug"],

            "path" =>
                $row["path"],

            "sort_order" =>
                (int) $row["sort_order"],

            "status" =>
                $row["status"],

            "parent_id" =>
                $row["parent_id"] !== null
                    ? (int) $row["parent_id"]
                    : null,

            "subcategory_name" =>
                $row["subcategory_name"],

            "subcategory_slug" =>
                $row["subcategory_slug"],

            "subcategory_sort_order" =>
                $row["subcategory_sort_order"] !== null
                    ? (int) $row["subcategory_sort_order"]
                    : null
        ];
    }

    $stmt->close();

    return $items;
}

// =====================================================
// PUBLIC PROFESSIONAL CERTIFICATIONS MENU
// =====================================================
//
// This method is ONLY for the public website navbar.
//
// It does NOT change any admin functionality.
//
// CATEGORY:
// Professional Certifications = 24
//
// TABLES:
// course_menu_categories
// course_menu_subcategories
// course_menu_items
// =====================================================

public function getPublicProfessionalCertificationMenu(): array
{
    $categoryId = 24;

    // -------------------------------------------------
    // GET CATEGORY
    // -------------------------------------------------

    $categorySql = "
        SELECT
            id,
            name,
            slug,
            menu_type,
            sort_order
        FROM course_menu_categories
        WHERE id = ?
        AND status = 'active'
        LIMIT 1
    ";

    $categoryStmt =
        $this->conn->prepare($categorySql);

    if (!$categoryStmt) {
        throw new Exception(
            "Professional certification category error: " .
            $this->conn->error
        );
    }

    $categoryStmt->bind_param(
        "i",
        $categoryId
    );

    $categoryStmt->execute();

    $categoryResult =
        $categoryStmt->get_result();

    $category =
        $categoryResult->fetch_assoc();

    $categoryStmt->close();


    if (!$category) {

        return [
            "category_id" => $categoryId,
            "name" => "Professional Certifications",
            "slug" => "professional-certifications",
            "subcategories" => []
        ];
    }


    // -------------------------------------------------
    // GET SUBCATEGORIES
    // -------------------------------------------------

    $subcategorySql = "
        SELECT
            id,
            category_id,
            name,
            slug,
            sort_order
        FROM course_menu_subcategories
        WHERE category_id = ?
        AND status = 'active'
        ORDER BY
            sort_order ASC,
            id ASC
    ";

    $subcategoryStmt =
        $this->conn->prepare(
            $subcategorySql
        );

    if (!$subcategoryStmt) {
        throw new Exception(
            "Professional certification subcategory error: " .
            $this->conn->error
        );
    }

    $subcategoryStmt->bind_param(
        "i",
        $categoryId
    );

    $subcategoryStmt->execute();

    $subcategoryResult =
        $subcategoryStmt->get_result();

    $subcategories = [];


    // -------------------------------------------------
    // LOOP SUBCATEGORIES
    // -------------------------------------------------

    while (
        $subcategory =
        $subcategoryResult->fetch_assoc()
    ) {

        $subcategoryId =
            (int) $subcategory["id"];


        // -------------------------------------------------
        // GET ITEMS FOR THIS SUBCATEGORY
        // -------------------------------------------------

        $itemSql = "
            SELECT
                id,
                category_id,
                subcategory_id,
                name,
                slug,
                path,
                sort_order
            FROM course_menu_items
            WHERE category_id = ?
            AND subcategory_id = ?
            AND status = 'active'
            ORDER BY
                sort_order ASC,
                id ASC
        ";

        $itemStmt =
            $this->conn->prepare(
                $itemSql
            );

        if (!$itemStmt) {
            $subcategoryStmt->close();

            throw new Exception(
                "Professional certification item error: " .
                $this->conn->error
            );
        }

        $itemStmt->bind_param(
            "ii",
            $categoryId,
            $subcategoryId
        );

        $itemStmt->execute();

        $itemResult =
            $itemStmt->get_result();

        $items = [];


        while (
            $item =
            $itemResult->fetch_assoc()
        ) {

            $item["id"] =
                (int) $item["id"];

            $item["category_id"] =
                (int) $item["category_id"];

            $item["subcategory_id"] =
                (int) $item["subcategory_id"];

            $item["sort_order"] =
                (int) $item["sort_order"];

            $items[] = $item;
        }


        $itemStmt->close();


        // -------------------------------------------------
        // ATTACH ITEMS
        // -------------------------------------------------

        $subcategory["id"] =
            $subcategoryId;

        $subcategory["category_id"] =
            $categoryId;

        $subcategory["sort_order"] =
            (int) $subcategory["sort_order"];

        $subcategory["items"] =
            $items;


        $subcategories[] =
            $subcategory;
    }

    $subcategoryStmt->close();


    // -------------------------------------------------
    // FINAL RESPONSE
    // -------------------------------------------------

    return [
        "category_id" =>
            (int) $category["id"],

        "name" =>
            $category["name"],

        "slug" =>
            $category["slug"],

        "menu_type" =>
            $category["menu_type"],

        "sort_order" =>
            (int) $category["sort_order"],

        "subcategories" =>
            $subcategories
    ];
}
 
public function getCourseMenuItems(
    $categoryId = null,
    $subcategoryId = null
): array {

    $sql = "
        SELECT
            id,
            category_id,
            subcategory_id,
            name,
            slug,
            path,
            sort_order,
            status,
            created_at,
            updated_at
        FROM course_menu_items
        WHERE status = 'active'
    ";

    $types = "";

    $values = [];


    // =====================================================
    // CATEGORY FILTER
    // =====================================================

    if (
        $categoryId !== null &&
        $categoryId !== ""
    ) {

        $categoryId = (int) $categoryId;

        if ($categoryId <= 0) {
            throw new Exception(
                "Invalid category ID."
            );
        }

        $sql .= "
            AND category_id = ?
        ";

        $types .= "i";

        $values[] = $categoryId;
    }


    // =====================================================
    // SUBCATEGORY FILTER
    // =====================================================

    if (
        $subcategoryId !== null &&
        $subcategoryId !== ""
    ) {

        $subcategoryId = (int) $subcategoryId;

        if ($subcategoryId <= 0) {
            throw new Exception(
                "Invalid subcategory ID."
            );
        }

        $sql .= "
            AND subcategory_id = ?
        ";

        $types .= "i";

        $values[] = $subcategoryId;
    }


    // =====================================================
    // ORDER
    // =====================================================

    $sql .= "
        ORDER BY
            sort_order ASC,
            id ASC
    ";


    // =====================================================
    // PREPARE
    // =====================================================

    $stmt = $this->conn->prepare($sql);

    if (!$stmt) {
        throw new Exception(
            "Course menu items prepare error: " .
            $this->conn->error
        );
    }


    // =====================================================
    // BIND PARAMETERS
    // =====================================================

    if (!empty($values)) {

        $bindParams = [];

        $bindParams[] = $types;

        foreach ($values as $key => $value) {
            $bindParams[] = &$values[$key];
        }

        call_user_func_array(
            [$stmt, "bind_param"],
            $bindParams
        );
    }


    // =====================================================
    // EXECUTE
    // =====================================================

    if (!$stmt->execute()) {

        $error = $stmt->error;

        $stmt->close();

        throw new Exception(
            "Course menu items query failed: " .
            $error
        );
    }


    // =====================================================
    // RESULT
    // =====================================================

    $result = $stmt->get_result();

    if (!$result) {

        $error = $stmt->error;

        $stmt->close();

        throw new Exception(
            "Unable to fetch course menu items: " .
            $error
        );
    }


    // =====================================================
    // BUILD DATA
    // =====================================================

    $data = [];

    while ($row = $result->fetch_assoc()) {

        $row["id"] =
            (int) $row["id"];

        $row["category_id"] =
            (int) $row["category_id"];

        $row["subcategory_id"] =
            (
                $row["subcategory_id"] !== null &&
                $row["subcategory_id"] !== ""
            )
            ? (int) $row["subcategory_id"]
            : null;

        $row["sort_order"] =
            (int) $row["sort_order"];

        $data[] = $row;
    }

    $stmt->close();

    return $data;
}


}