<?php

require_once __DIR__ . "/../Query.php";

class Lesson
{
    private mysqli $db;
    private Query $query;

    /*
     * Backend public URL
     */
    private string $baseUrl =
        "https://cadac.in/broadbeachlearning.com/broadbeach-backend/";

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
        $this->query = new Query($db);
    }

    // =====================================================
    // FORMAT FILE URL
    // =====================================================

    private function formatUrl(?string $url): ?string
    {
        if (empty($url)) {
            return null;
        }

        $url = trim($url);

        if (
            str_starts_with($url, "http://") ||
            str_starts_with($url, "https://")
        ) {
            return $url;
        }

        return $this->baseUrl . ltrim($url, "/");
    }

    // =====================================================
    // GET THUMBNAIL NAME FROM PDF NAME
    // =====================================================

    private function getThumbnailName(
        string $slidesUrl
    ): string {

        /*
         * Example:
         *
         * uploads/slides/introduction.pdf
         *          ↓
         * introduction.jpg
         *
         * uploads/slides/Chapter2.pdf
         *          ↓
         * chapter2.jpg
         */

        $fileName = pathinfo(
            $slidesUrl,
            PATHINFO_FILENAME
        );

        $fileName = strtolower($fileName);

        $fileName = str_replace(
            " ",
            "",
            $fileName
        );

        $fileName = preg_replace(
            "/[^a-z0-9_-]/",
            "",
            $fileName
        );

        return $fileName . ".jpg";
    }

    // =====================================================
    // FORMAT LESSON
    // =====================================================

    private function formatLesson(
        array $lesson
    ): array {

        // -------------------------------------------------
        // PDF / SLIDES URL
        // -------------------------------------------------

        $slidesUrl =
            $lesson["slides_url"] ?? null;

        $lesson["slides_url"] =
            $this->formatUrl($slidesUrl);

        $lesson["pdf_url"] =
            $lesson["slides_url"];

        // -------------------------------------------------
        // THUMBNAIL URL
        // -------------------------------------------------

        $lesson["thumbnail_url"] = null;

        if (!empty($slidesUrl)) {

            $thumbnailName =
                $this->getThumbnailName(
                    $slidesUrl
                );

            $lesson["thumbnail_url"] =
                $this->baseUrl .
                "uploads/thumbnails/" .
                $thumbnailName;
        }

        return $lesson;
    }

    // =====================================================
    // FORMAT RESOURCE
    // =====================================================

    private function formatResource(
        array $resource
    ): array {

        $resource["file_url"] =
            $this->formatUrl(
                $resource["file_url"] ?? null
            );

        return $resource;
    }

    // =====================================================
    // GET ALL LESSONS BY CERTIFICATION
    // =====================================================

    public function getByCertificationId(
        int $certificationId
    ): array {

        $sql = "
            SELECT
                id,
                certification_id,
                chapter,
                title,
                duration,
                type,
                video_url,
                lesson_content,
                slides_url,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_lessons
            WHERE certification_id = ?
            ORDER BY sort_order ASC, id ASC
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare lesson query."
            );
        }

        $stmt->bind_param(
            "i",
            $certificationId
        );

        if (!$stmt->execute()) {
            throw new Exception(
                "Failed to execute lesson query."
            );
        }

        $result =
            $stmt->get_result();

        $lessons = [];

        while (
            $row = $result->fetch_assoc()
        ) {
            $lessons[] =
                $this->formatLesson($row);
        }

        $stmt->close();

        return $lessons;
    }

    // =====================================================
    // GET SINGLE LESSON
    // =====================================================

    public function getById(
        int $id
    ): ?array {

        $sql = "
            SELECT
                id,
                certification_id,
                chapter,
                title,
                duration,
                type,
                video_url,
                lesson_content,
                slides_url,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_lessons
            WHERE id = ?
            LIMIT 1
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare lesson query."
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        if (!$stmt->execute()) {
            throw new Exception(
                "Failed to execute lesson query."
            );
        }

        $result =
            $stmt->get_result();

        $lesson =
            $result->fetch_assoc();

        $stmt->close();

        if (!$lesson) {
            return null;
        }

        return $this->formatLesson(
            $lesson
        );
    }

    // =====================================================
    // GET LESSON RESOURCES
    // =====================================================
    //
    // Used for Chapter 3:
    // Quality Management Principles
    //
    // Table:
    // lesson_resources
    //
    // Returns:
    // id
    // lesson_id
    // title
    // file_url
    // sort_order
    // status
    // created_at
    // =====================================================

    public function getResourcesByLessonId(
        int $lessonId
    ): array {

        $sql = "
            SELECT
                id,
                lesson_id,
                title,
                file_url,
                sort_order,
                status,
                created_at
            FROM lesson_resources
            WHERE lesson_id = ?
              AND status = 'active'
            ORDER BY
                sort_order ASC,
                id ASC
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare resources query."
            );
        }

        $stmt->bind_param(
            "i",
            $lessonId
        );

        if (!$stmt->execute()) {
            throw new Exception(
                "Failed to execute resources query."
            );
        }

        $result =
            $stmt->get_result();

        $resources = [];

        while (
            $row = $result->fetch_assoc()
        ) {
            $resources[] =
                $this->formatResource($row);
        }

        $stmt->close();

        return $resources;
    }

    // =====================================================
    // CREATE LESSON
    // =====================================================

    public function create(
        int $certificationId,
        string $chapter,
        string $title,
        ?string $duration,
        string $type,
        ?string $videoUrl,
        ?string $lessonContent,
        ?string $slidesUrl,
        int $sortOrder,
        string $status
    ): int {

        $sql = "
            INSERT INTO course_lessons
            (
                certification_id,
                chapter,
                title,
                duration,
                type,
                video_url,
                lesson_content,
                slides_url,
                sort_order,
                status
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare create lesson query."
            );
        }

        /*
         * 10 parameters:
         *
         * i = certification_id
         * s = chapter
         * s = title
         * s = duration
         * s = type
         * s = video_url
         * s = lesson_content
         * s = slides_url
         * i = sort_order
         * s = status
         */

        $stmt->bind_param(
            "isssssssis",
            $certificationId,
            $chapter,
            $title,
            $duration,
            $type,
            $videoUrl,
            $lessonContent,
            $slidesUrl,
            $sortOrder,
            $status
        );

        if (!$stmt->execute()) {
            throw new Exception(
                "Failed to create lesson."
            );
        }

        $id =
            $stmt->insert_id;

        $stmt->close();

        return $id;
    }

    // =====================================================
    // UPDATE LESSON
    // =====================================================

    public function update(
        int $id,
        int $certificationId,
        string $chapter,
        string $title,
        ?string $duration,
        string $type,
        ?string $videoUrl,
        ?string $lessonContent,
        ?string $slidesUrl,
        int $sortOrder,
        string $status
    ): bool {

        $sql = "
            UPDATE course_lessons
            SET
                certification_id = ?,
                chapter = ?,
                title = ?,
                duration = ?,
                type = ?,
                video_url = ?,
                lesson_content = ?,
                slides_url = ?,
                sort_order = ?,
                status = ?
            WHERE id = ?
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare update lesson query."
            );
        }

        /*
         * 11 parameters:
         *
         * i = certification_id
         * i = id
         * s x 7 = string fields
         * i = sort_order
         * s = status
         *
         * Actual SQL order:
         * certification_id
         * chapter
         * title
         * duration
         * type
         * video_url
         * lesson_content
         * slides_url
         * sort_order
         * status
         * id
         */

        $stmt->bind_param(
            "issssssisis",
            $certificationId,
            $chapter,
            $title,
            $duration,
            $type,
            $videoUrl,
            $lessonContent,
            $slidesUrl,
            $sortOrder,
            $status,
            $id
        );

        $success =
            $stmt->execute();

        $stmt->close();

        return $success;
    }

    // =====================================================
    // DELETE LESSON
    // =====================================================

    public function delete(
        int $id
    ): bool {

        $sql = "
            DELETE FROM course_lessons
            WHERE id = ?
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare delete lesson query."
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        $success =
            $stmt->execute();

        $stmt->close();

        return $success;
    }
}