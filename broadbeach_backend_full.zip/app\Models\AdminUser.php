<?php

class AdminUser
{
    private mysqli $db;


    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }


    // ==========================================
    // FIND ADMIN BY EMAIL
    // ==========================================

    public function findByEmail(
        string $email
    ): ?array {

        $sql = "
            SELECT
                id,
                name,
                email,
                password,
                role,
                status
            FROM admin_users
            WHERE email = ?
            LIMIT 1
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Unable to prepare admin query."
            );
        }


        $stmt->bind_param(
            "s",
            $email
        );


        $stmt->execute();


        $result =
            $stmt->get_result();


        if (
            $result->num_rows === 0
        ) {

            return null;
        }


        return $result->fetch_assoc();
    }


    // ==========================================
    // FIND ADMIN BY ID
    // ==========================================

    public function findById(
        int $id
    ): ?array {

        $sql = "
            SELECT
                id,
                name,
                email,
                role,
                status
            FROM admin_users
            WHERE id = ?
            LIMIT 1
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Unable to prepare admin query."
            );
        }


        $stmt->bind_param(
            "i",
            $id
        );


        $stmt->execute();


        $result =
            $stmt->get_result();


        if (
            $result->num_rows === 0
        ) {

            return null;
        }


        return $result->fetch_assoc();
    }
}