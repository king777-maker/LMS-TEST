<?php

require_once __DIR__ . "/app/config/Database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $password = $_POST["password"] ?? "";

    if ($password === "") {

        $message = "Please enter a password.";

    } else {

        $email = "admin@broadbeachlearning.com";

        $hash = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $database = new Database();
        $db = $database->connect();

        $stmt = $db->prepare("
            UPDATE admin_users
            SET password = ?
            WHERE email = ?
        ");

        $stmt->bind_param(
            "ss",
            $hash,
            $email
        );

        $stmt->execute();

        if ($stmt->affected_rows >= 0) {

            // Verify immediately using the same password
            if (
                password_verify(
                    $password,
                    $hash
                )
            ) {

                $message =
                    "Password updated and verified successfully.";

            } else {

                $message =
                    "Password verification failed.";
            }

        } else {

            $message =
                "Admin account was not found.";
        }

        $stmt->close();
        $database->close();
    }
}
?>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title>Admin Password Setup</title>

</head>

<body>

    <h2>Broadbeach Learning - Admin Password</h2>

    <?php if ($message !== ""): ?>

        <p>
            <?= htmlspecialchars($message) ?>
        </p>

    <?php endif; ?>


    <form method="POST">

        <label>
            New Admin Password
        </label>

        <br><br>

        <input
            type="password"
            name="password"
            required
        >

        <br><br>

        <button type="submit">
            Update Password
        </button>

    </form>

</body>

</html>