<?php

class AdminCertificateController
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    /*
    |--------------------------------------------------------------------------
    | JSON RESPONSE
    |--------------------------------------------------------------------------
    */

    private function response(
        $success,
        $message,
        $data = null,
        $statusCode = 200
    ) {
        http_response_code($statusCode);

        header("Content-Type: application/json; charset=UTF-8");

        echo json_encode([
            "success" => $success,
            "status"  => $success,
            "message" => $message,
            "data"    => $data
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | GET JSON INPUT
    |--------------------------------------------------------------------------
    */

    private function getJsonInput()
    {
        $input = file_get_contents("php://input");

        if (!$input) {
            return [];
        }

        $data = json_decode($input, true);

        if (!is_array($data)) {
            return [];
        }

        return $data;
    }

    /*
    |--------------------------------------------------------------------------
    | GET ALL CERTIFICATE NUMBERS
    |
    | GET /api/admin/certificates
    |--------------------------------------------------------------------------
    */

    public function getAll()
    {
        try {

            $sql = "
                SELECT
                    id,
                    certificate_number,
                    status,
                    created_at,
                    updated_at
                FROM certificate_numbers
                ORDER BY id DESC
            ";

            $result = $this->db->query($sql);

            if (!$result) {

                $this->response(
                    false,
                    "Failed to fetch certificate numbers.",
                    null,
                    500
                );
            }

            $data = [];

            while ($row = $result->fetch_assoc()) {

                $row["id"] = (int) $row["id"];
                $row["status"] = (int) $row["status"];

                $data[] = $row;
            }

            $this->response(
                true,
                "Certificate numbers fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to fetch certificate numbers.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREATE CERTIFICATE NUMBER
    |
    | POST /api/admin/certificates
    |--------------------------------------------------------------------------
    */

    public function create()
    {
        try {

            $data = $this->getJsonInput();

            $certificateNumber =
                isset($data["certificate_number"])
                    ? trim($data["certificate_number"])
                    : "";

            /*
            |--------------------------------------------------------------------------
            | VALIDATION
            |--------------------------------------------------------------------------
            */

            if ($certificateNumber === "") {

                $this->response(
                    false,
                    "Certificate number is required.",
                    null,
                    400
                );
            }

            /*
            |--------------------------------------------------------------------------
            | LENGTH VALIDATION
            |--------------------------------------------------------------------------
            */

            if (strlen($certificateNumber) > 100) {

                $this->response(
                    false,
                    "Certificate number cannot exceed 100 characters.",
                    null,
                    400
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CHECK DUPLICATE
            |--------------------------------------------------------------------------
            */

            $checkSql = "
                SELECT id
                FROM certificate_numbers
                WHERE certificate_number = ?
                LIMIT 1
            ";

            $checkStmt = $this->db->prepare($checkSql);

            if (!$checkStmt) {

                $this->response(
                    false,
                    "Failed to prepare duplicate check.",
                    null,
                    500
                );
            }

            $checkStmt->bind_param(
                "s",
                $certificateNumber
            );

            $checkStmt->execute();

            $checkResult = $checkStmt->get_result();

            if ($checkResult->num_rows > 0) {

                $existing =
                    $checkResult->fetch_assoc();

                $checkStmt->close();

                $this->response(
                    false,
                    "Certificate number already exists.",
                    [
                        "id" =>
                            (int) $existing["id"]
                    ],
                    409
                );
            }

            $checkStmt->close();

            /*
            |--------------------------------------------------------------------------
            | INSERT
            |--------------------------------------------------------------------------
            */

            $sql = "
                INSERT INTO certificate_numbers
                (
                    certificate_number,
                    status
                )
                VALUES
                (
                    ?,
                    1
                )
            ";

            $stmt = $this->db->prepare($sql);

            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare certificate insert.",
                    null,
                    500
                );
            }

            $stmt->bind_param(
                "s",
                $certificateNumber
            );

            if (!$stmt->execute()) {

                $error = $stmt->error;

                $stmt->close();

                $this->response(
                    false,
                    "Failed to save certificate number.",
                    [
                        "error" => $error
                    ],
                    500
                );
            }

            $newId = $stmt->insert_id;

            $stmt->close();

            /*
            |--------------------------------------------------------------------------
            | SUCCESS
            |--------------------------------------------------------------------------
            */

            $this->response(
                true,
                "Certificate number saved successfully.",
                [
                    "id" => $newId,
                    "certificate_number" =>
                        $certificateNumber
                ],
                201
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to save certificate number.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE CERTIFICATE NUMBER
    |
    | DELETE /api/admin/certificates/1
    |--------------------------------------------------------------------------
    */

    public function delete($id = null)
    {
        try {

            if ($id === null) {

                $id =
                    isset($_GET["id"])
                        ? (int) $_GET["id"]
                        : 0;
            }

            $id = (int) $id;

            if ($id <= 0) {

                $this->response(
                    false,
                    "Valid certificate ID is required.",
                    null,
                    400
                );
            }

            $sql = "
                DELETE FROM certificate_numbers
                WHERE id = ?
            ";

            $stmt = $this->db->prepare($sql);

            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare delete query.",
                    null,
                    500
                );
            }

            $stmt->bind_param(
                "i",
                $id
            );

            if (!$stmt->execute()) {

                $error = $stmt->error;

                $stmt->close();

                $this->response(
                    false,
                    "Failed to delete certificate number.",
                    [
                        "error" => $error
                    ],
                    500
                );
            }

            if ($stmt->affected_rows === 0) {

                $stmt->close();

                $this->response(
                    false,
                    "Certificate number not found.",
                    null,
                    404
                );
            }

            $stmt->close();

            $this->response(
                true,
                "Certificate number deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to delete certificate number.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }
}