<?php

require_once __DIR__ . "/../Models/Lesson.php";


class LessonController
{
    private Lesson $lesson;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->lesson =
            new Lesson($db);
    }


    // =====================================================
    // GET LESSONS BY CERTIFICATION
    // GET /api/admin/course-lessons?certification_id=1
    // =====================================================

    public function getByCertification(): void
    {
        $certificationId =
            isset($_GET["certification_id"])
                ? (int) $_GET["certification_id"]
                : 0;


        if ($certificationId <= 0) {

            $this->response(
                false,
                "Certification ID is required.",
                [],
                422
            );

            return;
        }


        try {

            $lessons =
                $this->lesson
                    ->getByCertificationId(
                        $certificationId
                    );


            $this->response(
                true,
                "Lessons fetched successfully.",
                $lessons
            );

        } catch (Throwable $error) {

            error_log(
                "GET LESSONS ERROR: " .
                $error->getMessage()
            );


            $this->response(
                false,
                "Unable to fetch lessons.",
                [],
                500
            );
        }
    }


    // =====================================================
    // GET LESSON RESOURCES
    // GET /api/lesson-resources?lesson_id=3
    // =====================================================

    public function getResources(): void
    {
        $lessonId =
            isset($_GET["lesson_id"])
                ? (int) $_GET["lesson_id"]
                : 0;

        if ($lessonId <= 0) {

            $this->response(
                false,
                "Lesson ID is required.",
                [],
                422
            );

            return;
        }

        try {

            $resources =
                $this->lesson
                    ->getResourcesByLessonId(
                        $lessonId
                    );

            $this->response(
                true,
                "Lesson resources fetched successfully.",
                $resources
            );

        } catch (Throwable $error) {

            error_log(
                "GET LESSON RESOURCES ERROR: " .
                $error->getMessage()
            );

            $this->response(
                false,
                "Unable to fetch lesson resources.",
                [],
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE LESSON
    // GET /api/admin/course-lesson?id=1
    // =====================================================

    public function getOne(): void
    {
        $id =
            isset($_GET["id"])
                ? (int) $_GET["id"]
                : 0;


        if ($id <= 0) {

            $this->response(
                false,
                "Lesson ID is required.",
                [],
                422
            );

            return;
        }


        try {

            $lesson =
                $this->lesson
                    ->getById($id);


            if (!$lesson) {

                $this->response(
                    false,
                    "Lesson not found.",
                    [],
                    404
                );

                return;
            }


            $this->response(
                true,
                "Lesson fetched successfully.",
                $lesson
            );

        } catch (Throwable $error) {

            error_log(
                "GET SINGLE LESSON ERROR: " .
                $error->getMessage()
            );


            $this->response(
                false,
                "Unable to fetch lesson.",
                [],
                500
            );
        }
    }


    // =====================================================
    // CREATE LESSON
    // POST /api/admin/course-lessons
    // =====================================================

    public function create(): void
    {
        $input =
            json_decode(
                file_get_contents("php://input"),
                true
            );


        if (!is_array($input)) {

            $this->response(
                false,
                "Invalid request data.",
                [],
                400
            );

            return;
        }


        $certificationId =
            (int) ($input["certification_id"] ?? 0);

        $chapter =
            trim(
                $input["chapter"] ?? ""
            );

        $title =
            trim(
                $input["title"] ?? ""
            );

        $duration =
            isset($input["duration"])
                ? trim($input["duration"])
                : null;

        $type =
            trim(
                $input["type"] ?? "lesson"
            );

        $videoUrl =
            isset($input["video_url"])
                ? trim($input["video_url"])
                : null;

        $lessonContent =
            isset($input["lesson_content"])
                ? $input["lesson_content"]
                : null;

        $slidesUrl =
            isset($input["slides_url"])
                ? trim($input["slides_url"])
                : null;

        $sortOrder =
            (int) ($input["sort_order"] ?? 0);

        $status =
            trim(
                $input["status"] ?? "active"
            );


        // =================================================
        // VALIDATION
        // =================================================

        if ($certificationId <= 0) {

            $this->response(
                false,
                "Certification ID is required.",
                [],
                422
            );

            return;
        }


        if ($chapter === "") {

            $this->response(
                false,
                "Chapter is required.",
                [],
                422
            );

            return;
        }


        if ($title === "") {

            $this->response(
                false,
                "Title is required.",
                [],
                422
            );

            return;
        }


        if (
            !in_array(
                $type,
                [
                    "lesson",
                    "assessment",
                    "certificate"
                ],
                true
            )
        ) {

            $this->response(
                false,
                "Invalid lesson type.",
                [],
                422
            );

            return;
        }


        if (
            !in_array(
                $status,
                [
                    "active",
                    "inactive"
                ],
                true
            )
        ) {

            $this->response(
                false,
                "Invalid status.",
                [],
                422
            );

            return;
        }


        try {

            $id =
                $this->lesson->create(
                    $certificationId,
                    $chapter,
                    $title,
                    $duration,
                    $type,
                    $videoUrl,
                    $lessonContent,
                    $slidesUrl,
                    $sortOrder,
                    $status
                );


            $lesson =
                $this->lesson
                    ->getById($id);


            $this->response(
                true,
                "Lesson created successfully.",
                $lesson,
                201
            );

        } catch (Throwable $error) {

            error_log(
                "CREATE LESSON ERROR: " .
                $error->getMessage()
            );


            $this->response(
                false,
                "Unable to create lesson.",
                [],
                500
            );
        }
    }


    // =====================================================
    // UPDATE LESSON
    // PUT /api/admin/course-lessons
    // =====================================================

    public function update(): void
    {
        $input =
            json_decode(
                file_get_contents("php://input"),
                true
            );


        if (!is_array($input)) {

            $this->response(
                false,
                "Invalid request data.",
                [],
                400
            );

            return;
        }


        $id =
            (int) ($input["id"] ?? 0);

        $certificationId =
            (int) ($input["certification_id"] ?? 0);

        $chapter =
            trim(
                $input["chapter"] ?? ""
            );

        $title =
            trim(
                $input["title"] ?? ""
            );

        $duration =
            isset($input["duration"])
                ? trim($input["duration"])
                : null;

        $type =
            trim(
                $input["type"] ?? "lesson"
            );

        $videoUrl =
            isset($input["video_url"])
                ? trim($input["video_url"])
                : null;

        $lessonContent =
            isset($input["lesson_content"])
                ? $input["lesson_content"]
                : null;

        $slidesUrl =
            isset($input["slides_url"])
                ? trim($input["slides_url"])
                : null;

        $sortOrder =
            (int) ($input["sort_order"] ?? 0);

        $status =
            trim(
                $input["status"] ?? "active"
            );


        // =================================================
        // VALIDATION
        // =================================================

        if ($id <= 0) {

            $this->response(
                false,
                "Lesson ID is required.",
                [],
                422
            );

            return;
        }


        if ($certificationId <= 0) {

            $this->response(
                false,
                "Certification ID is required.",
                [],
                422
            );

            return;
        }


        if ($chapter === "") {

            $this->response(
                false,
                "Chapter is required.",
                [],
                422
            );

            return;
        }


        if ($title === "") {

            $this->response(
                false,
                "Title is required.",
                [],
                422
            );

            return;
        }


        if (
            !in_array(
                $type,
                [
                    "lesson",
                    "assessment",
                    "certificate"
                ],
                true
            )
        ) {

            $this->response(
                false,
                "Invalid lesson type.",
                [],
                422
            );

            return;
        }


        if (
            !in_array(
                $status,
                [
                    "active",
                    "inactive"
                ],
                true
            )
        ) {

            $this->response(
                false,
                "Invalid status.",
                [],
                422
            );

            return;
        }


        try {

            $existing =
                $this->lesson
                    ->getById($id);


            if (!$existing) {

                $this->response(
                    false,
                    "Lesson not found.",
                    [],
                    404
                );

                return;
            }


            $updated =
                $this->lesson->update(
                    $id,
                    $certificationId,
                    $chapter,
                    $title,
                    $duration,
                    $type,
                    $videoUrl,
                    $lessonContent,
                    $slidesUrl,
                    $sortOrder,
                    $status
                );


            if (!$updated) {

                throw new Exception(
                    "Lesson update failed."
                );
            }


            $lesson =
                $this->lesson
                    ->getById($id);


            $this->response(
                true,
                "Lesson updated successfully.",
                $lesson
            );

        } catch (Throwable $error) {

            error_log(
                "UPDATE LESSON ERROR: " .
                $error->getMessage()
            );


            $this->response(
                false,
                "Unable to update lesson.",
                [],
                500
            );
        }
    }


    // =====================================================
    // DELETE LESSON
    // DELETE /api/admin/course-lessons
    // =====================================================

    public function delete(): void
    {
        $input =
            json_decode(
                file_get_contents("php://input"),
                true
            );


        $id =
            (int) (
                $input["id"]
                ?? $_GET["id"]
                ?? 0
            );


        if ($id <= 0) {

            $this->response(
                false,
                "Lesson ID is required.",
                [],
                422
            );

            return;
        }


        try {

            $existing =
                $this->lesson
                    ->getById($id);


            if (!$existing) {

                $this->response(
                    false,
                    "Lesson not found.",
                    [],
                    404
                );

                return;
            }


            $deleted =
                $this->lesson
                    ->delete($id);


            if (!$deleted) {

                throw new Exception(
                    "Lesson deletion failed."
                );
            }


            $this->response(
                true,
                "Lesson deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $error) {

            error_log(
                "DELETE LESSON ERROR: " .
                $error->getMessage()
            );


            $this->response(
                false,
                "Unable to delete lesson.",
                [],
                500
            );
        }
    }


    // =====================================================
    // RESPONSE
    // =====================================================

    private function response(
        bool $success,
        string $message,
        mixed $data = null,
        int $status = 200
    ): void {

        http_response_code($status);


        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        $response = [
            "success" => $success,
            "message" => $message,
        ];


        if ($data !== null) {

            $response["data"] =
                $data;
        }


        echo json_encode(
            $response
        );

        exit;
    }
}