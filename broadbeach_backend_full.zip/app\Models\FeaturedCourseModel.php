<?php

class FeaturedCourseModel
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // GET ALL FEATURED COURSES
    public function getAllFeaturedCourses(): array
    {
        $sql = "
            SELECT
                id,
                title,
                description,
                level,
                duration,
                rating,
                students,
                image,
                price,
                status,
                sort_order,
                created_at,
                updated_at
            FROM featured_courses
            WHERE status = 'active'
            ORDER BY sort_order ASC, id ASC
        ";

        $result = $this->conn->query($sql);

        if (!$result) {
            throw new Exception(
                "Get featured courses error: " . $this->conn->error
            );
        }

        $courses = [];

        while ($row = $result->fetch_assoc()) {
            $row["id"] = (int) $row["id"];
            $row["rating"] = (float) $row["rating"];
            $row["students"] = (int) $row["students"];
            $row["price"] = (float) $row["price"];
            $row["sort_order"] = (int) $row["sort_order"];

            $courses[] = $row;
        }

        return $courses;
    }

    // GET SINGLE FEATURED COURSE BY ID
    public function getFeaturedCourseById(int $id): ?array
    {
        $sql = "
            SELECT
                id,
                title,
                description,
                level,
                duration,
                rating,
                students,
                image,
                price,
                status,
                sort_order,
                created_at,
                updated_at
            FROM featured_courses
            WHERE id = ?
            AND status = 'active'
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Prepare featured course error: " . $this->conn->error
            );
        }

        $stmt->bind_param("i", $id);

        if (!$stmt->execute()) {
            throw new Exception(
                "Execute featured course error: " . $stmt->error
            );
        }

        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;

        $stmt->close();

        if (!$row) {
            return null;
        }

        $row["id"] = (int) $row["id"];
        $row["rating"] = (float) $row["rating"];
        $row["students"] = (int) $row["students"];
        $row["price"] = (float) $row["price"];
        $row["sort_order"] = (int) $row["sort_order"];

        return $row;
    }

    // GET SINGLE FEATURED COURSE BY SLUG
    public function getFeaturedCourseBySlug(string $slug): ?array
    {
        $sql = "
            SELECT
                id,
                title,
                description,
                level,
                duration,
                rating,
                students,
                image,
                price,
                status,
                sort_order,
                created_at,
                updated_at
            FROM featured_courses
            WHERE slug = ?
            AND status = 'active'
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Prepare featured course slug error: " . $this->conn->error
            );
        }

        $stmt->bind_param("s", $slug);

        if (!$stmt->execute()) {
            throw new Exception(
                "Execute featured course slug error: " . $stmt->error
            );
        }

        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;

        $stmt->close();

        if (!$row) {
            return null;
        }

        $row["id"] = (int) $row["id"];
        $row["rating"] = (float) $row["rating"];
        $row["students"] = (int) $row["students"];
        $row["price"] = (float) $row["price"];
        $row["sort_order"] = (int) $row["sort_order"];

        return $row;
    }
}