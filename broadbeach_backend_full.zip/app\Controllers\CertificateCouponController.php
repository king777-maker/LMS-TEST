<?php

require_once __DIR__
    . "/../Models/CertificateCoupon.php";


class CertificateCouponController
{
    private CertificateCoupon $coupon;


    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct(
        mysqli $db
    ) {

        $this->coupon =
            new CertificateCoupon($db);
    }


    // ==========================================
    // REDEEM CERTIFICATE COUPON
    // ==========================================

    public function redeem()
    {
        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        // =====================================
        // SESSION
        // =====================================

        if (
            session_status()
            === PHP_SESSION_NONE
        ) {

            session_start();
        }


        // =====================================
        // READ JSON
        // =====================================

        $rawData =
            file_get_contents(
                "php://input"
            );


        $data =
            json_decode(
                $rawData,
                true
            );


        if (!is_array($data)) {

            http_response_code(400);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Invalid request data."
            ]);


            return;
        }


        // =====================================
        // CODE
        // =====================================

        $code =
            strtoupper(
                trim(
                    $data["code"] ?? ""
                )
            );


        // =====================================
        // CERTIFICATION ID
        // =====================================

        $certificationId =
            (int) (
                $data["certification_id"]
                ?? 0
            );


        // =====================================
        // USER ID
        // =====================================

        $userId = 0;


        // PHP session
        if (
            isset(
                $_SESSION["user_id"]
            )
        ) {

            $userId =
                (int)
                $_SESSION["user_id"];
        }


        // Alternative session
        else if (
            isset(
                $_SESSION["user"]["id"]
            )
        ) {

            $userId =
                (int)
                $_SESSION["user"]["id"];
        }


        // Alternative session
        else if (
            isset(
                $_SESSION["id"]
            )
        ) {

            $userId =
                (int)
                $_SESSION["id"];
        }


        // React fallback
        else if (
            isset(
                $data["user_id"]
            )
        ) {

            $userId =
                (int)
                $data["user_id"];
        }


        // =====================================
        // LOGIN CHECK
        // =====================================

        if ($userId <= 0) {

            http_response_code(401);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Please login before using the certificate code."
            ]);


            return;
        }


        // =====================================
        // CODE VALIDATION
        // =====================================

        if (empty($code)) {

            http_response_code(422);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Please enter a certificate access code."
            ]);


            return;
        }


        // =====================================
        // CERTIFICATION VALIDATION
        // =====================================

        if ($certificationId <= 0) {

            http_response_code(422);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Certification ID is required."
            ]);


            return;
        }


        // =====================================
        // FIND COUPON
        // =====================================

        $coupon =
            $this->coupon
                ->findValidCoupon(
                    $code,
                    $certificationId
                );


        if (!$coupon) {

            http_response_code(404);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Invalid or expired certificate code."
            ]);


            return;
        }


        // =====================================
        // MAX USE
        // =====================================

        if (
            $coupon["max_uses"] !== null
            &&
            (int)
            $coupon["max_uses"] > 0
            &&
            (int)
            $coupon["used_count"]
            >=
            (int)
            $coupon["max_uses"]
        ) {

            http_response_code(409);


            echo json_encode([
                "success" => false,

                "message" =>
                    "This certificate code has reached its usage limit."
            ]);


            return;
        }


        // =====================================
        // ALREADY REDEEMED
        // =====================================

        $alreadyRedeemed =
            $this->coupon
                ->alreadyRedeemed(
                    (int) $coupon["id"],
                    $userId,
                    $certificationId
                );


        if ($alreadyRedeemed) {

            echo json_encode([

                "success" => true,

                "certificate_access" =>
                    true,

                "already_redeemed" =>
                    true,

                "user_id" =>
                    $userId,

                "certification_id" =>
                    $certificationId,

                "message" =>
                    "Certificate access is already enabled."
            ]);


            return;
        }


        // =====================================
        // REDEEM
        // =====================================

        $redeemed =
            $this->coupon
                ->redeem(
                    (int) $coupon["id"],
                    $userId,
                    $certificationId
                );


        if (!$redeemed) {

            http_response_code(409);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Unable to verify certificate code. Please try again."
            ]);


            return;
        }


        // =====================================
        // SUCCESS
        // =====================================

        $certNumber = "BOA" . $certificationId . $userId . rand(100, 999);

        http_response_code(200);

        echo json_encode([
            "success" => true,
            "certificate_access" => true,
            "already_redeemed" => false,
            "exam_bypassed" => true,
            "certificate_number" => $certNumber,
            "user_id" => $userId,
            "certification_id" => $certificationId,
            "message" => "Certificate access code verified successfully. Exam requirement bypassed and certificate issued."
        ]);

        return;
    }
}