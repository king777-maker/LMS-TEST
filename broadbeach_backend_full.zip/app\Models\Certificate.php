<?php


require_once __DIR__
    . "/../Query.php";


class Certificate
{
    private mysqli $db;

    private Query $query;

    private string $table =
        "free_certifications";


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(
        mysqli $db
    ) {

        $this->db =
            $db;


        $this->query =
            new Query($db);
    }


    // =====================================================
    // GET ALL ACTIVE FREE CERTIFICATIONS
    // =====================================================

    public function getAll(): array
    {

        return $this->query
            ->getWhere(

                $this->table,

                "status",

                "active",

                "sort_order",

                "ASC"
            );
    }


    // =====================================================
    // GET FREE CERTIFICATION BY ID
    // =====================================================

    public function getById(
        int $id
    ): ?array {

        $sql = "
            SELECT *
            FROM `{$this->table}`
            WHERE `id` = ?
            AND `status` = ?
            LIMIT 1
        ";


        return $this->query
            ->selectOne(

                $sql,

                "is",

                [
                    $id,
                    "active"
                ]
            );
    }


    // =====================================================
    // FIND EXISTING GENERATED CERTIFICATE
    // =====================================================

    public function findExisting(
        int $userId,
        int $certificationId
    ): ?array {

        $sql = "
            SELECT

                c.id,

                c.user_id,

                c.certification_id,

                c.student_name,

                c.certificate_number,

                c.score,

                c.total_questions,

                c.percentage,

                c.pdf_path,

                c.issued_at,

                c.created_at,

                c.updated_at,

                fc.name
                    AS certification_name

            FROM certificates AS c


            LEFT JOIN free_certifications AS fc

                ON fc.id =
                    c.certification_id


            WHERE c.user_id = ?

            AND c.certification_id = ?


            ORDER BY c.id DESC


            LIMIT 1
        ";


        $stmt =
            $this->db
                ->prepare($sql);


        if (!$stmt) {

            throw new Exception(

                "Find Certificate Prepare Error: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "ii",
            $userId,
            $certificationId
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;


            $stmt->close();


            throw new Exception(
                "Find Certificate Execute Error: "
                . $error
            );
        }


        $result =
            $stmt->get_result();


        $certificate =
            $result->fetch_assoc();


        $stmt->close();


        return
            $certificate
            ?: null;
    }


    // =====================================================
    // GENERATE CERTIFICATE NUMBER
    //
    // BOA10101
    // BOA10102
    // BOA10103
    // =====================================================

    public function generateCertificateNumber(): string
    {

        $sql = "
            SELECT

                MAX(

                    CAST(

                        SUBSTRING(
                            certificate_number,
                            4
                        )

                        AS UNSIGNED
                    )

                ) AS last_number

            FROM certificates

            WHERE certificate_number

            REGEXP '^BOA[0-9]+$'
        ";


        $result =
            $this->db
                ->query($sql);


        if (!$result) {

            throw new Exception(

                "Certificate Number Query Error: "
                . $this->db->error
            );
        }


        $row =
            $result->fetch_assoc();


        // =========================================
        // NO CERTIFICATES YET
        // =========================================

        if (
            !$row
            ||
            $row["last_number"] === null
        ) {

            return "BOA10101";
        }


        // =========================================
        // NEXT NUMBER
        // =========================================

        $lastNumber =
            (int) 
            $row["last_number"];


        $nextNumber =
            $lastNumber + 1;


        return
            "BOA"
            . $nextNumber;
    }


    // =====================================================
    // CERTIFICATE NUMBER EXISTS
    // =====================================================

    public function certificateNumberExists(
        string $certificateNumber
    ): bool {

        $sql = "
            SELECT id

            FROM certificates

            WHERE certificate_number = ?

            LIMIT 1
        ";


        $stmt =
            $this->db
                ->prepare($sql);


        if (!$stmt) {

            throw new Exception(

                "Certificate Number Check Prepare Error: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "s",
            $certificateNumber
        );


        $stmt->execute();


        $result =
            $stmt->get_result();


        $exists =
            $result->num_rows > 0;


        $stmt->close();


        return $exists;
    }


    // =====================================================
// CREATE GENERATED CERTIFICATE
// =====================================================

    public function create(
        int $userId,
        int $certificationId,
        string $studentName,
        string $certificateNumber,
        int $score,
        int $totalQuestions,
        float $percentage,
        ?string $pdfPath = null
    ): int {

        try {

            // Start transaction
            $this->db->begin_transaction();


            // =================================================
            // 1. INSERT INTO certificates
            // =================================================

            $sql = "
            INSERT INTO certificates
            (
                user_id,
                certification_id,
                student_name,
                certificate_number,
                score,
                total_questions,
                percentage,
                pdf_path
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ";

            $stmt = $this->db->prepare($sql);

            if (!$stmt) {
                throw new Exception(
                    "Create Certificate Prepare Error: "
                    . $this->db->error
                );
            }

            $stmt->bind_param(
                "iissiids",
                $userId,
                $certificationId,
                $studentName,
                $certificateNumber,
                $score,
                $totalQuestions,
                $percentage,
                $pdfPath
            );

            if (!$stmt->execute()) {

                $error = $stmt->error;

                $stmt->close();

                throw new Exception(
                    "Create Certificate Error: " . $error
                );
            }

            $certificateId = (int) $stmt->insert_id;

            $stmt->close();


            // =================================================
            // 2. INSERT INTO certificate_numbers
            // =================================================

            $numberSql = "
            INSERT INTO certificate_numbers
            (
                certificate_number,
                status
            )
            VALUES (?, 1)
        ";

            $numberStmt = $this->db->prepare($numberSql);

            if (!$numberStmt) {
                throw new Exception(
                    "Certificate Number Prepare Error: "
                    . $this->db->error
                );
            }

            $numberStmt->bind_param(
                "s",
                $certificateNumber
            );

            if (!$numberStmt->execute()) {

                $error = $numberStmt->error;

                $numberStmt->close();

                throw new Exception(
                    "Certificate Number Insert Error: " . $error
                );
            }

            $numberStmt->close();


            // =================================================
            // 3. COMMIT
            // =================================================

            $this->db->commit();


            return $certificateId;


        } catch (Throwable $e) {

            // =================================================
            // ROLLBACK EVERYTHING
            // =================================================

            $this->db->rollback();

            throw $e;
        }
    }


    // =====================================================
    // GET GENERATED CERTIFICATE
    // =====================================================

    public function getGeneratedCertificate(
        int $id
    ): ?array {

        $sql = "
            SELECT

                c.id,

                c.user_id,

                c.certification_id,

                c.student_name,

                c.certificate_number,

                c.score,

                c.total_questions,

                c.percentage,

                c.pdf_path,

                c.issued_at,

                c.created_at,

                c.updated_at,

                fc.name
                    AS certification_name

            FROM certificates AS c


            LEFT JOIN free_certifications AS fc

                ON fc.id =
                    c.certification_id


            WHERE c.id = ?


            LIMIT 1
        ";


        $stmt =
            $this->db
                ->prepare($sql);


        if (!$stmt) {

            throw new Exception(

                "Get Certificate Prepare Error: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $id
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;


            $stmt->close();


            throw new Exception(

                "Get Certificate Execute Error: "
                . $error
            );
        }


        $result =
            $stmt->get_result();


        $certificate =
            $result->fetch_assoc();


        $stmt->close();


        return
            $certificate
            ?: null;
    }
}