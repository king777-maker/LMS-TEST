<?php

class Course
{
    private mysqli $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }


    // =====================================================
    // GET COURSE DETAILS BY SLUG
    // =====================================================

    public function getCourseBySlug(string $slug): ?array
    {
        $sql = "
            SELECT

                cmi.id,
                cmi.category_id,
                cmi.subcategory_id,
                cmi.name,
                cmi.slug,
                cmi.path,

                cd.short_description,
                cd.overview,
                cd.course_image,
                cd.duration,
                cd.level,
                cd.language,
                cd.certification,
                cd.learning_objectives,
                cd.course_content,
                cd.target_audience,
                cd.prerequisites,
                cd.benefits,
                cd.assessment,
                cd.certification_details,
                cd.meta_title,
                cd.meta_description

            FROM course_menu_items AS cmi

            INNER JOIN course_details AS cd
                ON cd.course_item_id = cmi.id

            WHERE cmi.slug = ?
            AND cd.status = 1

            LIMIT 1
        ";


        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare course query: " .
                $this->conn->error
            );
        }


        $stmt->bind_param(
            "s",
            $slug
        );


        $stmt->execute();


        $result = $stmt->get_result();


        if ($result->num_rows === 0) {

            $stmt->close();

            return null;
        }


        $course = $result->fetch_assoc();


        $stmt->close();


        // =================================================
        // CONVERT | SEPARATED DATABASE VALUES INTO ARRAYS
        // =================================================

        $arrayFields = [
            "learning_objectives",
            "course_content",
            "target_audience",
            "benefits"
        ];


        foreach ($arrayFields as $field) {

            if (!empty($course[$field])) {

                $course[$field] = array_values(
                    array_filter(
                        array_map(
                            "trim",
                            explode(
                                "|",
                                $course[$field]
                            )
                        )
                    )
                );

            } else {

                $course[$field] = [];

            }
        }


        return $course;
    }
}