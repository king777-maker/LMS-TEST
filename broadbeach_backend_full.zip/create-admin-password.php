<?php

$password = "broad_beach_admin_2026";

echo password_hash(
    $password,
    PASSWORD_DEFAULT
);