<?php

require_once __DIR__ . "/../Models/Menu.php";


class MenuController
{
    private Menu $menu;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->menu = new Menu($db);
    }


    // =====================================================
    // JSON RESPONSE
    // =====================================================

    private function response(
        bool $success,
        string $message,
        $data = null,
        int $statusCode = 200
    ): void {

        http_response_code($statusCode);

        header(
            "Content-Type: application/json; charset=UTF-8"
        );

        echo json_encode(
            [
                "success" => $success,
                "status" => $success,
                "message" => $message,
                "data" => $data
            ],
            JSON_UNESCAPED_UNICODE
        );

        exit;
    }


    // =====================================================
    // READ JSON BODY
    // =====================================================

    private function getBody(): array
    {
        $raw =
            file_get_contents("php://input");

        if (!$raw) {
            return [];
        }

        $data =
            json_decode($raw, true);

        if (!is_array($data)) {
            return [];
        }

        return $data;
    }


    // =====================================================
    // GET ID
    // =====================================================

    private function getId(
        array $data = [],
        string $queryKey = "id"
    ): int {

        $id = 0;


        if (isset($data["id"])) {

            $id =
                (int) $data["id"];
        }


        if (
            $id <= 0 &&
            isset($_GET[$queryKey])
        ) {

            $id =
                (int) $_GET[$queryKey];
        }


        return $id;
    }


    // =====================================================
    // GET HEADER MENU
    // =====================================================
    //
    // GET
    // /api/header-menu
    //
    // =====================================================

    public function headerMenu(): void
    {
        try {

            $data =
                $this->menu->getHeaderMenu();


            $this->response(
                true,
                "Header menu fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // CATEGORY
    // =====================================================


    // =====================================================
    // GET ALL CATEGORIES
    // =====================================================
    //
    // GET
    // /api/admin/menu-categories
    //
    // GET
    // /api/admin/course-menu-categories
    //
    // =====================================================

    public function getCategories(): void
    {
        try {

            $data =
                $this->menu->getAllCategories();


            $this->response(
                true,
                "Categories fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE CATEGORY
    // =====================================================
    //
    // GET
    // /api/admin/menu-category?id=24
    //
    // GET
    // /api/admin/course-menu-category?id=24
    //
    // =====================================================

    public function getCategory(): void
    {
        try {

            $id =
                $this->getId();


            if ($id <= 0) {

                $this->response(
                    false,
                    "Category ID is required.",
                    null,
                    422
                );
            }


            $category =
                $this->menu->getCategoryById(
                    $id
                );


            if (!$category) {

                $this->response(
                    false,
                    "Category not found.",
                    null,
                    404
                );
            }


            $this->response(
                true,
                "Category fetched successfully.",
                $category
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // CREATE CATEGORY
    // =====================================================
    //
    // POST
    // /api/admin/menu-categories
    //
    // POST
    // /api/admin/course-menu-categories
    //
    // =====================================================

    public function createCategory(): void
    {
        try {

            $data =
                $this->getBody();


            // -------------------------------------------------
            // VALIDATE NAME
            // -------------------------------------------------

            if (
                !isset($data["name"]) ||
                trim((string) $data["name"]) === ""
            ) {

                $this->response(
                    false,
                    "Category name is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CREATE
            // -------------------------------------------------

            $id =
                $this->menu->createCategory(
                    $data
                );


            if ((int) $id <= 0) {

                $this->response(
                    false,
                    "Category was not created.",
                    null,
                    500
                );
            }


            // -------------------------------------------------
            // GET CREATED CATEGORY
            // -------------------------------------------------

            $category =
                $this->menu->getCategoryById(
                    (int) $id
                );


            $this->response(
                true,
                "Category created successfully.",
                $category,
                201
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // UPDATE CATEGORY
    // =====================================================
    //
    // PUT
    // /api/admin/menu-categories
    //
    // PUT
    // /api/admin/course-menu-categories
    //
    // =====================================================

    public function updateCategory(): void
    {
        try {

            $data =
                $this->getBody();


            $id =
                $this->getId(
                    $data
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Category ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // VALIDATE NAME
            // -------------------------------------------------

            if (
                isset($data["name"]) &&
                trim((string) $data["name"]) === ""
            ) {

                $this->response(
                    false,
                    "Category name cannot be empty.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CHECK CATEGORY
            // -------------------------------------------------

            $existing =
                $this->menu->getCategoryById(
                    $id
                );


            if (!$existing) {

                $this->response(
                    false,
                    "Category not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // UPDATE
            // -------------------------------------------------

            $this->menu->updateCategory(
                $id,
                $data
            );


            // -------------------------------------------------
            // GET UPDATED CATEGORY
            // -------------------------------------------------

            $category =
                $this->menu->getCategoryById(
                    $id
                );


            $this->response(
                true,
                "Category updated successfully.",
                $category
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // DELETE CATEGORY
    // =====================================================
    //
    // DELETE
    // /api/admin/menu-categories
    //
    // DELETE
    // /api/admin/course-menu-categories
    //
    // BODY:
    //
    // {
    //     "id": 24
    // }
    //
    // =====================================================

    public function deleteCategory(): void
    {
        try {

            $data =
                $this->getBody();


            $id =
                $this->getId(
                    $data
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Category ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CHECK CATEGORY
            // -------------------------------------------------

            $existing =
                $this->menu->getCategoryById(
                    $id
                );


            if (!$existing) {

                $this->response(
                    false,
                    "Category not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // DELETE
            // -------------------------------------------------

            $this->menu->deleteCategory(
                $id
            );


            $this->response(
                true,
                "Category deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // SUBCATEGORY
    // =====================================================


    // =====================================================
    // GET ALL SUBCATEGORIES
    // =====================================================
    //
    // GET
    // /api/admin/menu-subcategories
    //
    // GET
    // /api/admin/menu-subcategories?category_id=24
    //
    // GET
    // /api/admin/course-menu-subcategories?category_id=24
    //
    // =====================================================

    public function getSubcategories(): void
    {
        try {

            $categoryId =
                isset($_GET["category_id"])
                ? (int) $_GET["category_id"]
                : 0;


            // -------------------------------------------------
            // CATEGORY FILTER
            // -------------------------------------------------

            if ($categoryId > 0) {

                $data =
                    $this->menu->getSubcategories(
                        $categoryId
                    );

            } else {

                // -------------------------------------------------
                // ALL SUBCATEGORIES
                // -------------------------------------------------

                $data =
                    $this->menu->getAllSubcategories();
            }


            $this->response(
                true,
                "Subcategories fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE SUBCATEGORY
    // =====================================================
    //
    // GET
    // /api/admin/menu-subcategory?id=28
    //
    // =====================================================

    public function getSubcategory(): void
    {
        try {

            $id =
                $this->getId();


            if ($id <= 0) {

                $this->response(
                    false,
                    "Subcategory ID is required.",
                    null,
                    422
                );
            }


            $subcategory =
                $this->menu->getSubcategoryById(
                    $id
                );


            if (!$subcategory) {

                $this->response(
                    false,
                    "Subcategory not found.",
                    null,
                    404
                );
            }


            $this->response(
                true,
                "Subcategory fetched successfully.",
                $subcategory
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // CREATE SUBCATEGORY
    // =====================================================
    //
    // POST
    // /api/admin/menu-subcategories
    //
    // POST
    // /api/admin/course-menu-subcategories
    //
    // =====================================================

    public function createSubcategory(): void
    {
        try {

            $data =
                $this->getBody();


            // -------------------------------------------------
            // CATEGORY ID
            // -------------------------------------------------

            if (
                !isset($data["category_id"]) ||
                (int) $data["category_id"] <= 0
            ) {

                $this->response(
                    false,
                    "Category ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // NAME
            // -------------------------------------------------

            if (
                !isset($data["name"]) ||
                trim((string) $data["name"]) === ""
            ) {

                $this->response(
                    false,
                    "Subcategory name is required.",
                    null,
                    422
                );
            }


            $categoryId =
                (int) $data["category_id"];


            // -------------------------------------------------
            // CHECK PARENT CATEGORY
            // -------------------------------------------------

            $category =
                $this->menu->getCategoryById(
                    $categoryId
                );


            if (!$category) {

                $this->response(
                    false,
                    "Parent category not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // CREATE
            // -------------------------------------------------

            $id =
                $this->menu->createSubcategory(
                    $data
                );


            if ((int) $id <= 0) {

                $this->response(
                    false,
                    "Subcategory was not created.",
                    null,
                    500
                );
            }


            // -------------------------------------------------
            // GET CREATED SUBCATEGORY
            // -------------------------------------------------

            $subcategory =
                $this->menu->getSubcategoryById(
                    (int) $id
                );


            $this->response(
                true,
                "Subcategory created successfully.",
                $subcategory,
                201
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // UPDATE SUBCATEGORY
    // =====================================================
    //
    // PUT
    // /api/admin/menu-subcategories
    //
    // PUT
    // /api/admin/course-menu-subcategories
    //
    // =====================================================

    public function updateSubcategory(): void
    {
        try {

            $data =
                $this->getBody();


            $id =
                $this->getId(
                    $data
                );


            // -------------------------------------------------
            // ID
            // -------------------------------------------------

            if ($id <= 0) {

                $this->response(
                    false,
                    "Subcategory ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // NAME
            // -------------------------------------------------

            if (
                isset($data["name"]) &&
                trim((string) $data["name"]) === ""
            ) {

                $this->response(
                    false,
                    "Subcategory name cannot be empty.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CATEGORY ID
            // -------------------------------------------------

            if (
                isset($data["category_id"]) &&
                (int) $data["category_id"] <= 0
            ) {

                $this->response(
                    false,
                    "Invalid category ID.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CHECK EXISTING SUBCATEGORY
            // -------------------------------------------------

            $existing =
                $this->menu->getSubcategoryById(
                    $id
                );


            if (!$existing) {

                $this->response(
                    false,
                    "Subcategory not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // CHECK NEW PARENT CATEGORY
            // -------------------------------------------------

            if (
                isset($data["category_id"]) &&
                (int) $data["category_id"] > 0
            ) {

                $category =
                    $this->menu->getCategoryById(
                        (int) $data["category_id"]
                    );


                if (!$category) {

                    $this->response(
                        false,
                        "Parent category not found.",
                        null,
                        404
                    );
                }
            }


            // -------------------------------------------------
            // UPDATE
            // -------------------------------------------------

            $this->menu->updateSubcategory(
                $id,
                $data
            );


            // -------------------------------------------------
            // GET UPDATED
            // -------------------------------------------------

            $subcategory =
                $this->menu->getSubcategoryById(
                    $id
                );


            $this->response(
                true,
                "Subcategory updated successfully.",
                $subcategory
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // DELETE SUBCATEGORY
    // =====================================================
    //
    // DELETE
    // /api/admin/menu-subcategories
    //
    // DELETE
    // /api/admin/course-menu-subcategories
    //
    // =====================================================

    public function deleteSubcategory(): void
    {
        try {

            $data =
                $this->getBody();


            $id =
                $this->getId(
                    $data
                );


            // -------------------------------------------------
            // ID
            // -------------------------------------------------

            if ($id <= 0) {

                $this->response(
                    false,
                    "Subcategory ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CHECK EXISTING
            // -------------------------------------------------

            $existing =
                $this->menu->getSubcategoryById(
                    $id
                );


            if (!$existing) {

                $this->response(
                    false,
                    "Subcategory not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // DELETE
            // -------------------------------------------------

            $this->menu->deleteSubcategory(
                $id
            );


            $this->response(
                true,
                "Subcategory deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // COURSE MENU ITEMS
    // =====================================================
    //
    // IMPORTANT:
    //
    // These methods work with:
    //
    // course_menu_items
    //
    // NOT:
    //
    // course_menu_subcategories
    //
    // =====================================================


    // =====================================================
    // GET ALL COURSE MENU ITEMS
    // =====================================================
    //
    // GET
    // /api/admin/course-menu-items
    //
    // Optional:
    //
    // /api/admin/course-menu-items?category_id=19
    //
    // /api/admin/course-menu-items?category_id=19&subcategory_id=5
    //
    // =====================================================


    // =====================================================
// PUBLIC PROFESSIONAL CERTIFICATIONS MENU
// =====================================================
//
// GET
// /api/professional-certifications-menu
//
// PUBLIC WEBSITE ONLY
// =====================================================

    public function professionalCertificationMenu(): void
    {
        try {

            $data =
                $this->menu
                    ->getPublicProfessionalCertificationMenu();


            $this->response(
                true,
                "Professional certifications menu fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }
    public function getCourseMenuItems(): void
    {
        try {

            // -------------------------------------------------
            // CATEGORY ID
            // -------------------------------------------------

            $categoryId = null;


            if (
                isset($_GET["category_id"]) &&
                $_GET["category_id"] !== ""
            ) {

                $categoryId =
                    (int) $_GET["category_id"];
            }


            // -------------------------------------------------
            // SUBCATEGORY ID
            // -------------------------------------------------

            $subcategoryId = null;


            if (
                isset($_GET["subcategory_id"]) &&
                $_GET["subcategory_id"] !== ""
            ) {

                $subcategoryId =
                    (int) $_GET["subcategory_id"];
            }


            // -------------------------------------------------
            // VALIDATE CATEGORY ID
            // -------------------------------------------------

            if (
                $categoryId !== null &&
                $categoryId <= 0
            ) {

                $this->response(
                    false,
                    "Invalid category ID.",
                    [],
                    422
                );
            }


            // -------------------------------------------------
            // VALIDATE SUBCATEGORY ID
            // -------------------------------------------------

            if (
                $subcategoryId !== null &&
                $subcategoryId <= 0
            ) {

                $this->response(
                    false,
                    "Invalid subcategory ID.",
                    [],
                    422
                );
            }


            // -------------------------------------------------
            // FETCH COURSE MENU ITEMS
            // -------------------------------------------------

            $data =
                $this->menu->getCourseMenuItems(
                    $categoryId,
                    $subcategoryId
                );


            // -------------------------------------------------
            // SUCCESS RESPONSE
            // -------------------------------------------------

            $this->response(
                true,
                "Course menu items fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                [],
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE COURSE MENU ITEM
    // =====================================================
    //
    // GET
    // /api/admin/course-menu-item?id=453
    //
    // =====================================================

    public function getCourseMenuItem(): void
    {
        try {

            $id =
                $this->getId();


            if ($id <= 0) {

                $this->response(
                    false,
                    "Menu item ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // GET ITEM
            // -------------------------------------------------

            $item =
                $this->menu->getCourseMenuItemById(
                    $id
                );


            if (!$item) {

                $this->response(
                    false,
                    "Course menu item not found.",
                    null,
                    404
                );
            }


            $this->response(
                true,
                "Course menu item fetched successfully.",
                $item
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // CREATE COURSE MENU ITEM
    // =====================================================
    //
    // POST
    // /api/admin/course-menu-items
    //
    // BODY:
    //
    // {
    //     "category_id": 19,
    //     "subcategory_id": null,
    //     "name": "History",
    //     "slug": "history",
    //     "path": "/about/history",
    //     "sort_order": 1,
    //     "status": "active"
    // }
    //
    // =====================================================

    public function createCourseMenuItem(): void
    {
        try {

            $data =
                $this->getBody();


            // -------------------------------------------------
            // CATEGORY ID
            // -------------------------------------------------

            if (
                !isset($data["category_id"]) ||
                (int) $data["category_id"] <= 0
            ) {

                $this->response(
                    false,
                    "Category ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // NAME
            // -------------------------------------------------

            if (
                !isset($data["name"]) ||
                trim((string) $data["name"]) === ""
            ) {

                $this->response(
                    false,
                    "Menu item name is required.",
                    null,
                    422
                );
            }


            $categoryId =
                (int) $data["category_id"];


            // -------------------------------------------------
            // CHECK CATEGORY
            // -------------------------------------------------

            $category =
                $this->menu->getCategoryById(
                    $categoryId
                );


            if (!$category) {

                $this->response(
                    false,
                    "Parent category not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // CREATE
            // -------------------------------------------------

            $id =
                $this->menu->createCourseMenuItem(
                    $data
                );


            if ((int) $id <= 0) {

                $this->response(
                    false,
                    "Course menu item was not created.",
                    null,
                    500
                );
            }


            // -------------------------------------------------
            // GET CREATED ITEM
            // -------------------------------------------------

            $item =
                $this->menu->getCourseMenuItemById(
                    (int) $id
                );


            $this->response(
                true,
                "Course menu item created successfully.",
                $item,
                201
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // UPDATE COURSE MENU ITEM
    // =====================================================
    //
    // PUT
    // /api/admin/course-menu-items
    //
    // BODY:
    //
    // {
    //     "id": 453,
    //     "category_id": 19,
    //     "subcategory_id": null,
    //     "name": "Our History",
    //     "slug": "our-history",
    //     "path": "/about/history",
    //     "sort_order": 1,
    //     "status": "active"
    // }
    //
    // =====================================================

    public function updateCourseMenuItem(): void
    {
        try {

            $data =
                $this->getBody();


            // -------------------------------------------------
            // ID
            // -------------------------------------------------

            $id =
                $this->getId(
                    $data
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Menu item ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CHECK EXISTING ITEM
            // -------------------------------------------------

            $existing =
                $this->menu->getCourseMenuItemById(
                    $id
                );


            if (!$existing) {

                $this->response(
                    false,
                    "Course menu item not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // CATEGORY
            // -------------------------------------------------

            if (
                isset($data["category_id"]) &&
                (int) $data["category_id"] <= 0
            ) {

                $this->response(
                    false,
                    "Invalid category ID.",
                    null,
                    422
                );
            }


            if (
                isset($data["category_id"])
            ) {

                $category =
                    $this->menu->getCategoryById(
                        (int) $data["category_id"]
                    );


                if (!$category) {

                    $this->response(
                        false,
                        "Parent category not found.",
                        null,
                        404
                    );
                }
            }


            // -------------------------------------------------
            // NAME
            // -------------------------------------------------

            if (
                isset($data["name"]) &&
                trim((string) $data["name"]) === ""
            ) {

                $this->response(
                    false,
                    "Menu item name cannot be empty.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // UPDATE
            // -------------------------------------------------

            $this->menu->updateCourseMenuItem(
                $id,
                $data
            );


            // -------------------------------------------------
            // GET UPDATED ITEM
            // -------------------------------------------------

            $item =
                $this->menu->getCourseMenuItemById(
                    $id
                );


            $this->response(
                true,
                "Course menu item updated successfully.",
                $item
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }


    // =====================================================
    // DELETE COURSE MENU ITEM
    // =====================================================
    //
    // DELETE
    // /api/admin/course-menu-items
    //
    // BODY:
    //
    // {
    //     "id": 453
    // }
    //
    // =====================================================

    public function deleteCourseMenuItem(): void
    {
        try {

            $data =
                $this->getBody();


            // -------------------------------------------------
            // ID
            // -------------------------------------------------

            $id =
                $this->getId(
                    $data
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Menu item ID is required.",
                    null,
                    422
                );
            }


            // -------------------------------------------------
            // CHECK EXISTING ITEM
            // -------------------------------------------------

            $existing =
                $this->menu->getCourseMenuItemById(
                    $id
                );


            if (!$existing) {

                $this->response(
                    false,
                    "Course menu item not found.",
                    null,
                    404
                );
            }


            // -------------------------------------------------
            // DELETE
            // -------------------------------------------------

            $deleted =
                $this->menu->deleteCourseMenuItem(
                    $id
                );


            if (!$deleted) {

                $this->response(
                    false,
                    "Course menu item was not deleted.",
                    null,
                    500
                );
            }


            $this->response(
                true,
                "Course menu item deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                $e->getMessage(),
                null,
                422
            );
        }
    }

    public function getMenuItems()
    {
        try {

            $categoryId =
                isset($_GET["category_id"])
                ? (int) $_GET["category_id"]
                : 0;

            if ($categoryId <= 0) {

                http_response_code(400);

                echo json_encode([
                    "success" => false,
                    "status" => false,
                    "message" =>
                        "category_id is required",
                    "data" => []
                ]);

                return;
            }


            $items =
                $this->menuModel
                    ->getPublicMenuItemsByCategory(
                        $categoryId
                    );


            echo json_encode([
                "success" => true,
                "status" => true,
                "message" =>
                    "Course menu items fetched successfully.",
                "data" => $items
            ]);

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "success" => false,
                "status" => false,
                "message" => $e->getMessage(),
                "data" => []
            ]);
        }
    }
}