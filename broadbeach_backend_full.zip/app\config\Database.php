<?php

require_once __DIR__ . "/config.php";


class Database
{
    private string $host;

    private string $username;

    private string $password;

    private string $database;

    private int $port;

    private ?mysqli $conn = null;


    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct()
    {
        $this->host =
            DB_HOST;

        $this->username =
            DB_USER;

        $this->password =
            DB_PASSWORD;

        $this->database =
            DB_NAME;

        $this->port =
            DB_PORT;
    }


    // ==========================================
    // CONNECT
    // ==========================================

    public function connect(): mysqli
    {
        if ($this->conn !== null) {

            return $this->conn;

        }


        $this->conn =
            new mysqli(
                $this->host,
                $this->username,
                $this->password,
                $this->database,
                $this->port
            );


        if (
            $this->conn->connect_error
        ) {

            throw new Exception(
                "Database connection failed: "
                . $this->conn->connect_error
            );

        }


        $this->conn->set_charset(
            "utf8mb4"
        );


        return $this->conn;
    }


    // ==========================================
    // CLOSE
    // ==========================================

    public function close(): void
    {
        if ($this->conn !== null) {

            $this->conn->close();

            $this->conn = null;

        }
    }
}