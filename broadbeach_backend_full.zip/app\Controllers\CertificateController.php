<?php


require_once __DIR__
    . "/../Models/Certificate.php";


class CertificateController
{
    private mysqli $db;

    private Certificate $certificate;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(
        mysqli $db
    ) {

        $this->db =
            $db;

        $this->certificate =
            new Certificate($db);
    }


    // =====================================================
    // GET ALL CERTIFICATIONS
    // =====================================================

    public function getAll(): void
    {

        try {

            $certificates =
                $this->certificate
                    ->getAll();


            $this->response(
                true,
                "Certifications fetched successfully.",
                $certificates
            );


        } catch (Throwable $e) {


            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // GET CERTIFICATION BY ID
    // =====================================================

    public function getById(): void
    {

        try {

            $id =
                isset($_GET["id"])
                    ? (int) $_GET["id"]
                    : 0;


            if ($id <= 0) {

                $this->response(
                    false,
                    "Certification ID is required.",
                    null,
                    422
                );

                return;
            }


            $certificate =
                $this->certificate
                    ->getById($id);


            if (!$certificate) {

                $this->response(
                    false,
                    "Certification not found.",
                    null,
                    404
                );

                return;
            }


            $this->response(
                true,
                "Certification fetched successfully.",
                $certificate
            );


        } catch (Throwable $e) {


            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // CREATE CERTIFICATE
    // POST /api/create-certificate
    // =====================================================

    public function createCertificate(): void
    {

        try {

            // ==============================================
            // START SESSION
            // ==============================================

            if (
                session_status()
                === PHP_SESSION_NONE
            ) {

                session_start();
            }


            // ==============================================
            // GET JSON
            // ==============================================

            $input =
                json_decode(
                    file_get_contents(
                        "php://input"
                    ),
                    true
                );


            if (!is_array($input)) {

                $this->response(
                    false,
                    "Invalid request data.",
                    null,
                    422
                );

                return;
            }


            // ==============================================
            // GET LOGGED-IN USER ID
            // ==============================================

            $userId = 0;


            // First priority
            if (
                isset(
                    $_SESSION["user_id"]
                )
            ) {

                $userId =
                    (int)
                    $_SESSION["user_id"];
            }


            // Second possible session structure
            elseif (
                isset(
                    $_SESSION["user"]["id"]
                )
            ) {

                $userId =
                    (int)
                    $_SESSION["user"]["id"];
            }


            // Third possible structure
            elseif (
                isset(
                    $_SESSION["id"]
                )
            ) {

                $userId =
                    (int)
                    $_SESSION["id"];
            }


            // Temporary fallback from React
            elseif (
                isset(
                    $input["user_id"]
                )
            ) {

                $userId =
                    (int)
                    $input["user_id"];
            }


            // ==============================================
            // CHECK USER
            // ==============================================

            if ($userId <= 0) {

                $this->response(
                    false,
                    "Unable to identify logged-in user.",
                    null,
                    401
                );

                return;
            }


            // ==============================================
            // CERTIFICATION ID
            // ==============================================

            $certificationId =
                isset(
                    $input[
                        "certification_id"
                    ]
                )
                    ? (int)
                        $input[
                            "certification_id"
                        ]
                    : 0;


            if ($certificationId <= 0) {

                $this->response(
                    false,
                    "Certification ID is required.",
                    null,
                    422
                );

                return;
            }


            // ==============================================
            // GET CERTIFICATION
            // ==============================================

            $certification =
                $this->certificate
                    ->getById(
                        $certificationId
                    );


            if (!$certification) {

                $this->response(
                    false,
                    "Certification not found.",
                    null,
                    404
                );

                return;
            }


            // ==============================================
            // GET LOGGED-IN USER FROM DATABASE
            // ==============================================

            $user =
                $this->getUserById(
                    $userId
                );


            if (!$user) {

                $this->response(
                    false,
                    "Logged-in user not found.",
                    null,
                    404
                );

                return;
            }


            // ==============================================
            // CREATE FULL NAME
            // ==============================================

            $firstName =
                trim(
                    $user["first_name"]
                    ?? ""
                );


            $lastName =
                trim(
                    $user["last_name"]
                    ?? ""
                );


            $studentName =
                trim(
                    $firstName
                    . " "
                    . $lastName
                );


            // ==============================================
            // FALLBACK
            // ==============================================
            //
            // Only use React value if DB does not contain
            // first_name / last_name.
            //
            // ==============================================

            if (
                $studentName === ""
                &&
                isset(
                    $input["student_name"]
                )
            ) {

                $studentName =
                    trim(
                        $input[
                            "student_name"
                        ]
                    );
            }


            if ($studentName === "") {

                $this->response(
                    false,
                    "Student name is required.",
                    null,
                    422
                );

                return;
            }


            // ==============================================
            // SCORE
            // ==============================================

            $score =
                isset(
                    $input["score"]
                )
                    ? (int)
                        $input["score"]
                    : 0;


            // ==============================================
            // TOTAL QUESTIONS
            // ==============================================

            $total =
                isset(
                    $input["total"]
                )
                    ? (int)
                        $input["total"]
                    : 0;


            // ==============================================
            // PERCENTAGE
            // ==============================================

            $percentage =
                isset(
                    $input["percentage"]
                )
                    ? (float)
                        $input[
                            "percentage"
                        ]
                    : 0;


            // ==============================================
            // CHECK EXISTING CERTIFICATE
            // ==============================================

            $existing =
                $this->certificate
                    ->findExisting(
                        $userId,
                        $certificationId
                    );


            // ==============================================
            // RETURN EXISTING CERTIFICATE
            // ==============================================

            if ($existing) {

                $existing[
                    "template_url"
                ] =
                    $this
                        ->getTemplateUrl();


                $this->response(
                    true,
                    "Certificate already exists.",
                    $existing
                );

                return;
            }


            // ==============================================
            // GENERATE CERTIFICATE NUMBER
            // ==============================================

            $certificateNumber =
                $this->certificate
                    ->generateCertificateNumber();


            // ==============================================
            // MAKE SURE NUMBER DOES NOT EXIST
            // ==============================================

            while (
                $this->certificate
                    ->certificateNumberExists(
                        $certificateNumber
                    )
            ) {

                $certificateNumber =
                    $this->certificate
                        ->generateCertificateNumber();
            }


            // ==============================================
            // PDF PATH
            // ==============================================
            //
            // You are currently displaying an HTML/image
            // certificate, so no PDF has been generated.
            //
            // ==============================================

            $pdfPath =
                null;


            // ==============================================
            // CREATE CERTIFICATE
            // ==============================================

            $certificateId =
                $this->certificate
                    ->create(

                        $userId,

                        $certificationId,

                        $studentName,

                        $certificateNumber,

                        $score,

                        $total,

                        $percentage,

                        $pdfPath
                    );


            // ==============================================
            // CHECK INSERT
            // ==============================================

            if ($certificateId <= 0) {

                throw new Exception(
                    "Unable to create certificate."
                );
            }


            // ==============================================
            // GET CREATED CERTIFICATE
            // ==============================================

            $certificate =
                $this->certificate
                    ->getGeneratedCertificate(
                        $certificateId
                    );


            if (!$certificate) {

                throw new Exception(
                    "Certificate was created but could not be loaded."
                );
            }


            // ==============================================
            // TEMPLATE URL
            // ==============================================

            $certificate[
                "template_url"
            ] =
                $this
                    ->getTemplateUrl();


            // ==============================================
            // SUCCESS
            // ==============================================

            $this->response(
                true,
                "Certificate created successfully.",
                $certificate,
                201
            );


        } catch (Throwable $e) {


            $this->response(
                false,
                $e->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // GET USER FROM DATABASE
    // =====================================================

    private function getUserById(
        int $userId
    ): ?array {

        $sql = "
            SELECT
                id,
                first_name,
                last_name,
                email
            FROM users
            WHERE id = ?
            LIMIT 1
        ";


        $stmt =
            $this->db
                ->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "User Query Prepare Error: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $userId
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;


            $stmt->close();


            throw new Exception(
                "User Query Execute Error: "
                . $error
            );
        }


        $result =
            $stmt->get_result();


        $user =
            $result->fetch_assoc();


        $stmt->close();


        return $user ?: null;
    }


    // =====================================================
    // CERTIFICATE TEMPLATE
    // =====================================================

    private function getTemplateUrl(): string
    {

        return
            "http://localhost/"
            . "broadbeach-backend/"
            . "uploads/certificates/"
            . "templates/"
            . "certificate-template.png";
    }


    // =====================================================
    // JSON RESPONSE
    // =====================================================

    private function response(
        bool $success,
        string $message,
        mixed $data = null,
        int $status = 200
    ): void {

        http_response_code(
            $status
        );


        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        $response = [

            "success" =>
                $success,

            "message" =>
                $message,

        ];


        if ($data !== null) {

            $response[
                "data"
            ] =
                $data;
        }


        echo json_encode(
            $response,
            JSON_UNESCAPED_SLASHES
        );
    }
}