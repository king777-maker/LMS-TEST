<?php

require_once __DIR__ . "/../Models/AdminUser.php";

class AdminAuthController
{
    private mysqli $db;
    private AdminUser $adminUser;

    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
        $this->adminUser = new AdminUser($db);
    }


    // ==========================================
    // ADMIN LOGIN
    // POST /api/admin/login
    // ==========================================

    public function login(): void
    {
        header(
            "Content-Type: application/json; charset=UTF-8"
        );

        $input = json_decode(
            file_get_contents("php://input"),
            true
        );

        $email = trim(
            $input["email"] ?? ""
        );

        $password =
            $input["password"] ?? "";


        // ==========================================
        // VALIDATION
        // ==========================================

        if (
            $email === "" ||
            $password === ""
        ) {
            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" =>
                    "Email and password are required."
            ]);

            return;
        }


        // ==========================================
        // FIND ADMIN
        // ==========================================

        try {

            $admin =
                $this->adminUser->findByEmail(
                    $email
                );

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,
                "message" =>
                    "Unable to process login."
            ]);

            return;
        }


        // ==========================================
        // ADMIN NOT FOUND
        // ==========================================

        if (!$admin) {

            http_response_code(401);

            echo json_encode([
                "status" => false,
                "message" =>
                    "Invalid email or password."
            ]);

            return;
        }


        // ==========================================
        // CHECK ADMIN STATUS
        // ==========================================

        if (
            (int) $admin["status"] !== 1
        ) {
            http_response_code(403);

            echo json_encode([
                "status" => false,
                "message" =>
                    "Your admin account is inactive."
            ]);

            return;
        }


        // ==========================================
        // VERIFY PASSWORD
        // ==========================================

        if (
            !password_verify(
                $password,
                $admin["password"]
            )
        ) {
            http_response_code(401);

            echo json_encode([
                "status" => false,
                "message" =>
                    "Invalid email or password."
            ]);

            return;
        }


        // ==========================================
        // REGENERATE SESSION
        // ==========================================

        session_regenerate_id(true);

        $token = bin2hex(random_bytes(32));

        // ==========================================
        // STORE ADMIN SESSION
        // ==========================================

        $effectiveRole = $admin["role"];
        if (strtolower(trim($admin["email"])) === "admin@broadbeachlearning.com" || $effectiveRole === "super_admin") {
            $effectiveRole = "super_admin";
        }

        $_SESSION["admin"] = [
            "id" => (int) $admin["id"],
            "name" => $admin["name"],
            "email" => $admin["email"],
            "role" => $effectiveRole
        ];
        $_SESSION["admin_token"] = $token;

        try {
            $saveStmt = $this->db->prepare("UPDATE admin_users SET auth_token = ?, token_expires_at = DATE_ADD(NOW(), INTERVAL 24 HOUR) WHERE id = ?");
            if ($saveStmt) {
                $adminIdInt = (int)$admin["id"];
                $saveStmt->bind_param("si", $token, $adminIdInt);
                $saveStmt->execute();
                $saveStmt->close();
            }
        } catch (Throwable $e) {}

        echo json_encode([
            "status" => true,
            "message" => "Admin login successful.",
            "data" => [
                "id" => (int) $admin["id"],
                "name" => $admin["name"],
                "email" => $admin["email"],
                "role" => $effectiveRole,
                "token" => $token
            ]
        ]);
    }


    // ==========================================
    // CHECK ADMIN SESSION
    // GET /api/admin/me
    // ==========================================

    public function me(): void
    {
        header("Content-Type: application/json; charset=UTF-8");

        $adminData = null;
        if (isset($_SESSION["admin"]) && is_array($_SESSION["admin"])) {
            $adminData = $_SESSION["admin"];
        } else {
            // Check Authorization Bearer header
            $authHeader = $_SERVER["HTTP_AUTHORIZATION"] ?? $_SERVER["REDIRECT_HTTP_AUTHORIZATION"] ?? "";
            if (!$authHeader && function_exists('apache_request_headers')) {
                $h = apache_request_headers();
                $authHeader = $h['Authorization'] ?? $h['authorization'] ?? "";
            }
            if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
                $token = $matches[1];
                if (isset($_SESSION["admin_token"]) && hash_equals($_SESSION["admin_token"], $token) && isset($_SESSION["admin"])) {
                    $adminData = $_SESSION["admin"];
                } else {
                    try {
                        $stmt = $this->db->prepare("SELECT id, name, email, role, status FROM admin_users WHERE auth_token = ? AND token_expires_at > NOW() LIMIT 1");
                        if ($stmt) {
                            $stmt->bind_param("s", $token);
                            $stmt->execute();
                            $res = $stmt->get_result();
                            if ($res && $res->num_rows > 0) {
                                $u = $res->fetch_assoc();
                                if ((int)($u["status"] ?? 1) === 1 || $u["status"] === "active") {
                                    $adminData = [
                                        "id" => (int)$u["id"],
                                        "name" => $u["name"],
                                        "email" => $u["email"],
                                        "role" => $u["role"]
                                    ];
                                }
                            }
                            $stmt->close();
                        }
                    } catch (Throwable $e) {}
                }
            }
        }

        if (!$adminData) {
            http_response_code(401);
            echo json_encode([
                "status" => false,
                "message" => "Admin is not authenticated."
            ]);
            return;
        }

        if (strtolower(trim($adminData["email"] ?? "")) === "admin@broadbeachlearning.com" || ($adminData["role"] ?? "") === "super_admin") {
            $adminData["role"] = "super_admin";
        }

        echo json_encode([
            "status" => true,
            "message" => "Admin authenticated.",
            "data" => $adminData
        ]);
    }



    // ==========================================
    // ADMIN LOGOUT
    // POST /api/admin/logout
    // ==========================================

    public function logout(): void
    {
        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        unset(
            $_SESSION["admin"]
        );


        echo json_encode([
            "status" => true,

            "message" =>
                "Admin logout successful."
        ]);
    }
}