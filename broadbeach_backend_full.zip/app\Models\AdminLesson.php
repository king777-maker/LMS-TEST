<?php

class AdminLesson
{
    private mysqli $db;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }


    // =====================================================
    // GET ALL LESSONS
    // =====================================================

    public function getAll(int $certificationId): array
    {
        if ($certificationId <= 0) {
            throw new Exception(
                "Certification ID is required."
            );
        }


        $sql = "
            SELECT
                id,
                certification_id,
                chapter,
                title,
                duration,
                type,
                video_url,
                lesson_content,
                slides_url,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_lessons
            WHERE certification_id = ?
            ORDER BY sort_order ASC, id ASC
        ";


        $stmt = $this->db->prepare($sql);


        if (!$stmt) {
            throw new Exception(
                "Failed to prepare get lessons query: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $certificationId
        );


        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Failed to fetch lessons: "
                . $error
            );
        }


        $result = $stmt->get_result();


        $lessons = [];


        while ($row = $result->fetch_assoc()) {

            $lessons[] = $row;
        }


        $stmt->close();


        return $lessons;
    }


    // =====================================================
    // GET SINGLE LESSON
    // =====================================================

    public function getById(int $id): ?array
    {
        if ($id <= 0) {
            throw new Exception(
                "Lesson ID is required."
            );
        }


        $sql = "
            SELECT
                id,
                certification_id,
                chapter,
                title,
                duration,
                type,
                video_url,
                lesson_content,
                slides_url,
                sort_order,
                status,
                created_at,
                updated_at
            FROM course_lessons
            WHERE id = ?
            LIMIT 1
        ";


        $stmt = $this->db->prepare($sql);


        if (!$stmt) {
            throw new Exception(
                "Failed to prepare get lesson query: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $id
        );


        if (!$stmt->execute()) {

            $error = $stmt->error;

            $stmt->close();

            throw new Exception(
                "Failed to fetch lesson: "
                . $error
            );
        }


        $result = $stmt->get_result();


        $lesson =
            $result->fetch_assoc();


        $stmt->close();


        return $lesson ?: null;
    }


    // =====================================================
    // CREATE LESSON
    // =====================================================

    public function create(array $data): int
    {
        // -------------------------------------------------
        // GET DATA
        // -------------------------------------------------

        $certificationId =
            (int) (
                $data["certification_id"]
                ?? 0
            );


        $chapter =
            trim(
                (string) (
                    $data["chapter"]
                    ?? ""
                )
            );


        $title =
            trim(
                (string) (
                    $data["title"]
                    ?? ""
                )
            );


        $duration =
            trim(
                (string) (
                    $data["duration"]
                    ?? ""
                )
            );


        $type =
            trim(
                (string) (
                    $data["type"]
                    ?? "lesson"
                )
            );


        $videoUrl =
            $this->nullableString(
                $data["video_url"]
                ?? null
            );


        $lessonContent =
            $this->nullableString(
                $data["lesson_content"]
                ?? null
            );


        $slidesUrl =
            $this->nullableString(
                $data["slides_url"]
                ?? null
            );


        $sortOrder =
            (int) (
                $data["sort_order"]
                ?? 0
            );


        $status =
            trim(
                (string) (
                    $data["status"]
                    ?? "active"
                )
            );


        // -------------------------------------------------
        // VALIDATION
        // -------------------------------------------------

        if ($certificationId <= 0) {

            throw new Exception(
                "Certification ID is required."
            );
        }


        if ($chapter === "") {

            throw new Exception(
                "Chapter is required."
            );
        }


        if ($title === "") {

            throw new Exception(
                "Title is required."
            );
        }


        if (
            !in_array(
                $type,
                [
                    "lesson",
                    "assessment",
                    "certificate"
                ],
                true
            )
        ) {

            throw new Exception(
                "Invalid lesson type."
            );
        }


        if (
            !in_array(
                $status,
                [
                    "active",
                    "inactive"
                ],
                true
            )
        ) {

            throw new Exception(
                "Invalid lesson status."
            );
        }


        // -------------------------------------------------
        // INSERT
        // -------------------------------------------------

        $sql = "
            INSERT INTO course_lessons
            (
                certification_id,
                chapter,
                title,
                duration,
                type,
                video_url,
                lesson_content,
                slides_url,
                sort_order,
                status
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Failed to prepare create lesson query: "
                . $this->db->error
            );
        }


        /*
         * certification_id = i
         * chapter          = s
         * title            = s
         * duration         = s
         * type             = s
         * video_url        = s
         * lesson_content   = s
         * slides_url       = s
         * sort_order       = i
         * status           = s
         */

        $stmt->bind_param(
            "isssssssis",
            $certificationId,
            $chapter,
            $title,
            $duration,
            $type,
            $videoUrl,
            $lessonContent,
            $slidesUrl,
            $sortOrder,
            $status
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Failed to create lesson: "
                . $error
            );
        }


        $newId =
            (int) $stmt->insert_id;


        $stmt->close();


        return $newId;
    }


    // =====================================================
    // UPDATE LESSON
    // =====================================================

    public function update(array $data): bool
    {
        // -------------------------------------------------
        // GET DATA
        // -------------------------------------------------

        $id =
            (int) (
                $data["id"]
                ?? 0
            );


        $certificationId =
            (int) (
                $data["certification_id"]
                ?? 0
            );


        $chapter =
            trim(
                (string) (
                    $data["chapter"]
                    ?? ""
                )
            );


        $title =
            trim(
                (string) (
                    $data["title"]
                    ?? ""
                )
            );


        $duration =
            trim(
                (string) (
                    $data["duration"]
                    ?? ""
                )
            );


        $type =
            trim(
                (string) (
                    $data["type"]
                    ?? "lesson"
                )
            );


        $videoUrl =
            $this->nullableString(
                $data["video_url"]
                ?? null
            );


        $lessonContent =
            $this->nullableString(
                $data["lesson_content"]
                ?? null
            );


        $slidesUrl =
            $this->nullableString(
                $data["slides_url"]
                ?? null
            );


        $sortOrder =
            (int) (
                $data["sort_order"]
                ?? 0
            );


        $status =
            trim(
                (string) (
                    $data["status"]
                    ?? "active"
                )
            );


        // -------------------------------------------------
        // VALIDATION
        // -------------------------------------------------

        if ($id <= 0) {

            throw new Exception(
                "Lesson ID is required."
            );
        }


        if ($certificationId <= 0) {

            throw new Exception(
                "Certification ID is required."
            );
        }


        if ($chapter === "") {

            throw new Exception(
                "Chapter is required."
            );
        }


        if ($title === "") {

            throw new Exception(
                "Title is required."
            );
        }


        if (
            !in_array(
                $type,
                [
                    "lesson",
                    "assessment",
                    "certificate"
                ],
                true
            )
        ) {

            throw new Exception(
                "Invalid lesson type."
            );
        }


        if (
            !in_array(
                $status,
                [
                    "active",
                    "inactive"
                ],
                true
            )
        ) {

            throw new Exception(
                "Invalid lesson status."
            );
        }


        // -------------------------------------------------
        // CHECK EXISTING
        // -------------------------------------------------

        $existing =
            $this->getById($id);


        if (!$existing) {

            throw new Exception(
                "Lesson not found."
            );
        }


        // -------------------------------------------------
        // UPDATE
        // -------------------------------------------------

        $sql = "
            UPDATE course_lessons
            SET
                certification_id = ?,
                chapter = ?,
                title = ?,
                duration = ?,
                type = ?,
                video_url = ?,
                lesson_content = ?,
                slides_url = ?,
                sort_order = ?,
                status = ?
            WHERE id = ?
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Failed to prepare update lesson query: "
                . $this->db->error
            );
        }


        /*
         * i = certification_id
         * s = chapter
         * s = title
         * s = duration
         * s = type
         * s = video_url
         * s = lesson_content
         * s = slides_url
         * i = sort_order
         * s = status
         * i = id
         *
         * IMPORTANT:
         *
         * "isssssssssi"
         */

        $stmt->bind_param(
            "isssssssssi",
            $certificationId,
            $chapter,
            $title,
            $duration,
            $type,
            $videoUrl,
            $lessonContent,
            $slidesUrl,
            $sortOrder,
            $status,
            $id
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Failed to update lesson: "
                . $error
            );
        }


        $stmt->close();


        return true;
    }


    // =====================================================
    // DELETE LESSON
    // =====================================================

    public function delete(int $id): bool
    {
        if ($id <= 0) {

            throw new Exception(
                "Lesson ID is required."
            );
        }


        // -------------------------------------------------
        // CHECK EXISTING
        // -------------------------------------------------

        $existing =
            $this->getById($id);


        if (!$existing) {

            return false;
        }


        // -------------------------------------------------
        // DELETE
        // -------------------------------------------------

        $sql = "
            DELETE FROM course_lessons
            WHERE id = ?
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Failed to prepare delete lesson query: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $id
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Failed to delete lesson: "
                . $error
            );
        }


        $deleted =
            $stmt->affected_rows > 0;


        $stmt->close();


        return $deleted;
    }


    // =====================================================
    // NULLABLE STRING
    // =====================================================

    private function nullableString(
        mixed $value
    ): ?string {

        if (
            $value === null
            ||
            $value === ""
        ) {

            return null;
        }


        return (string) $value;
    }
}