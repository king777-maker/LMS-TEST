<?php

/*
|--------------------------------------------------------------------------
| BROADBEECH SESSION + CORS
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/cors.php";

/*
|--------------------------------------------------------------------------
| SESSION INITIALIZATION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {

    $isHttps = (
        (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off") ||
        (isset($_SERVER["HTTP_X_FORWARDED_PROTO"]) && $_SERVER["HTTP_X_FORWARDED_PROTO"] === "https") ||
        (isset($_SERVER["SERVER_PORT"]) && (int)$_SERVER["SERVER_PORT"] === 443)
    );

    // Cross-site fetch requests require SameSite=None and Secure=true over HTTPS
    $sameSite = $isHttps ? "None" : "Lax";

    session_set_cookie_params([
        "lifetime" => 86400 * 7, // 7 days
        "path" => "/",
        "domain" => "",
        "secure" => $isHttps,
        "httponly" => true,
        "samesite" => $sameSite
    ]);

    session_start();
}

if (!isset($_SESSION) || !is_array($_SESSION)) {
    $_SESSION = [];
}