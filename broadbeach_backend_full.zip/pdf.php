<?php

// =====================================================
// CORS
// =====================================================

header(
    "Access-Control-Allow-Origin: http://localhost:5173"
);

header(
    "Access-Control-Allow-Methods: GET, OPTIONS"
);

header(
    "Access-Control-Allow-Headers: Content-Type, Authorization"
);

header(
    "Access-Control-Allow-Credentials: true"
);


// =====================================================
// OPTIONS
// =====================================================

if (
    $_SERVER["REQUEST_METHOD"] === "OPTIONS"
) {
    http_response_code(204);
    exit;
}


// =====================================================
// ONLY GET
// =====================================================

if (
    $_SERVER["REQUEST_METHOD"] !== "GET"
) {
    http_response_code(405);
    exit("Method not allowed.");
}


// =====================================================
// GET FILE
// =====================================================

$file = trim(
    $_GET["file"] ?? ""
);

if ($file === "") {
    http_response_code(400);
    exit("PDF file is required.");
}


// =====================================================
// SLIDES DIRECTORY
// =====================================================

$basePath = realpath(
    __DIR__ . "/uploads/slides"
);

if ($basePath === false) {
    http_response_code(500);
    exit("Slides directory not found.");
}


// =====================================================
// SECURITY
// =====================================================

$fileName = basename($file);

$filePath = realpath(
    $basePath .
    DIRECTORY_SEPARATOR .
    $fileName
);


// =====================================================
// CHECK FILE
// =====================================================

if (
    $filePath === false ||
    !is_file($filePath) ||
    !str_starts_with(
        $filePath,
        $basePath
    )
) {
    http_response_code(404);
    exit("PDF not found.");
}


// =====================================================
// CHECK PDF EXTENSION
// =====================================================

if (
    strtolower(
        pathinfo(
            $filePath,
            PATHINFO_EXTENSION
        )
    ) !== "pdf"
) {
    http_response_code(403);
    exit("Only PDF files are allowed.");
}


// =====================================================
// SEND PDF
// =====================================================

header(
    "Content-Type: application/pdf"
);

header(
    "Content-Length: " .
    filesize($filePath)
);

header(
    'Content-Disposition: attachment; filename="' .
    basename($filePath) .
    '"'
);

header(
    "Cache-Control: private, max-age=3600"
);

header(
    "X-Content-Type-Options: nosniff"
);


// =====================================================
// OUTPUT
// =====================================================

readfile($filePath);

exit;