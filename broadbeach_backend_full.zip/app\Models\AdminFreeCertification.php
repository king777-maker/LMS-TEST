<?php

class AdminFreeCertification
{
    private mysqli $db;
 

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }


    // =====================================================
    // GET ALL FREE CERTIFICATIONS
    // =====================================================

    public function getAll(): array
    {
        $sql = "
            SELECT
                id,
                name,
                category,
                description,
                students,
                rating,
                image,
                price,
                status,
                sort_order,
                created_at,
                updated_at
            FROM free_certifications
            ORDER BY sort_order ASC, id DESC
        ";

        $result = $this->db->query($sql);

        if (!$result) {
            throw new Exception(
                "Unable to fetch certifications: "
                . $this->db->error
            );
        }

        $certifications = [];

        while ($row = $result->fetch_assoc()) {

            $certifications[] = $row;
        }

        return $certifications;
    }


    // =====================================================
    // GET SINGLE FREE CERTIFICATION
    // =====================================================

    public function getById(int $id): ?array
    {
        $sql = "
            SELECT
                id,
                name,
                category,
                description,
                students,
                rating,
                image,
                price,
                status,
                sort_order,
                created_at,
                updated_at
            FROM free_certifications
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Unable to prepare query: "
                . $this->db->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        $stmt->execute();

        $result =
            $stmt->get_result();

        $data =
            $result->fetch_assoc();

        $stmt->close();

        return $data ?: null;
    }


    // =====================================================
    // CREATE FREE CERTIFICATION
    // =====================================================

    public function create(array $data): int
    {
        $name =
            trim($data["name"] ?? "");

        $category =
            trim($data["category"] ?? "");

        $description =
            trim($data["description"] ?? "");

        $students =
            isset($data["students"])
                ? (int) $data["students"]
                : 0;

        $rating =
            isset($data["rating"])
                ? (float) $data["rating"]
                : 0.0;

        $image =
            !empty($data["image"])
                ? trim($data["image"])
                : null;

        $price =
            isset($data["price"])
                ? (float) $data["price"]
                : 0.00;

        $status =
            !empty($data["status"])
                ? trim($data["status"])
                : "active";

        $sortOrder =
            isset($data["sort_order"])
                ? (int) $data["sort_order"]
                : 0;


        // =================================================
        // VALIDATION
        // =================================================

        if ($name === "") {

            throw new Exception(
                "Certification name is required."
            );
        }

        if ($category === "") {

            throw new Exception(
                "Certification category is required."
            );
        }


        // =================================================
        // INSERT
        // =================================================

        $sql = "
            INSERT INTO free_certifications
            (
                name,
                category,
                description,
                students,
                rating,
                image,
                price,
                status,
                sort_order
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ";

        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Unable to prepare insert query: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "sssidsssi",
            $name,
            $category,
            $description,
            $students,
            $rating,
            $image,
            $price,
            $status,
            $sortOrder
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Unable to create certification: "
                . $error
            );
        }


        $id =
            $this->db->insert_id;


        $stmt->close();


        return (int) $id;
    }


    // =====================================================
    // UPDATE FREE CERTIFICATION
    // =====================================================

    public function update(array $data): bool
    {
        $id =
            isset($data["id"])
                ? (int) $data["id"]
                : 0;


        if ($id <= 0) {

            throw new Exception(
                "Certification ID is required."
            );
        }


        $name =
            trim($data["name"] ?? "");

        $category =
            trim($data["category"] ?? "");

        $description =
            trim($data["description"] ?? "");

        $students =
            isset($data["students"])
                ? (int) $data["students"]
                : 0;

        $rating =
            isset($data["rating"])
                ? (float) $data["rating"]
                : 0.0;

        $image =
            !empty($data["image"])
                ? trim($data["image"])
                : null;

        $price =
            isset($data["price"])
                ? (float) $data["price"]
                : 0.00;

        $status =
            !empty($data["status"])
                ? trim($data["status"])
                : "active";

        $sortOrder =
            isset($data["sort_order"])
                ? (int) $data["sort_order"]
                : 0;


        // =================================================
        // VALIDATION
        // =================================================

        if ($name === "") {

            throw new Exception(
                "Certification name is required."
            );
        }

        if ($category === "") {

            throw new Exception(
                "Certification category is required."
            );
        }


        // =================================================
        // UPDATE
        // =================================================

        $sql = "
            UPDATE free_certifications
            SET
                name = ?,
                category = ?,
                description = ?,
                students = ?,
                rating = ?,
                image = ?,
                price = ?,
                status = ?,
                sort_order = ?
            WHERE id = ?
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Unable to prepare update query: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "sssidsssii",
            $name,
            $category,
            $description,
            $students,
            $rating,
            $image,
            $price,
            $status,
            $sortOrder,
            $id
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Unable to update certification: "
                . $error
            );
        }


        $affectedRows =
            $stmt->affected_rows;


        $stmt->close();


        /*
         * affected_rows can be 0 when the submitted
         * values are exactly the same as the existing
         * values. Therefore check whether the record
         * actually exists.
         */

        if ($affectedRows === 0) {

            $existing =
                $this->getById($id);

            return $existing !== null;
        }


        return true;
    }


    // =====================================================
    // DELETE FREE CERTIFICATION
    // =====================================================

    public function delete(int $id): bool
    {
        if ($id <= 0) {

            throw new Exception(
                "Certification ID is required."
            );
        }


        $sql = "
            DELETE FROM free_certifications
            WHERE id = ?
        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Unable to prepare delete query: "
                . $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $id
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Unable to delete certification: "
                . $error
            );
        }


        $deleted =
            $stmt->affected_rows > 0;


        $stmt->close();


        return $deleted;
    }
}