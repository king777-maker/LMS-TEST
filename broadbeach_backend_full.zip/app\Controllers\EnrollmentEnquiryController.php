<?php

/**
 * ============================================================================
 * BROADBEACH ACADEMY — ENROLLMENT ENQUIRY CONTROLLER (PHASE 1)
 * ============================================================================
 */

class EnrollmentEnquiryController
{
    private $recipientEmail = "certification@broadbeach.in";
    private $senderEmail = "no-reply@broadbeach.in";
    private $db = null;

    public function __construct($db = null)
    {
        $this->db = $db;
    }

    public function submit()
    {
        header("Content-Type: application/json; charset=UTF-8");

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            http_response_code(405);
            echo json_encode([
                "success" => false,
                "message" => "Method not allowed. Only POST is accepted."
            ]);
            return;
        }

        $raw = file_get_contents("php://input");
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            $data = $_POST;
        }

        // Honeypot check
        if (!empty($data["website"])) {
            http_response_code(200);
            echo json_encode([
                "success" => true,
                "message" => "Thank you! Your enquiry has been received.",
                "data" => [
                    "reference_id" => "ENQ-BOT-" . time()
                ]
            ]);
            return;
        }

        // Rate limiting (max 10 per hour)
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $now = time();
        $rateLimitWindow = 3600;
        $maxAttempts = 10;

        if (!isset($_SESSION["course_enquiry_submissions"])) {
            $_SESSION["course_enquiry_submissions"] = [];
        }

        $_SESSION["course_enquiry_submissions"] = array_filter(
            $_SESSION["course_enquiry_submissions"],
            function ($timestamp) use ($now, $rateLimitWindow) {
                return ($now - $timestamp) < $rateLimitWindow;
            }
        );

        if (count($_SESSION["course_enquiry_submissions"]) >= $maxAttempts) {
            http_response_code(429);
            echo json_encode([
                "success" => false,
                "message" => "Too many enquiries sent. Please wait or contact our admissions office directly at +91 7338649737."
            ]);
            return;
        }

        // Server-Side Validation: ALL REQUIRED FIELDS
        $fullName = trim($data["full_name"] ?? "");
        $email = trim($data["email"] ?? "");
        $phone = trim($data["phone"] ?? "");
        $courseId = trim((string)($data["course_id"] ?? ""));
        $courseTitle = trim($data["course_title"] ?? "");
        $company = trim($data["company"] ?? "");
        $designation = trim($data["designation"] ?? "");
        $experience = trim($data["experience"] ?? "");
        $priorKnowledge = trim($data["prior_knowledge"] ?? "");
        $participants = trim($data["participants"] ?? "");
        $trainingLocation = trim($data["training_location"] ?? "");
        $preferredTiming = trim($data["preferred_timing"] ?? "");
        $timeframe = trim($data["timeframe"] ?? "");
        $message = trim($data["message"] ?? "");
        $consent = !empty($data["consent"]);

        $errors = [];

        if (empty($fullName) || mb_strlen($fullName) < 2) {
            $errors["full_name"] = "Full name is required (minimum 2 characters).";
        }

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors["email"] = "A valid email address is required.";
        }

        $cleanedPhone = preg_replace('/[\s\-()]/', '', $phone);
        if (empty($phone) || strlen($cleanedPhone) < 8) {
            $errors["phone"] = "A valid contact phone number is required (min 8 digits).";
        }

        if (empty($company) || mb_strlen($company) < 2) {
            $errors["company"] = "Company or organization name is required.";
        }

        if (empty($designation) || mb_strlen($designation) < 2) {
            $errors["designation"] = "Job role or designation is required.";
        }

        if (empty($experience)) {
            $errors["experience"] = "Years of experience is required.";
        }

        if (empty($priorKnowledge)) {
            $errors["prior_knowledge"] = "Prior ISO knowledge level is required.";
        }

        if (empty($participants)) {
            $errors["participants"] = "Number of participants is required.";
        }

        if (empty($trainingLocation)) {
            $errors["training_location"] = "Preferred training location is required.";
        }

        if (empty($preferredTiming)) {
            $errors["preferred_timing"] = "Preferred batch timing is required.";
        }

        if (empty($timeframe)) {
            $errors["timeframe"] = "Target training timeframe is required.";
        }

        if (empty($message) || mb_strlen($message) < 10) {
            $errors["message"] = "Training requirements message is required (minimum 10 characters).";
        }

        if (empty($courseId)) {
            $errors["course_id"] = "Course identifier is required.";
        }

        if (!$consent) {
            $errors["consent"] = "Consent to be contacted is required.";
        }

        if (!empty($errors)) {
            http_response_code(422);
            echo json_encode([
                "success" => false,
                "message" => "Validation failed. Please fill in all required enquiry details.",
                "errors" => $errors
            ]);
            return;
        }

        $cleanFullName = preg_replace("/[\r\n]+/", " ", $fullName);
        $cleanEmail = preg_replace("/[\r\n]+/", "", $email);
        $cleanPhone = preg_replace("/[\r\n]+/", " ", $phone);
        $cleanCourseId = preg_replace("/[\r\n]+/", " ", $courseId);
        $cleanCourseTitle = preg_replace("/[\r\n]+/", " ", $courseTitle ?: $cleanCourseId);
        $cleanCompany = preg_replace("/[\r\n]+/", " ", $company);
        $cleanDesignation = preg_replace("/[\r\n]+/", " ", $designation);
        $cleanLocation = preg_replace("/[\r\n]+/", " ", $trainingLocation);
        $cleanTiming = preg_replace("/[\r\n]+/", " ", $preferredTiming);
        $cleanMessage = htmlspecialchars($message, ENT_QUOTES, "UTF-8");

        $refId = "ENQ-" . strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $cleanCourseId), 0, 8)) . "-" . strtoupper(dechex($now));
        $ipAddress = $_SERVER["REMOTE_ADDR"] ?? "unknown";

        // DB save
        if ($this->db instanceof mysqli) {
            try {
                $tableSql = "CREATE TABLE IF NOT EXISTS course_enquiries (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    reference_id VARCHAR(64) NOT NULL,
                    course_id VARCHAR(64) NOT NULL,
                    course_title VARCHAR(255) NOT NULL,
                    full_name VARCHAR(128) NOT NULL,
                    email VARCHAR(128) NOT NULL,
                    phone VARCHAR(32) NOT NULL,
                    company VARCHAR(128) DEFAULT NULL,
                    designation VARCHAR(128) DEFAULT NULL,
                    experience VARCHAR(64) DEFAULT NULL,
                    prior_knowledge VARCHAR(64) DEFAULT NULL,
                    participants VARCHAR(64) DEFAULT NULL,
                    training_location VARCHAR(128) DEFAULT NULL,
                    preferred_timing VARCHAR(64) DEFAULT NULL,
                    timeframe VARCHAR(64) DEFAULT NULL,
                    message TEXT DEFAULT NULL,
                    consent TINYINT(1) DEFAULT 1,
                    ip_address VARCHAR(45) DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_course (course_id),
                    INDEX idx_email (email)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
                @$this->db->query($tableSql);

                $stmt = $this->db->prepare("INSERT INTO course_enquiries (reference_id, course_id, course_title, full_name, email, phone, company, designation, experience, prior_knowledge, participants, training_location, preferred_timing, timeframe, message, consent, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)");
                if ($stmt) {
                    $stmt->bind_param(
                        "ssssssssssssssss",
                        $refId,
                        $cleanCourseId,
                        $cleanCourseTitle,
                        $cleanFullName,
                        $cleanEmail,
                        $cleanPhone,
                        $cleanCompany,
                        $cleanDesignation,
                        $experience,
                        $priorKnowledge,
                        $participants,
                        $cleanLocation,
                        $cleanTiming,
                        $timeframe,
                        $message,
                        $ipAddress
                    );
                    $stmt->execute();
                    $stmt->close();
                }
            } catch (\Throwable $t) {
                error_log("Course enquiry DB save error: " . $t->getMessage());
            }
        }

        // Email Notification
        $emailSubject = "[Broadbeach Academy - Enquire from] " . $cleanCourseTitle . " (" . $cleanFullName . " - " . $cleanCompany . ")";
        $emailHeaders = [
            "MIME-Version: 1.0",
            "Content-Type: text/html; charset=UTF-8",
            "From: Broadbeach Academy <" . $this->senderEmail . ">",
            "Reply-To: " . $cleanFullName . " <" . $cleanEmail . ">",
            "X-Mailer: PHP/" . phpversion()
        ];

        $htmlBody = "
        <!DOCTYPE html>
        <html>
        <head><meta charset='utf-8'><title>Enquire from</title></head>
        <body style='font-family: Arial, sans-serif; background-color: #f4f6f9; padding: 20px;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden;'>
                <div style='background-color: #0B315B; padding: 20px; text-align: center; color: #ffffff;'>
                    <h2 style='margin: 0; font-size: 20px;'>Broadbeach Online Academy</h2>
                    <p style='margin: 5px 0 0; color: #F7C600; font-size: 13px; font-weight: bold;'>Enquire from — Offline Certification Batches</p>
                </div>
                <div style='padding: 24px; color: #334155; line-height: 1.6;'>
                    <div style='background-color: #eff6ff; border-left: 4px solid #2563eb; padding: 12px 16px; margin-bottom: 20px; border-radius: 4px;'>
                        <p style='margin: 0; font-size: 12px; color: #1e40af; font-weight: bold;'>REFERENCE: {$refId}</p>
                        <h3 style='margin: 4px 0 0; color: #1e3a8a; font-size: 16px;'>Course: {$cleanCourseTitle} ({$cleanCourseId})</h3>
                    </div>
                    <table style='width: 100%; border-collapse: collapse; margin-bottom: 20px;'>
                        <tr><td style='padding: 6px 0; font-weight: bold; width: 150px; color: #64748b;'>Full Name:</td><td style='padding: 6px 0; font-weight: 600;'>{$cleanFullName}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Email:</td><td style='padding: 6px 0;'>{$cleanEmail}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Phone:</td><td style='padding: 6px 0;'>{$cleanPhone}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Company:</td><td style='padding: 6px 0;'>{$cleanCompany}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Role / Designation:</td><td style='padding: 6px 0;'>{$cleanDesignation}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Experience:</td><td style='padding: 6px 0;'>{$experience}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Prior Knowledge:</td><td style='padding: 6px 0;'>{$priorKnowledge}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Participants:</td><td style='padding: 6px 0;'>{$participants}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Location:</td><td style='padding: 6px 0;'>{$cleanLocation}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Batch Timing:</td><td style='padding: 6px 0;'>{$cleanTiming}</td></tr>
                        <tr><td style='padding: 6px 0; font-weight: bold; color: #64748b;'>Target Timeframe:</td><td style='padding: 6px 0;'>{$timeframe}</td></tr>
                    </table>
                    <div style='background-color: #f8fafc; border-left: 4px solid #0B315B; padding: 15px; border-radius: 4px;'>
                        <p style='margin: 0 0 6px; font-weight: bold; color: #0B315B;'>Specific Training Objectives / Message:</p>
                        <p style='margin: 0; color: #1e293b; white-space: pre-wrap;'>{$cleanMessage}</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";

        try {
            @mail($this->recipientEmail, $emailSubject, $htmlBody, implode("\r\n", $emailHeaders));
        } catch (\Throwable $t) {}

        $_SESSION["course_enquiry_submissions"][] = $now;

        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Thank you for your interest in " . ($cleanCourseTitle ?: "this course") . ". Our team will contact you regarding upcoming offline batches.",
            "data" => [
                "reference_id" => $refId,
                "course_id" => $cleanCourseId,
                "course_title" => $cleanCourseTitle,
                "full_name" => $cleanFullName,
                "email" => $cleanEmail,
                "phone" => $cleanPhone
            ]
        ]);
    }
}
