<?php

require_once __DIR__ . "/../Models/FeaturedCourseModel.php";

class FeaturedCourseController
{
    private $model;

    public function __construct($db)
    {
        $this->model = new FeaturedCourseModel($db);
    }

    // GET ALL FEATURED COURSES
    // /api/featured-courses
    public function getAll()
    {
        header("Content-Type: application/json");

        try {
            $courses = $this->model->getAllFeaturedCourses();

            echo json_encode([
                "success" => true,
                "status" => true,
                "message" => "Featured courses fetched successfully.",
                "data" => $courses
            ]);
        } catch (Exception $e) {
            http_response_code(500);

            echo json_encode([
                "success" => false,
                "status" => false,
                "message" => $e->getMessage(),
                "data" => []
            ]);
        }

        exit;
    }

    // GET SINGLE FEATURED COURSE BY ID
    // /api/featured-course?id=1
    public function getById()
    {
        header("Content-Type: application/json");

        $id = isset($_GET["id"]) ? (int) $_GET["id"] : 0;

        if ($id <= 0) {
            http_response_code(400);

            echo json_encode([
                "success" => false,
                "status" => false,
                "message" => "Valid featured course ID is required.",
                "data" => null
            ]);

            exit;
        }

        try {
            $course = $this->model->getFeaturedCourseById($id);

            if (!$course) {
                http_response_code(404);

                echo json_encode([
                    "success" => false,
                    "status" => false,
                    "message" => "Featured course not found.",
                    "data" => null
                ]);

                exit;
            }

            echo json_encode([
                "success" => true,
                "status" => true,
                "message" => "Featured course fetched successfully.",
                "data" => $course
            ]);
        } catch (Exception $e) {
            http_response_code(500);

            echo json_encode([
                "success" => false,
                "status" => false,
                "message" => $e->getMessage(),
                "data" => null
            ]);
        }

        exit;
    }

    // GET SINGLE FEATURED COURSE BY SLUG
    // /api/featured-course-by-slug?slug=course-slug
    public function getBySlug()
    {
        header("Content-Type: application/json");

        $slug = trim($_GET["slug"] ?? "");

        if ($slug === "") {
            http_response_code(400);

            echo json_encode([
                "success" => false,
                "status" => false,
                "message" => "Course slug is required.",
                "data" => null
            ]);

            exit;
        }

        try {
            $course = $this->model->getFeaturedCourseBySlug($slug);

            if (!$course) {
                http_response_code(404);

                echo json_encode([
                    "success" => false,
                    "status" => false,
                    "message" => "Featured course not found.",
                    "data" => null
                ]);

                exit;
            }

            echo json_encode([
                "success" => true,
                "status" => true,
                "message" => "Featured course fetched successfully.",
                "data" => $course
            ]);
        } catch (Exception $e) {
            http_response_code(500);

            echo json_encode([
                "success" => false,
                "status" => false,
                "message" => $e->getMessage(),
                "data" => null
            ]);
        }

        exit;
    }
}