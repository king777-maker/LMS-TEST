<?php

class CertificateCoupon
{
    private mysqli $conn;


    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct(mysqli $db)
    {
        $this->conn = $db;
    }


    // ==========================================
    // FIND VALID CERTIFICATE COUPON
    // ==========================================

    public function findValidCoupon(
        string $code,
        int $certificationId
    ): ?array {

        $sql = "
            SELECT
                *
            FROM certificate_coupons

            WHERE code = ?

            AND status = 1

            AND (
                certification_id = ?
                OR certification_id IS NULL
            )

            AND (
                expires_at IS NULL
                OR expires_at >= NOW()
            )

            LIMIT 1
        ";


        $stmt =
            $this->conn->prepare($sql);


        if (!$stmt) {

            return null;
        }


        $stmt->bind_param(
            "si",
            $code,
            $certificationId
        );


        $stmt->execute();


        $result =
            $stmt->get_result();


        $coupon =
            $result->fetch_assoc();


        $stmt->close();


        return $coupon ?: null;
    }


    // ==========================================
    // CHECK ALREADY REDEEMED
    // ==========================================

    public function alreadyRedeemed(
        int $couponId,
        int $userId,
        int $certificationId
    ): bool {

        $sql = "
            SELECT id

            FROM certificate_coupon_redemptions

            WHERE coupon_id = ?

            AND user_id = ?

            AND certification_id = ?

            LIMIT 1
        ";


        $stmt =
            $this->conn->prepare($sql);


        if (!$stmt) {

            return false;
        }


        $stmt->bind_param(
            "iii",
            $couponId,
            $userId,
            $certificationId
        );


        $stmt->execute();


        $result =
            $stmt->get_result();


        $exists =
            $result->num_rows > 0;


        $stmt->close();


        return $exists;
    }


    // ==========================================
    // REDEEM CERTIFICATE COUPON
    // ==========================================

    public function redeem(
        int $couponId,
        int $userId,
        int $certificationId
    ): bool {

        try {

            $this->conn->begin_transaction();


            // =====================================
            // LOCK COUPON
            // =====================================

            $sql = "
                SELECT
                    max_uses,
                    used_count,
                    status,
                    expires_at

                FROM certificate_coupons

                WHERE id = ?

                FOR UPDATE
            ";


            $stmt =
                $this->conn->prepare($sql);


            if (!$stmt) {

                throw new Exception(
                    "Unable to prepare coupon query."
                );
            }


            $stmt->bind_param(
                "i",
                $couponId
            );


            $stmt->execute();


            $coupon =
                $stmt
                    ->get_result()
                    ->fetch_assoc();


            $stmt->close();


            if (!$coupon) {

                $this->conn->rollback();

                return false;
            }


            // =====================================
            // STATUS CHECK
            // =====================================

            if (
                (int) $coupon["status"] !== 1
            ) {

                $this->conn->rollback();

                return false;
            }


            // =====================================
            // EXPIRY CHECK
            // =====================================

            if (
                $coupon["expires_at"] !== null
                &&
                strtotime(
                    $coupon["expires_at"]
                ) < time()
            ) {

                $this->conn->rollback();

                return false;
            }


            // =====================================
            // MAXIMUM USE CHECK
            // =====================================

            if (
                $coupon["max_uses"] !== null
                &&
                (int) $coupon["max_uses"] > 0
                &&
                (int) $coupon["used_count"]
                >=
                (int) $coupon["max_uses"]
            ) {

                $this->conn->rollback();

                return false;
            }


            // =====================================
            // CHECK DUPLICATE
            // =====================================

            $sql = "
                SELECT id

                FROM certificate_coupon_redemptions

                WHERE coupon_id = ?

                AND user_id = ?

                AND certification_id = ?

                LIMIT 1
            ";


            $stmt =
                $this->conn->prepare($sql);


            $stmt->bind_param(
                "iii",
                $couponId,
                $userId,
                $certificationId
            );


            $stmt->execute();


            $result =
                $stmt->get_result();


            if ($result->num_rows > 0) {

                $stmt->close();

                $this->conn->commit();

                return true;
            }


            $stmt->close();


            // =====================================
            // SAVE REDEMPTION
            // =====================================

            $sql = "
                INSERT INTO certificate_coupon_redemptions
                (
                    coupon_id,
                    user_id,
                    certification_id
                )

                VALUES
                (
                    ?,
                    ?,
                    ?
                )
            ";


            $stmt =
                $this->conn->prepare($sql);


            if (!$stmt) {

                throw new Exception(
                    "Unable to prepare redemption query."
                );
            }


            $stmt->bind_param(
                "iii",
                $couponId,
                $userId,
                $certificationId
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    $stmt->error
                );
            }


            $stmt->close();


            // =====================================
            // INCREMENT USAGE
            // =====================================

            $sql = "
                UPDATE certificate_coupons

                SET used_count =
                    used_count + 1

                WHERE id = ?
            ";


            $stmt =
                $this->conn->prepare($sql);


            if (!$stmt) {

                throw new Exception(
                    "Unable to update coupon usage."
                );
            }


            $stmt->bind_param(
                "i",
                $couponId
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    $stmt->error
                );
            }


            $stmt->close();


            // =====================================
            // COMMIT
            // =====================================

            $this->conn->commit();


            return true;


        } catch (Throwable $e) {

    // Rollback the transaction if anything failed
    $this->conn->rollback();

    error_log(
        "Certificate Coupon Error: "
        . $e->getMessage()
    );

    return false;
}
    }
}