<?php

require_once __DIR__
    . "/../Models/AdminLesson.php";


class AdminLessonController
{
    private AdminLesson $lesson;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(
        mysqli $db
    ) {

        $this->lesson =
            new AdminLesson($db);
    }


    // =====================================================
    // GET ALL LESSONS
    // GET /api/admin/course-lessons
    // =====================================================

    public function getAll(): void
    {
        try {

            $certificationId =
                (int) (
                    $_GET["certification_id"]
                    ?? 0
                );


            if ($certificationId <= 0) {

                $this->response(
                    false,
                    "Certification ID is required.",
                    [],
                    422
                );

                return;
            }


            $lessons =
                $this->lesson->getAll(
                    $certificationId
                );


            $this->response(
                true,
                "Lessons fetched successfully.",
                $lessons
            );

        } catch (Throwable $error) {

            error_log(
                "GET LESSONS ERROR: "
                . $error->getMessage()
            );


            $this->response(
                false,
                $error->getMessage(),
                [],
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE
    // GET /api/admin/course-lesson?id=1
    // =====================================================

    public function getById(): void
    {
        try {

            $id =
                (int) (
                    $_GET["id"]
                    ?? 0
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Lesson ID is required.",
                    [],
                    422
                );

                return;
            }


            $lesson =
                $this->lesson->getById(
                    $id
                );


            if (!$lesson) {

                $this->response(
                    false,
                    "Lesson not found.",
                    [],
                    404
                );

                return;
            }


            $this->response(
                true,
                "Lesson fetched successfully.",
                $lesson
            );

        } catch (Throwable $error) {

            error_log(
                "GET SINGLE LESSON ERROR: "
                . $error->getMessage()
            );


            $this->response(
                false,
                $error->getMessage(),
                [],
                500
            );
        }
    }


    // =====================================================
    // CREATE
    // POST /api/admin/course-lessons
    // =====================================================

    public function create(): void
    {
        try {

            $input =
                $this->getJsonBody();


            /*
             * IMPORTANT
             *
             * AdminLesson::create()
             * expects ARRAY.
             *
             * Example:
             *
             * [
             *   certification_id => 1,
             *   chapter          => "Chapter 1",
             *   title            => "...",
             *   ...
             * ]
             */


            $newId =
                $this->lesson->create(
                    $input
                );


            $createdLesson =
                $this->lesson->getById(
                    $newId
                );


            $this->response(
                true,
                "Lesson created successfully.",
                $createdLesson,
                201
            );

        } catch (Throwable $error) {

            error_log(
                "CREATE LESSON ERROR: "
                . $error->getMessage()
            );


            $this->response(
                false,
                $error->getMessage(),
                [],
                400
            );
        }
    }


    // =====================================================
    // UPDATE
    // PUT /api/admin/course-lessons
    // =====================================================

    public function update(): void
    {
        try {

            $input =
                $this->getJsonBody();


            $id =
                (int) (
                    $input["id"]
                    ?? 0
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Lesson ID is required.",
                    [],
                    422
                );

                return;
            }


            /*
             * Make sure ID is integer.
             */

            $input["id"] =
                $id;


            /*
             * AdminLesson::update()
             * expects ARRAY.
             */

            $this->lesson->update(
                $input
            );


            $updatedLesson =
                $this->lesson->getById(
                    $id
                );


            $this->response(
                true,
                "Lesson updated successfully.",
                $updatedLesson
            );

        } catch (Throwable $error) {

            error_log(
                "UPDATE LESSON ERROR: "
                . $error->getMessage()
            );


            $this->response(
                false,
                $error->getMessage(),
                [],
                400
            );
        }
    }


    // =====================================================
    // DELETE
    // DELETE /api/admin/course-lessons
    // =====================================================

    public function delete(): void
    {
        try {

            $input =
                $this->getJsonBody();


            $id =
                (int) (
                    $input["id"]
                    ?? 0
                );


            if ($id <= 0) {

                $this->response(
                    false,
                    "Lesson ID is required.",
                    [],
                    422
                );

                return;
            }


            $deleted =
                $this->lesson->delete(
                    $id
                );


            if (!$deleted) {

                $this->response(
                    false,
                    "Lesson not found.",
                    [],
                    404
                );

                return;
            }


            $this->response(
                true,
                "Lesson deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $error) {

            error_log(
                "DELETE LESSON ERROR: "
                . $error->getMessage()
            );


            $this->response(
                false,
                $error->getMessage(),
                [],
                400
            );
        }
    }


    // =====================================================
    // JSON BODY
    // =====================================================

    private function getJsonBody(): array
    {
        $raw =
            file_get_contents(
                "php://input"
            );


        if (
            $raw === false
            ||
            trim($raw) === ""
        ) {

            return [];
        }


        $data =
            json_decode(
                $raw,
                true
            );


        if (
            json_last_error()
            !==
            JSON_ERROR_NONE
        ) {

            throw new Exception(
                "Invalid JSON request: "
                . json_last_error_msg()
            );
        }


        if (!is_array($data)) {

            throw new Exception(
                "Invalid request body."
            );
        }


        return $data;
    }


    // =====================================================
    // RESPONSE
    // =====================================================

    private function response(
        bool $success,
        string $message,
        mixed $data = null,
        int $status = 200
    ): void {

        http_response_code(
            $status
        );


        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        $response = [

            "success" =>
                $success,

            "message" =>
                $message,

            "data" =>
                $data ?? []

        ];


        echo json_encode(
            $response,
            JSON_UNESCAPED_UNICODE
        );


        exit;
    }
}