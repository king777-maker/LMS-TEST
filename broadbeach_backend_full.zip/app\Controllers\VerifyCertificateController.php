<?php

class VerifyCertificateController
{
    private mysqli $db;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }


    // =========================================================
    // VERIFY CERTIFICATE
    //
    // GET:
    // /api/certificates/verify?certificate_number=BOA10110
    // =========================================================

    public function verify(): void
    {
        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        // =====================================================
        // GET CERTIFICATE NUMBER
        // =====================================================

        $certificateNumber = trim(
            (string) (
                $_GET["certificate_number"] ?? ""
            )
        );


        if ($certificateNumber === "") {

            $this->response(
                false,
                "Please enter a certificate number.",
                null,
                400
            );

            return;
        }


        try {

            // =================================================
            // CHECK DATABASE CONNECTION
            // =================================================

            if ($this->db->connect_errno) {

                throw new Exception(
                    "Database connection failed: " .
                    $this->db->connect_error
                );
            }


            // =================================================
            // GET CERTIFICATE
            //
            // certificates:
            // Contains certificate details.
            //
            // certificate_numbers:
            // Confirms that the certificate number is registered
            // and active.
            // =================================================

            $sql = "

                SELECT

                    c.id,
                    c.user_id,
                    c.certification_id,
                    c.student_name,
                    c.certificate_number,
                    c.score,
                    c.total_questions,
                    c.percentage,
                    c.pdf_path,
                    c.issued_at,
                    c.created_at,
                    c.updated_at,

                    cn.id AS certificate_number_id,
                    cn.certificate_number
                        AS registered_certificate_number,
                    cn.status
                        AS certificate_number_status,
                    cn.created_at
                        AS number_created_at,
                    cn.updated_at
                        AS number_updated_at

                FROM certificates c

                INNER JOIN certificate_numbers cn

                    ON TRIM(
                        cn.certificate_number
                    )
                    =
                    TRIM(
                        c.certificate_number
                    )

                WHERE TRIM(
                    c.certificate_number
                ) = ?

                LIMIT 1

            ";


            $stmt = $this->db->prepare($sql);


            if (!$stmt) {

                throw new Exception(
                    "Query prepare failed: " .
                    $this->db->error
                );
            }


            $stmt->bind_param(
                "s",
                $certificateNumber
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    "Query execution failed: " .
                    $stmt->error
                );
            }


            $result =
                $stmt->get_result();


            // =================================================
            // CERTIFICATE NOT FOUND
            // =================================================

            if ($result->num_rows === 0) {

                $stmt->close();

                // ---------------------------------------------
                // CHECK manual_certificates TABLE (REGISTRY PARITY)
                // ---------------------------------------------
                $manualStmt = @$this->db->prepare("
                    SELECT id, certificate_number, student_name, course_name, issue_date, status, pdf_path
                    FROM manual_certificates
                    WHERE TRIM(certificate_number) = ?
                    LIMIT 1
                ");

                if ($manualStmt) {
                    $manualStmt->bind_param("s", $certificateNumber);
                    if ($manualStmt->execute()) {
                        $mRes = $manualStmt->get_result();
                        if ($mRes && $mRes->num_rows > 0) {
                            $mCert = $mRes->fetch_assoc();
                            $manualStmt->close();

                            if ($mCert["status"] === "revoked" || $mCert["status"] === "inactive") {
                                $this->response(
                                    false,
                                    "This certificate has been revoked.",
                                    [
                                        "certificate_number" => $mCert["certificate_number"],
                                        "student_name" => $mCert["student_name"],
                                        "course_name" => $mCert["course_name"],
                                        "status" => 0,
                                        "certificate_number_status" => 0,
                                        "verification_status" => "Revoked"
                                    ],
                                    403
                                );
                                return;
                            }

                            $this->response(
                                true,
                                "Certificate verified successfully.",
                                [
                                    "certificate_number" => $mCert["certificate_number"],
                                    "student_name" => $mCert["student_name"],
                                    "course_name" => $mCert["course_name"],
                                    "issued_at" => $mCert["issue_date"],
                                    "score" => 100,
                                    "total_questions" => 100,
                                    "percentage" => 100,
                                    "certificate_number_status" => 1,
                                    "verification_status" => "Verified",
                                    "source" => "manual",
                                    "pdf_path" => $mCert["pdf_path"] ?? null
                                ],
                                200
                            );
                            return;
                        }
                    }
                    $manualStmt->close();
                }

                // ---------------------------------------------
                // CHECK certificates TABLE
                // ---------------------------------------------
                $certificateExists =
                    false;

                $certificateDebug =
                    null;


                $debugStmt =
                    $this->db->prepare("

                        SELECT
                            id,
                            user_id,
                            certification_id,
                            certificate_number,
                            student_name

                        FROM certificates

                        WHERE TRIM(
                            certificate_number
                        ) = ?

                        LIMIT 1

                    ");


                if ($debugStmt) {

                    $debugStmt->bind_param(
                        "s",
                        $certificateNumber
                    );


                    if ($debugStmt->execute()) {

                        $debugResult =
                            $debugStmt->get_result();


                        if (
                            $debugResult->num_rows > 0
                        ) {

                            $certificateExists =
                                true;

                            $certificateDebug =
                                $debugResult
                                    ->fetch_assoc();
                        }
                    }


                    $debugStmt->close();
                }


                // ---------------------------------------------
                // CHECK certificate_numbers TABLE
                // ---------------------------------------------

                $numberExists =
                    false;

                $numberDebug =
                    null;


                $numberStmt =
                    $this->db->prepare("

                        SELECT
                            id,
                            certificate_number,
                            status

                        FROM certificate_numbers

                        WHERE TRIM(
                            certificate_number
                        ) = ?

                        LIMIT 1

                    ");


                if ($numberStmt) {

                    $numberStmt->bind_param(
                        "s",
                        $certificateNumber
                    );


                    if ($numberStmt->execute()) {

                        $numberResult =
                            $numberStmt->get_result();


                        if (
                            $numberResult->num_rows > 0
                        ) {

                            $numberExists =
                                true;

                            $numberDebug =
                                $numberResult
                                    ->fetch_assoc();
                        }
                    }


                    $numberStmt->close();
                }


                // ---------------------------------------------
                // BOTH EXIST BUT DO NOT MATCH
                // ---------------------------------------------

                if (
                    $certificateExists &&
                    $numberExists
                ) {

                    $this->response(
                        false,
                        "Certificate exists in both tables, but the certificate numbers do not match exactly.",
                        [
                            "certificate_number" =>
                                $certificateNumber,

                            "certificates" =>
                                $certificateDebug,

                            "certificate_numbers" =>
                                $numberDebug,
                        ],
                        409
                    );

                    return;
                }


                // ---------------------------------------------
                // EXISTS ONLY IN certificates
                // ---------------------------------------------

                if ($certificateExists) {

                    $this->response(
                        false,
                        "Certificate exists in certificates table, but it is not registered in certificate_numbers table.",
                        [
                            "certificate_number" =>
                                $certificateNumber,

                            "certificates" =>
                                $certificateDebug,

                            "certificate_numbers" =>
                                null,
                        ],
                        404
                    );

                    return;
                }


                // ---------------------------------------------
                // EXISTS ONLY IN certificate_numbers
                // ---------------------------------------------

                if ($numberExists) {

                    $this->response(
                        false,
                        "Certificate number exists in certificate_numbers table, but certificate details are missing from certificates table.",
                        [
                            "certificate_number" =>
                                $certificateNumber,

                            "certificates" =>
                                null,

                            "certificate_numbers" =>
                                $numberDebug,
                        ],
                        404
                    );

                    return;
                }


                // ---------------------------------------------
                // DOES NOT EXIST ANYWHERE
                // ---------------------------------------------

                $this->response(
                    false,
                    "Certificate number was not found in either table.",
                    [
                        "certificate_number" =>
                            $certificateNumber,

                        "certificates" =>
                            false,

                        "certificate_numbers" =>
                            false,
                    ],
                    404
                );

                return;
            }


            // =================================================
            // GET CERTIFICATE
            // =================================================

            $certificate =
                $result->fetch_assoc();


            $stmt->close();


            // =================================================
            // CHECK ACTIVE STATUS
            // =================================================

            if (
                (int) (
                    $certificate[
                        "certificate_number_status"
                    ]
                ) !== 1
            ) {

                $this->response(
                    false,
                    "This certificate is inactive.",
                    [
                        "certificate_number" =>
                            $certificate[
                                "certificate_number"
                            ],

                        "status" =>
                            (int) (
                                $certificate[
                                    "certificate_number_status"
                                ]
                            ),
                    ],
                    403
                );

                return;
            }


            // =================================================
            // GET COURSE / CERTIFICATION NAME
            // =================================================
            //
            // We use SELECT * here so this controller does not
            // depend on one exact name column.
            //
            // It supports:
            //
            // name
            // title
            // course_name
            // certification_name
            //
            // =================================================

            $courseName =
                $this->getCourseName(
                    (int) (
                        $certificate[
                            "certification_id"
                        ]
                    )
                );


            // =================================================
            // COMPLETE PUBLIC RESPONSE
            // =================================================
            //
            // IMPORTANT:
            //
            // id
            // user_id
            // certification_id
            //
            // are intentionally NOT returned here.
            //
            // The frontend only needs the information required
            // for public certificate verification.
            //
            // =================================================

            $data = [

                // ---------------------------------------------
                // CERTIFICATE
                // ---------------------------------------------

                "certificate_number" =>
                    $certificate[
                        "certificate_number"
                    ],


                // ---------------------------------------------
                // STUDENT
                // ---------------------------------------------

                "student_name" =>
                    $certificate[
                        "student_name"
                    ],


                // ---------------------------------------------
                // COURSE
                // ---------------------------------------------

                "course_name" =>
                    $courseName,


                // ---------------------------------------------
                // RESULT
                // ---------------------------------------------

                "score" =>
                    (int) (
                        $certificate["score"]
                    ),


                "total_questions" =>
                    (int) (
                        $certificate[
                            "total_questions"
                        ]
                    ),


                "percentage" =>
                    (float) (
                        $certificate[
                            "percentage"
                        ]
                    ),


                // ---------------------------------------------
                // CERTIFICATE PDF
                // ---------------------------------------------

                "pdf_path" =>
                    $certificate[
                        "pdf_path"
                    ],


                // ---------------------------------------------
                // ISSUE DATE
                // ---------------------------------------------

                "issued_at" =>
                    $certificate[
                        "issued_at"
                    ],


                // ---------------------------------------------
                // STATUS
                // ---------------------------------------------

                "certificate_number_status" =>
                    (int) (
                        $certificate[
                            "certificate_number_status"
                        ]
                    ),


                "verification_status" =>
                    "Verified",


                "verified_from_both_tables" =>
                    true,
            ];


            // =================================================
            // SUCCESS
            // =================================================

            $this->response(
                true,
                "Certificate verified successfully.",
                $data,
                200
            );


        } catch (Throwable $e) {

            // =================================================
            // ERROR LOG
            // =================================================

            error_log(
                "VERIFY CERTIFICATE ERROR: " .
                $e->getMessage()
            );


            // =================================================
            // ERROR RESPONSE
            // =================================================

            $this->response(
                false,
                "Unable to verify certificate.",
                [
                    "error" =>
                        $e->getMessage(),

                    "certificate_number" =>
                        $certificateNumber,
                ],
                500
            );
        }
    }


    // =========================================================
    // GET COURSE NAME
    // =========================================================

    private function getCourseName(
        int $certificationId
    ): string {

        if ($certificationId <= 0) {
            return "";
        }


        // =====================================================
        // GET CERTIFICATION
        // =====================================================

        $sql = "

            SELECT *

            FROM certificates

            WHERE id = ?

            LIMIT 1

        ";


        $stmt =
            $this->db->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Unable to prepare certification query: " .
                $this->db->error
            );
        }


        $stmt->bind_param(
            "i",
            $certificationId
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "Unable to fetch certification: " .
                $error
            );
        }


        $result =
            $stmt->get_result();


        if ($result->num_rows === 0) {

            $stmt->close();

            return "";
        }


        $certification =
            $result->fetch_assoc();


        $stmt->close();


        // =====================================================
        // FIND COURSE NAME
        // =====================================================
        //
        // Different versions of the certification table may
        // use different names for the course title.
        //
        // =====================================================

        $possibleFields = [

            "name",

            "title",

            "course_name",

            "certification_name",

            "course_title",

        ];


        foreach (
            $possibleFields
            as $field
        ) {

            if (
                isset(
                    $certification[$field]
                )
                &&
                trim(
                    (string)
                    $certification[$field]
                ) !== ""
            ) {

                return trim(
                    (string)
                    $certification[$field]
                );
            }
        }


        return "";
    }


    // =========================================================
    // JSON RESPONSE
    // =========================================================

    private function response(
        bool $success,
        string $message,
        ?array $data = null,
        int $statusCode = 200
    ): void {

        http_response_code(
            $statusCode
        );


        echo json_encode(
            [
                "success" =>
                    $success,

                "status" =>
                    $success,

                "message" =>
                    $message,

                "data" =>
                    $data,
            ],

            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES |
            JSON_PRETTY_PRINT
        );


        exit;
    }
}