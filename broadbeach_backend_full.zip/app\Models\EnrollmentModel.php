<?php

class EnrollmentModel
{
    private mysqli $conn;


    public function __construct(mysqli $db)
    {
        $this->conn = $db;
    }


    // =========================================================
    // ENROLL USER
    // =========================================================

    public function enrollUser(
        int $userId,
        int $certificationId
    ): array {

        // -----------------------------------------------------
        // VALIDATE USER
        // -----------------------------------------------------

        if ($userId <= 0) {

            return [
                "success" => false,
                "message" => "Invalid user ID."
            ];
        }


        // -----------------------------------------------------
        // VALIDATE COURSE
        // -----------------------------------------------------

        if ($certificationId <= 0) {

            return [
                "success" => false,
                "message" => "Invalid certification ID."
            ];
        }


        // -----------------------------------------------------
        // CHECK USER EXISTS
        // -----------------------------------------------------

        $stmt = $this->conn->prepare("
            SELECT
                id
            FROM users
            WHERE id = ?
            LIMIT 1
        ");

        if (!$stmt) {

            throw new Exception(
                "User query prepare failed: " .
                $this->conn->error
            );
        }


        $stmt->bind_param(
            "i",
            $userId
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "User query failed: " .
                $stmt->error
            );
        }


        $result = $stmt->get_result();


        if ($result->num_rows === 0) {

            $stmt->close();

            return [
                "success" => false,
                "message" =>
                    "Logged-in user does not exist.",
                "user_id" =>
                    $userId
            ];
        }


        $stmt->close();


        // -----------------------------------------------------
        // GET COURSE
        // -----------------------------------------------------

        $stmt = $this->conn->prepare("
            SELECT
                id,
                name
            FROM free_certifications
            WHERE id = ?
            LIMIT 1
        ");


        if (!$stmt) {

            throw new Exception(
                "Course query prepare failed: " .
                $this->conn->error
            );
        }


        $stmt->bind_param(
            "i",
            $certificationId
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Course query failed: " .
                $stmt->error
            );
        }


        $result = $stmt->get_result();


        if ($result->num_rows === 0) {

            $stmt->close();

            return [
                "success" => false,
                "message" =>
                    "Course does not exist.",
                "certification_id" =>
                    $certificationId
            ];
        }


        $course = $result->fetch_assoc();

        $stmt->close();


        // -----------------------------------------------------
        // COURSE NAME
        // -----------------------------------------------------

        $courseName =
            trim(
                $course["name"] ?? ""
            );


        if ($courseName === "") {

            return [
                "success" => false,
                "message" =>
                    "Course name is missing.",
                "certification_id" =>
                    $certificationId
            ];
        }


        // -----------------------------------------------------
        // CHECK EXISTING ENROLLMENT
        // -----------------------------------------------------

        $stmt = $this->conn->prepare("
            SELECT
                id,
                user_id,
                certification_id,
                course_name,
                enrolled_at,
                status
            FROM course_enrollments
            WHERE user_id = ?
              AND certification_id = ?
            LIMIT 1
        ");


        if (!$stmt) {

            throw new Exception(
                "Enrollment check prepare failed: " .
                $this->conn->error
            );
        }


        $stmt->bind_param(
            "ii",
            $userId,
            $certificationId
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Enrollment check failed: " .
                $stmt->error
            );
        }


        $result = $stmt->get_result();


        if ($result->num_rows > 0) {

            $existing =
                $result->fetch_assoc();


            $stmt->close();


            return [
                "success" => true,

                "message" =>
                    "User is already enrolled in this course.",

                "already_enrolled" =>
                    true,

                "enrollment_id" =>
                    (int) $existing["id"],

                "user_id" =>
                    (int) $existing["user_id"],

                "certification_id" =>
                    (int) $existing["certification_id"],

                "course_name" =>
                    $existing["course_name"],

                "enrolled_at" =>
                    $existing["enrolled_at"],

                "status" =>
                    $existing["status"]
            ];
        }


        $stmt->close();


        // -----------------------------------------------------
        // INSERT ENROLLMENT
        // -----------------------------------------------------

        $status = "active";


        $stmt = $this->conn->prepare("
            INSERT INTO course_enrollments
            (
                user_id,
                certification_id,
                course_name,
                status
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?
            )
        ");


        if (!$stmt) {

            throw new Exception(
                "Enrollment INSERT prepare failed: " .
                $this->conn->error
            );
        }


        $stmt->bind_param(
            "iiss",
            $userId,
            $certificationId,
            $courseName,
            $status
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Enrollment INSERT failed: " .
                $stmt->error
            );
        }


        // -----------------------------------------------------
        // GET INSERTED ID
        // -----------------------------------------------------

        $enrollmentId =
            (int) $this->conn->insert_id;


        $stmt->close();


        if ($enrollmentId <= 0) {

            throw new Exception(
                "Enrollment was inserted but ID was not generated."
            );
        }


        // -----------------------------------------------------
        // SUCCESS
        // -----------------------------------------------------

        return [
            "success" => true,

            "message" =>
                "Course enrollment successful.",

            "already_enrolled" =>
                false,

            "enrollment_id" =>
                $enrollmentId,

            "user_id" =>
                $userId,

            "certification_id" =>
                $certificationId,

            "course_name" =>
                $courseName,

            "status" =>
                $status
        ];
    }


    // =========================================================
    // GET USER ENROLLMENTS / COMPLETED COURSES
    // =========================================================

    public function getUserEnrollments(
        int $userId
    ): array {

        if ($userId <= 0) {

            return [];
        }


        /*
        =========================================================
        IMPORTANT

        We get the latest certificate belonging to the same:

            user_id
            certification_id

        This gives MyProfile.jsx:

            certificate_number
            score
            total_questions
            percentage
            issued_at
            pdf_path

        =========================================================
        */

        $sql = "
            SELECT

                ce.id,
                ce.user_id,
                ce.certification_id,
                ce.course_name,
                ce.enrolled_at,
                ce.status,

                cert.id AS certificate_id,
                cert.certificate_number,
                cert.student_name,
                cert.score,
                cert.total_questions,
                cert.percentage,
                cert.pdf_path,
                cert.issued_at

            FROM course_enrollments AS ce

            LEFT JOIN certificates AS cert
                ON cert.id = (

                    SELECT
                        c2.id

                    FROM certificates AS c2

                    WHERE c2.user_id = ce.user_id
                      AND c2.certification_id =
                          ce.certification_id

                    ORDER BY c2.id DESC

                    LIMIT 1
                )

            WHERE ce.user_id = ?

            ORDER BY ce.enrolled_at DESC
        ";


        $stmt =
            $this->conn->prepare($sql);


        if (!$stmt) {

            throw new Exception(
                "Enrollment list prepare failed: " .
                $this->conn->error
            );
        }


        $stmt->bind_param(
            "i",
            $userId
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Enrollment list failed: " .
                $stmt->error
            );
        }


        $result =
            $stmt->get_result();


        $data = [];


        while (
            $row =
            $result->fetch_assoc()
        ) {

            // -------------------------------------------------
            // NORMALIZE TYPES
            // -------------------------------------------------

            $row["id"] =
                (int) $row["id"];

            $row["user_id"] =
                (int) $row["user_id"];

            $row["certification_id"] =
                (int) $row["certification_id"];


            if (
                $row["certificate_id"] !== null
            ) {

                $row["certificate_id"] =
                    (int) $row["certificate_id"];

            }


            $row["score"] =
                $row["score"] !== null
                    ? (int) $row["score"]
                    : null;


            $row["total_questions"] =
                $row["total_questions"] !== null
                    ? (int) $row["total_questions"]
                    : null;


            $row["percentage"] =
                $row["percentage"] !== null
                    ? (float) $row["percentage"]
                    : null;


            // -------------------------------------------------
            // -------------------------------------------------
            // COMPLETION DATE
            // -------------------------------------------------

            $row["completion_date"] =
                $row["issued_at"] ?? null;


            // -------------------------------------------------
            // CERTIFICATE STATUS & COURSE COMPLETION
            // -------------------------------------------------

            $isCompleted =
                (isset($row["status"]) && strtolower($row["status"]) === "completed")
                || !empty($row["certificate_id"]);

            $row["completed"] = $isCompleted;
            if ($isCompleted) {
                $row["status"] = "Completed";
                $row["progress"] = 100;
            }


            $data[] = $row;
        }


        $stmt->close();


        return $data;
    }


    // =========================================================
    // MARK COURSE COMPLETED
    // =========================================================

    public function markCourseCompleted(
        int $userId,
        int $certificationId
    ): bool {
        if ($userId <= 0 || $certificationId <= 0) {
            return false;
        }

        try {
            $stmt = $this->conn->prepare("
                UPDATE course_enrollments
                SET status = 'completed'
                WHERE user_id = ?
                  AND certification_id = ?
            ");

            if (!$stmt) {
                return false;
            }

            $stmt->bind_param("ii", $userId, $certificationId);
            $success = $stmt->execute();
            $stmt->close();

            return $success;
        } catch (Throwable $e) {
            return false;
        }
    }
}