<?php

require_once __DIR__ . "/../Query.php";


class User
{
    private Query $query;

    private string $table =
        "users";


    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct(
        mysqli $db
    ) {

        $this->query =
            new Query($db);

    }


    // ==========================================
    // GET BY ID
    // ==========================================

    public function getById(
        int $id
    ): ?array {

        return $this->query->getById(
            $this->table,
            $id
        );
    }


    // ==========================================
    // GET BY EMAIL
    // ==========================================

    public function getByEmail(
        string $email
    ): ?array {

        return $this->query->getOne(
            $this->table,
            "email",
            $email
        );
    }


    // ==========================================
    // EMAIL EXISTS
    // ==========================================

    public function emailExists(
        string $email
    ): bool {

        return $this->query->exists(
            $this->table,
            "email",
            $email
        );
    }


    // ==========================================
    // PHONE EXISTS
    // ==========================================

    public function phoneExists(
        string $phone
    ): bool {

        return $this->query->exists(
            $this->table,
            "phone",
            $phone
        );
    }


    // ==========================================
    // REGISTER
    // ==========================================

    public function register(
        array $data
    ): int {

        return $this->query->insert(
            $this->table,
            $data
        );
    }


    // ==========================================
    // UPDATE
    // ==========================================

    public function update(
        int $id,
        array $data
    ): bool {

        return $this->query->update(
            $this->table,
            $id,
            $data
        );
    }
}