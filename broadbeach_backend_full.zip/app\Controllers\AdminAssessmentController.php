<?php

require_once __DIR__
    . "/../Models/Assessment.php";


class AdminAssessmentController
{
    private mysqli $db;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(
        mysqli $db
    ) {
        $this->db = $db;
    }


    // =====================================================
    // GET ALL COURSE ASSESSMENTS
    //
    // GET:
    // /api/admin/course-assessments
    // =====================================================

    public function getAll(): void
    {
        try {

            $sql = "
                SELECT
                    ca.id,
                    ca.certification_id,
                    ca.title,
                    ca.duration_minutes,
                    ca.passing_percentage,
                    ca.status,
                    ca.created_at,
                    ca.updated_at,

                    fc.name AS certification_name

                FROM course_assessments ca

                LEFT JOIN free_certifications fc
                    ON fc.id = ca.certification_id

                ORDER BY
                    ca.id ASC
            ";


            $stmt =
                $this->db->prepare($sql);


            if (!$stmt) {

                throw new Exception(
                    "Unable to prepare assessment query: "
                    . $this->db->error
                );
            }


            if (!$stmt->execute()) {

                $error =
                    $stmt->error;

                $stmt->close();

                throw new Exception(
                    "Unable to fetch assessments: "
                    . $error
                );
            }


            $result =
                $stmt->get_result();


            $assessments = [];


            while (
                $row =
                    $result->fetch_assoc()
            ) {

                $row["id"] =
                    (int) $row["id"];


                $row["certification_id"] =
                    (int) $row["certification_id"];


                $row["duration_minutes"] =
                    (int) $row["duration_minutes"];


                $row["passing_percentage"] =
                    (float) $row["passing_percentage"];


                $assessments[] =
                    $row;
            }


            $stmt->close();


            $this->response(
                true,
                "Assessments fetched successfully.",
                $assessments
            );


        } catch (Throwable $error) {

            $this->response(
                false,
                $error->getMessage(),
                [],
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE ASSESSMENT
    //
    // GET:
    // /api/admin/course-assessment?id=1
    // =====================================================

    public function getById(): void
    {
        $id =
            isset($_GET["id"])
                ? (int) $_GET["id"]
                : 0;


        if ($id <= 0) {

            $this->response(
                false,
                "Assessment ID is required.",
                null,
                422
            );

            return;
        }


        try {

            $sql = "
                SELECT
                    ca.id,
                    ca.certification_id,
                    ca.title,
                    ca.duration_minutes,
                    ca.passing_percentage,
                    ca.status,
                    ca.created_at,
                    ca.updated_at,

                    fc.name AS certification_name

                FROM course_assessments ca

                LEFT JOIN free_certifications fc
                    ON fc.id = ca.certification_id

                WHERE ca.id = ?

                LIMIT 1
            ";


            $stmt =
                $this->db->prepare($sql);


            if (!$stmt) {

                throw new Exception(
                    "Unable to prepare assessment query: "
                    . $this->db->error
                );
            }


            $stmt->bind_param(
                "i",
                $id
            );


            if (!$stmt->execute()) {

                $error =
                    $stmt->error;

                $stmt->close();

                throw new Exception(
                    "Unable to fetch assessment: "
                    . $error
                );
            }


            $result =
                $stmt->get_result();


            $assessment =
                $result->fetch_assoc();


            $stmt->close();


            if (!$assessment) {

                $this->response(
                    false,
                    "Assessment not found.",
                    null,
                    404
                );

                return;
            }


            $assessment["id"] =
                (int) $assessment["id"];


            $assessment["certification_id"] =
                (int) $assessment["certification_id"];


            $assessment["duration_minutes"] =
                (int) $assessment["duration_minutes"];


            $assessment["passing_percentage"] =
                (float) $assessment["passing_percentage"];


            $this->response(
                true,
                "Assessment fetched successfully.",
                $assessment
            );


        } catch (Throwable $error) {

            $this->response(
                false,
                $error->getMessage(),
                null,
                500
            );
        }
    }


    // =====================================================
    // RESPONSE
    // =====================================================

    private function response(
        bool $success,
        string $message,
        mixed $data = null,
        int $status = 200
    ): void {

        http_response_code(
            $status
        );


        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        $response = [

            "success" =>
                $success,

            "message" =>
                $message
        ];


        if ($data !== null) {

            $response["data"] =
                $data;
        }


        echo json_encode(
            $response
        );


        exit;
    }
}