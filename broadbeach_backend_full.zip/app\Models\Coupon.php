<?php


class Coupon
{
    private mysqli $conn;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->conn = $db;
    }


    // =====================================================
    // FIND VALID COUPON
    // =====================================================

    public function findValidCoupon(
        string $code,
        int $courseId
    ): ?array {

        $sql = "
            SELECT
                id,
                code,
                course_id,
                max_uses,
                used_count,
                expires_at,
                status
            FROM course_coupons

            WHERE code = ?

            AND status = 1

            AND (
                course_id = ?
                OR course_id IS NULL
            )

            AND (
                expires_at IS NULL
                OR expires_at >= NOW()
            )

            LIMIT 1
        ";


        $stmt =
            $this->conn->prepare(
                $sql
            );


        if (!$stmt) {

            throw new Exception(
                "findValidCoupon prepare failed: "
                . $this->conn->error
            );
        }


        $stmt->bind_param(
            "si",
            $code,
            $courseId
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "findValidCoupon execute failed: "
                . $error
            );
        }


        $result =
            $stmt->get_result();


        $coupon =
            $result->fetch_assoc();


        $stmt->close();


        return $coupon ?: null;
    }


    // =====================================================
    // CHECK ALREADY REDEEMED
    // =====================================================

    public function alreadyRedeemed(
        int $couponId,
        int $userId,
        int $courseId
    ): bool {

        $sql = "
            SELECT id

            FROM course_coupon_redemptions

            WHERE coupon_id = ?

            AND user_id = ?

            AND course_id = ?

            LIMIT 1
        ";


        $stmt =
            $this->conn->prepare(
                $sql
            );


        // IMPORTANT
        if (!$stmt) {

            throw new Exception(
                "alreadyRedeemed prepare failed: "
                . $this->conn->error
            );
        }


        $stmt->bind_param(
            "iii",
            $couponId,
            $userId,
            $courseId
        );


        if (!$stmt->execute()) {

            $error =
                $stmt->error;

            $stmt->close();

            throw new Exception(
                "alreadyRedeemed execute failed: "
                . $error
            );
        }


        $result =
            $stmt->get_result();


        $exists =
            $result->num_rows > 0;


        $stmt->close();


        return $exists;
    }


    // =====================================================
    // REDEEM COUPON
    // =====================================================

    public function redeem(
        int $couponId,
        int $userId,
        int $courseId
    ): bool {

        try {

            // =============================================
            // START TRANSACTION
            // =============================================

            $this->conn
                ->begin_transaction();


            // =============================================
            // LOCK COUPON
            // =============================================

            $sql = "
                SELECT
                    max_uses,
                    used_count

                FROM course_coupons

                WHERE id = ?

                AND status = 1

                FOR UPDATE
            ";


            $stmt =
                $this->conn->prepare(
                    $sql
                );


            if (!$stmt) {

                throw new Exception(
                    "Coupon lock prepare failed: "
                    . $this->conn->error
                );
            }


            $stmt->bind_param(
                "i",
                $couponId
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    "Coupon lock execute failed: "
                    . $stmt->error
                );
            }


            $result =
                $stmt->get_result();


            $coupon =
                $result->fetch_assoc();


            $stmt->close();


            if (!$coupon) {

                throw new Exception(
                    "Coupon not found."
                );
            }


            // =============================================
            // CHECK MAX USES
            // =============================================

            if (
                $coupon["max_uses"] !== null
                &&
                (int) $coupon["max_uses"] > 0
                &&
                (int) $coupon["used_count"]
                    >=
                (int) $coupon["max_uses"]
            ) {

                throw new Exception(
                    "Coupon usage limit reached."
                );
            }


            // =============================================
            // DOUBLE CHECK REDEMPTION
            // INSIDE TRANSACTION
            // =============================================

            $sql = "
                SELECT id

                FROM course_coupon_redemptions

                WHERE coupon_id = ?

                AND user_id = ?

                AND course_id = ?

                LIMIT 1
            ";


            $stmt =
                $this->conn->prepare(
                    $sql
                );


            if (!$stmt) {

                throw new Exception(
                    "Redemption check prepare failed: "
                    . $this->conn->error
                );
            }


            $stmt->bind_param(
                "iii",
                $couponId,
                $userId,
                $courseId
            );


            $stmt->execute();


            $existing =
                $stmt
                    ->get_result()
                    ->fetch_assoc();


            $stmt->close();


            if ($existing) {

                // Already redeemed = access already exists

                $this->conn->commit();

                return true;
            }


            // =============================================
            // INSERT REDEMPTION
            // =============================================

            $sql = "
                INSERT INTO
                    course_coupon_redemptions
                (
                    coupon_id,
                    user_id,
                    course_id
                )

                VALUES (?, ?, ?)
            ";


            $stmt =
                $this->conn->prepare(
                    $sql
                );


            if (!$stmt) {

                throw new Exception(
                    "Redemption insert prepare failed: "
                    . $this->conn->error
                );
            }


            $stmt->bind_param(
                "iii",
                $couponId,
                $userId,
                $courseId
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    "Redemption insert failed: "
                    . $stmt->error
                );
            }


            $stmt->close();


            // =============================================
            // UPDATE USED COUNT
            // =============================================

            $sql = "
                UPDATE course_coupons

                SET used_count =
                    used_count + 1

                WHERE id = ?
            ";


            $stmt =
                $this->conn->prepare(
                    $sql
                );


            if (!$stmt) {

                throw new Exception(
                    "Coupon update prepare failed: "
                    . $this->conn->error
                );
            }


            $stmt->bind_param(
                "i",
                $couponId
            );


            if (!$stmt->execute()) {

                throw new Exception(
                    "Coupon update failed: "
                    . $stmt->error
                );
            }


            $stmt->close();


            // =============================================
            // COMMIT
            // =============================================

            $this->conn->commit();


            return true;

        } catch (Throwable $e) {


            // =============================================
            // ROLLBACK
            // =============================================

            try {

                $this->conn
                    ->rollback();

            } catch (Throwable $ignored) {
            }


            // Development only
            error_log(
                "COUPON REDEEM ERROR: "
                . $e->getMessage()
            );


            return false;
        }
    }
}