<?php

class AdminAssessment
{
    private mysqli $db;

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }


    // =====================================================
    // GET ALL ASSESSMENTS
    // =====================================================

    public function getAll(): array
    {
        $sql = "
            SELECT
                ca.id,
                ca.certification_id,
                ca.title,
                ca.duration_minutes,
                ca.passing_percentage,
                ca.status,
                ca.created_at,
                ca.updated_at,

                fc.name AS certification_name

            FROM course_assessments ca

            LEFT JOIN free_certifications fc
                ON fc.id = ca.certification_id

            ORDER BY
                ca.id DESC
        ";

        $stmt = $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare assessment query: "
                . $this->db->error
            );
        }

        if (!$stmt->execute()) {
            throw new Exception(
                "Failed to fetch assessments: "
                . $stmt->error
            );
        }

        $result = $stmt->get_result();

        $assessments = [];

        while ($row = $result->fetch_assoc()) {

            $row["id"] =
                (int) $row["id"];

            $row["certification_id"] =
                (int) $row["certification_id"];

            $row["duration_minutes"] =
                (int) $row["duration_minutes"];

            $row["passing_percentage"] =
                (float) $row["passing_percentage"];

            $assessments[] = $row;
        }

        return $assessments;
    }


    // =====================================================
    // GET SINGLE ASSESSMENT
    // =====================================================

    public function getById(
        int $id
    ): ?array
    {
        $sql = "
            SELECT
                ca.id,
                ca.certification_id,
                ca.title,
                ca.duration_minutes,
                ca.passing_percentage,
                ca.status,
                ca.created_at,
                ca.updated_at,

                fc.name AS certification_name

            FROM course_assessments ca

            LEFT JOIN free_certifications fc
                ON fc.id = ca.certification_id

            WHERE ca.id = ?

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        if (!$stmt) {
            throw new Exception(
                "Failed to prepare assessment query: "
                . $this->db->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );

        if (!$stmt->execute()) {
            throw new Exception(
                "Failed to fetch assessment: "
                . $stmt->error
            );
        }

        $result = $stmt->get_result();

        $assessment =
            $result->fetch_assoc();

        if (!$assessment) {
            return null;
        }

        $assessment["id"] =
            (int) $assessment["id"];

        $assessment["certification_id"] =
            (int) $assessment["certification_id"];

        $assessment["duration_minutes"] =
            (int) $assessment["duration_minutes"];

        $assessment["passing_percentage"] =
            (float) $assessment["passing_percentage"];

        return $assessment;
    }


    // =====================================================
    // CREATE ASSESSMENT
    // =====================================================

    public function create(
        array $data
    ): array
    {
        $certificationId =
            (int) (
                $data["certification_id"]
                ?? 0
            );

        $title =
            trim(
                (string) (
                    $data["title"]
                    ?? ""
                )
            );

        $durationMinutes =
            (int) (
                $data["duration_minutes"]
                ?? 0
            );

        $passingPercentage =
            (float) (
                $data["passing_percentage"]
                ?? 60
            );

        $status =
            trim(
                (string) (
                    $data["status"]
                    ?? "active"
                )
            );


        // =================================================
        // VALIDATION
        // =================================================

        if ($certificationId <= 0) {

            throw new Exception(
                "Certification ID is required."
            );
        }

        if ($title === "") {

            throw new Exception(
                "Assessment title is required."
            );
        }

        if ($durationMinutes <= 0) {

            throw new Exception(
                "Duration must be greater than 0."
            );
        }

        if (
            $passingPercentage < 0
            ||
            $passingPercentage > 100
        ) {

            throw new Exception(
                "Passing percentage must be between 0 and 100."
            );
        }

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {

            $status = "active";
        }


        // =================================================
        // INSERT
        // =================================================

        $sql = "
            INSERT INTO course_assessments
            (
                certification_id,
                title,
                duration_minutes,
                passing_percentage,
                status,
                created_at,
                updated_at
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                NOW(),
                NOW()
            )
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {

            throw new Exception(
                "Failed to prepare create assessment query: "
                . $this->db->error
            );
        }

        $stmt->bind_param(
            "isids",
            $certificationId,
            $title,
            $durationMinutes,
            $passingPercentage,
            $status
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Failed to create assessment: "
                . $stmt->error
            );
        }


        $id =
            (int) $this->db->insert_id;


        // =================================================
        // RETURN CREATED RECORD
        // =================================================

        $assessment =
            $this->getById($id);

        if (!$assessment) {

            throw new Exception(
                "Assessment was created but could not be retrieved."
            );
        }

        return $assessment;
    }


    // =====================================================
    // UPDATE ASSESSMENT
    // =====================================================

    public function update(
        array $data
    ): array
    {
        $id =
            (int) (
                $data["id"]
                ?? 0
            );

        $certificationId =
            (int) (
                $data["certification_id"]
                ?? 0
            );

        $title =
            trim(
                (string) (
                    $data["title"]
                    ?? ""
                )
            );

        $durationMinutes =
            (int) (
                $data["duration_minutes"]
                ?? 0
            );

        $passingPercentage =
            (float) (
                $data["passing_percentage"]
                ?? 60
            );

        $status =
            trim(
                (string) (
                    $data["status"]
                    ?? "active"
                )
            );


        // =================================================
        // VALIDATION
        // =================================================

        if ($id <= 0) {

            throw new Exception(
                "Assessment ID is required."
            );
        }

        if ($certificationId <= 0) {

            throw new Exception(
                "Certification ID is required."
            );
        }

        if ($title === "") {

            throw new Exception(
                "Assessment title is required."
            );
        }

        if ($durationMinutes <= 0) {

            throw new Exception(
                "Duration must be greater than 0."
            );
        }

        if (
            $passingPercentage < 0
            ||
            $passingPercentage > 100
        ) {

            throw new Exception(
                "Passing percentage must be between 0 and 100."
            );
        }

        if (
            !in_array(
                $status,
                ["active", "inactive"],
                true
            )
        ) {

            $status = "active";
        }


        // =================================================
        // CHECK EXISTS
        // =================================================

        $existing =
            $this->getById($id);

        if (!$existing) {

            throw new Exception(
                "Assessment not found."
            );
        }


        // =================================================
        // UPDATE
        // =================================================

        $sql = "
            UPDATE course_assessments

            SET
                certification_id = ?,
                title = ?,
                duration_minutes = ?,
                passing_percentage = ?,
                status = ?,
                updated_at = NOW()

            WHERE id = ?
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {

            throw new Exception(
                "Failed to prepare update assessment query: "
                . $this->db->error
            );
        }

        $stmt->bind_param(
            "isidsi",
            $certificationId,
            $title,
            $durationMinutes,
            $passingPercentage,
            $status,
            $id
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Failed to update assessment: "
                . $stmt->error
            );
        }


        // =================================================
        // RETURN UPDATED RECORD
        // =================================================

        $assessment =
            $this->getById($id);

        if (!$assessment) {

            throw new Exception(
                "Assessment updated but could not be retrieved."
            );
        }

        return $assessment;
    }


    // =====================================================
    // DELETE ASSESSMENT
    // =====================================================

    public function delete(
        int $id
    ): bool
    {
        if ($id <= 0) {

            throw new Exception(
                "Assessment ID is required."
            );
        }


        // =================================================
        // CHECK EXISTS
        // =================================================

        $existing =
            $this->getById($id);

        if (!$existing) {

            return false;
        }


        // =================================================
        // DELETE
        // =================================================

        $sql = "
            DELETE FROM course_assessments
            WHERE id = ?
        ";

        $stmt =
            $this->db->prepare($sql);

        if (!$stmt) {

            throw new Exception(
                "Failed to prepare delete assessment query: "
                . $this->db->error
            );
        }

        $stmt->bind_param(
            "i",
            $id
        );


        if (!$stmt->execute()) {

            throw new Exception(
                "Failed to delete assessment: "
                . $stmt->error
            );
        }


        return $stmt->affected_rows > 0;
    }
}