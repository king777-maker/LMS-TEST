<?php


require_once __DIR__
    . "/../Models/Coupon.php";


class CouponController
{
    private $coupon;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct($db)
    {
        $this->coupon =
            new Coupon($db);
    }


    // =====================================================
    // REDEEM COUPON
    // =====================================================

    public function redeem()
    {
        header(
            "Content-Type: application/json; charset=UTF-8"
        );


        // =================================================
        // START SESSION
        // =================================================

        if (
            session_status()
            === PHP_SESSION_NONE
        ) {

            session_start();

        }


        // =================================================
        // GET JSON BODY
        // =================================================

        $rawData =
            file_get_contents(
                "php://input"
            );


        $data =
            json_decode(
                $rawData,
                true
            );


        if (
            !is_array($data)
        ) {

            http_response_code(400);

            echo json_encode([
                "success" => false,
                "message" =>
                    "Invalid request data."
            ]);

            return;
        }


        // =================================================
        // GET COUPON CODE
        // =================================================

        $code =
            strtoupper(
                trim(
                    $data["code"] ?? ""
                )
            );


        // =================================================
        // GET COURSE ID
        // =================================================

        $courseId =
            (int) (
                $data["course_id"] ?? 0
            );


        // =================================================
        // GET LOGGED-IN USER ID
        // =================================================
        //
        // First preference:
        // PHP session
        //
        // Temporary fallback:
        // React user_id
        //
        // =================================================

        $userId = 0;


        // Standard session
        if (
            isset(
            $_SESSION["user_id"]
        )
        ) {

            $userId =
                (int) 
                $_SESSION["user_id"];

        }


        // Some applications store:
        // $_SESSION["user"]["id"]
        else if (
            isset(
            $_SESSION["user"]["id"]
        )
        ) {

            $userId =
                (int) 
                $_SESSION["user"]["id"];

        }


        // Some applications use:
        // $_SESSION["id"]
        else if (
            isset(
            $_SESSION["id"]
        )
        ) {

            $userId =
                (int) 
                $_SESSION["id"];

        }


        // Temporary React fallback
        else if (
            isset(
            $data["user_id"]
        )
        ) {

            $userId =
                (int) 
                $data["user_id"];

        }


        // =================================================
        // CHECK LOGIN
        // =================================================

        if (
            $userId <= 0
        ) {

            http_response_code(401);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Unable to identify the logged-in user.",

                "debug" => [
                    "session_id" =>
                        session_id(),

                    "session_keys" =>
                        array_keys(
                            $_SESSION
                        )
                ]
            ]);


            return;
        }


        // =================================================
        // VALIDATE COUPON CODE
        // =================================================

        if (
            empty($code)
        ) {

            http_response_code(422);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Please enter an access code."
            ]);


            return;
        }


        // =================================================
        // VALIDATE COURSE
        // =================================================

        if (
            $courseId <= 0
        ) {

            http_response_code(422);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Course ID is required."
            ]);


            return;
        }


        // =================================================
        // FIND VALID COUPON
        // =================================================

        $coupon =
            $this->coupon
                ->findValidCoupon(
                    $code,
                    $courseId
                );


        // =================================================
        // INVALID / EXPIRED COUPON
        // =================================================

        if (
            !$coupon
        ) {

            http_response_code(404);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Invalid or expired access code."
            ]);


            return;
        }


        // =================================================
        // CHECK MAXIMUM USAGE
        // =================================================

        if (
            $coupon["max_uses"] !== null
            &&
            (int) 
            $coupon["max_uses"] > 0
            &&
            (int) 
            $coupon["used_count"]
            >=
            (int) 
            $coupon["max_uses"]
        ) {

            http_response_code(409);


            echo json_encode([
                "success" => false,

                "message" =>
                    "This access code has reached its usage limit."
            ]);


            return;
        }


        // =================================================
        // CHECK IF USER ALREADY REDEEMED
        // =================================================

        try {

            $alreadyRedeemed =
                $this->coupon
                    ->alreadyRedeemed(
                        (int) $coupon["id"],
                        $userId,
                        $courseId
                    );

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "success" => false,

                "message" =>
                    "Unable to check coupon redemption.",

                // DEVELOPMENT ONLY
                "debug" =>
                    $e->getMessage()
            ]);

            return;
        }


        if (
            $alreadyRedeemed
        ) {

            http_response_code(200);


            echo json_encode([

                "success" => true,

                "certificate_access" =>
                    true,

                "already_redeemed" =>
                    true,

                "user_id" =>
                    $userId,

                "course_id" =>
                    $courseId,

                "message" =>
                    "Certificate access is already enabled for this course."

            ]);


            return;
        }


        // =================================================
        // REDEEM COUPON
        // =================================================

        $redeemed =
            $this->coupon
                ->redeem(
                    (int) 
                    $coupon["id"],

                    $userId,

                    $courseId
                );


        // =================================================
        // REDEMPTION FAILED
        // =================================================

        if (
            !$redeemed
        ) {

            http_response_code(409);


            echo json_encode([
                "success" => false,

                "message" =>
                    "Unable to redeem this access code. Please try again."
            ]);


            return;
        }


        // =================================================
        // SUCCESS
        // =================================================

        http_response_code(200);


        echo json_encode([

            "success" =>
                true,

            "certificate_access" =>
                true,

            "already_redeemed" =>
                false,

            "user_id" =>
                $userId,

            "course_id" =>
                $courseId,

            "message" =>
                "Access code verified successfully. Certificate access has been unlocked."

        ]);


        return;
    }
}