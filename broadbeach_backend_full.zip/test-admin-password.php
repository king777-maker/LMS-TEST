<?php

require_once __DIR__ . "/app/config/Database.php";

$email = "admin@broadbeachlearning.com";
$password = "admin_broadbeach_2026";

$database = new Database();
$db = $database->connect();

$stmt = $db->prepare("
    SELECT id, email, password, status
    FROM admin_users
    WHERE email = ?
    LIMIT 1
");

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("ADMIN NOT FOUND");
}

$admin = $result->fetch_assoc();

echo "<pre>";

echo "Email: " . $admin["email"] . PHP_EOL;
echo "Status: " . $admin["status"] . PHP_EOL;
echo "Hash length: " . strlen($admin["password"]) . PHP_EOL;
echo "Hash: " . $admin["password"] . PHP_EOL;

echo PHP_EOL;

if (password_verify($password, $admin["password"])) {
    echo "PASSWORD VERIFY: SUCCESS";
} else {
    echo "PASSWORD VERIFY: FAILED";
}

echo "</pre>";