<?php

require_once __DIR__ . "/../Models/Course.php";


class CourseController
{
    private Course $courseModel;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $conn)
    {
        $this->courseModel =
            new Course($conn);
    }


    // =====================================================
    // GET COURSE DETAILS BY SLUG
    // =====================================================

    public function getCourseBySlug(string $slug): void
    {
        try {

            // ---------------------------------------------
            // CLEAN SLUG
            // ---------------------------------------------

            $slug = trim($slug);


            // ---------------------------------------------
            // VALIDATION
            // ---------------------------------------------

            if ($slug === "") {

                http_response_code(400);

                echo json_encode([
                    "success" => false,
                    "message" => "Course slug is required"
                ]);

                return;
            }


            // ---------------------------------------------
            // GET COURSE
            // ---------------------------------------------

            $course =
                $this->courseModel
                    ->getCourseBySlug($slug);


            // ---------------------------------------------
            // COURSE NOT FOUND
            // ---------------------------------------------

            if (!$course) {

                http_response_code(404);

                echo json_encode([
                    "success" => false,
                    "message" => "Course not found"
                ]);

                return;
            }


            // ---------------------------------------------
            // SUCCESS
            // ---------------------------------------------

            http_response_code(200);

            echo json_encode([
                "success" => true,
                "data" => $course
            ]);


        } catch (Throwable $e) {

            // ---------------------------------------------
            // SERVER ERROR
            // ---------------------------------------------

            http_response_code(500);

            echo json_encode([
                "success" => false,
                "message" =>
                    "Failed to fetch course details",

                "error" =>
                    $e->getMessage()
            ]);
        }
    }
}