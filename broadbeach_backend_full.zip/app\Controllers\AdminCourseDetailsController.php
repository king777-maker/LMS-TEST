<?php

class AdminCourseDetailsController
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }


    // =====================================================
    // JSON RESPONSE
    // =====================================================

    private function response(
        $success,
        $message,
        $data = null,
        $statusCode = 200
    ) {

        http_response_code($statusCode);

        echo json_encode([
            "success" => $success,
            "status" => $success,
            "message" => $message,
            "data" => $data
        ]);

        exit;
    }


    // =====================================================
    // READ JSON INPUT
    // =====================================================

    private function getJsonInput()
    {
        $input = file_get_contents("php://input");

        if (!$input) {
            return [];
        }

        $data = json_decode($input, true);

        if (!is_array($data)) {
            return [];
        }

        return $data;
    }


    // =====================================================
    // NORMALIZE DB VALUES
    // =====================================================
    // MySQL TEXT/LONGTEXT columns receive strings.
    // If React sends an array/object, store it as JSON.

    private function normalizeValue($value)
    {
        if (is_array($value) || is_object($value)) {
            return json_encode(
                $value,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
        }

        if (is_bool($value)) {
            return $value ? "1" : "0";
        }

        if ($value === null) {
            return null;
        }

        return (string) $value;
    }


    // =====================================================
    // DECODE JSON TEXT VALUES
    // =====================================================

    private function decodeIfJson($value)
    {
        if (!is_string($value) || $value === "") {
            return $value;
        }

        $decoded = json_decode($value, true);

        return (
            json_last_error() === JSON_ERROR_NONE
            &&
            is_array($decoded)
        )
            ? $decoded
            : $value;
    }


    // =====================================================
    // GET ALL COURSE DETAILS
    //
    // GET /api/admin/course-details
    //
    // Optional:
    // ?course_item_id=320
    // =====================================================

    public function getAll()
    {
        try {

            $courseItemId =
                isset($_GET["course_item_id"])
                    ? (int) $_GET["course_item_id"]
                    : 0;


            $sql = "
                SELECT
                    cd.id,
                    cd.course_item_id,
                    cd.short_description,
                    cd.overview,
                    cd.course_image,
                    cd.duration,
                    cd.level,
                    cd.language,
                    cd.certification,
                    cd.learning_objectives,
                    cd.course_content,
                    cd.target_audience,
                    cd.prerequisites,
                    cd.benefits,
                    cd.assessment,
                    cd.certification_details,
                    cd.meta_title,
                    cd.meta_description,
                    cd.status,
                    cd.created_at,
                    cd.updated_at,

                    cmi.name AS course_name,
                    cmi.slug AS course_slug,
                    cmi.path AS course_path

                FROM course_details cd

                LEFT JOIN course_menu_items cmi
                    ON cmi.id = cd.course_item_id
            ";


            if ($courseItemId > 0) {

                $sql .= "
                    WHERE cd.course_item_id = ?
                ";

            }


            $sql .= "
                ORDER BY cd.id DESC
            ";


            $stmt = $this->db->prepare($sql);


            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare course details query.",
                    null,
                    500
                );
            }


            if ($courseItemId > 0) {

                $stmt->bind_param(
                    "i",
                    $courseItemId
                );
            }


            $stmt->execute();


            $result = $stmt->get_result();


            $data = [];


            while ($row = $result->fetch_assoc()) {

                $row["id"] =
                    (int) $row["id"];

                $row["course_item_id"] =
                    (int) $row["course_item_id"];

                $row["status"] =
                    (int) $row["status"];

                // Return JSON fields as arrays when they were stored as JSON.
                $jsonFields = [
                    "learning_objectives",
                    "course_content",
                    "target_audience",
                    "prerequisites",
                    "benefits",
                    "assessment",
                    "certification_details"
                ];

                foreach ($jsonFields as $jsonField) {
                    if (array_key_exists($jsonField, $row)) {
                        $row[$jsonField] =
                            $this->decodeIfJson($row[$jsonField]);
                    }
                }


                $data[] = $row;
            }


            $stmt->close();


            $this->response(
                true,
                "Course details fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to fetch course details.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }


    // =====================================================
    // GET SINGLE COURSE DETAILS
    //
    // GET /api/admin/course-details/1
    // =====================================================

    public function getById($id = null)
    {
        try {

            if ($id === null) {

                $id =
                    isset($_GET["id"])
                        ? (int) $_GET["id"]
                        : 0;
            }


            $id = (int) $id;


            if ($id <= 0) {

                $this->response(
                    false,
                    "Valid course details ID is required.",
                    null,
                    400
                );
            }


            $sql = "
                SELECT
                    cd.id,
                    cd.course_item_id,
                    cd.short_description,
                    cd.overview,
                    cd.course_image,
                    cd.duration,
                    cd.level,
                    cd.language,
                    cd.certification,
                    cd.learning_objectives,
                    cd.course_content,
                    cd.target_audience,
                    cd.prerequisites,
                    cd.benefits,
                    cd.assessment,
                    cd.certification_details,
                    cd.meta_title,
                    cd.meta_description,
                    cd.status,
                    cd.created_at,
                    cd.updated_at,

                    cmi.name AS course_name,
                    cmi.slug AS course_slug,
                    cmi.path AS course_path

                FROM course_details cd

                LEFT JOIN course_menu_items cmi
                    ON cmi.id = cd.course_item_id

                WHERE cd.id = ?

                LIMIT 1
            ";


            $stmt =
                $this->db->prepare($sql);


            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare query.",
                    null,
                    500
                );
            }


            $stmt->bind_param(
                "i",
                $id
            );


            $stmt->execute();


            $result =
                $stmt->get_result();


            $data =
                $result->fetch_assoc();


            $stmt->close();


            if (!$data) {

                $this->response(
                    false,
                    "Course details not found.",
                    null,
                    404
                );
            }


            $data["id"] =
                (int) $data["id"];

            $data["course_item_id"] =
                (int) $data["course_item_id"];

            $data["status"] =
                (int) $data["status"];

            // Return JSON fields as arrays when they were stored as JSON.
            $jsonFields = [
                "learning_objectives",
                "course_content",
                "target_audience",
                "prerequisites",
                "benefits",
                "assessment",
                "certification_details"
            ];

            foreach ($jsonFields as $jsonField) {
                if (array_key_exists($jsonField, $data)) {
                    $data[$jsonField] =
                        $this->decodeIfJson($data[$jsonField]);
                }
            }


            $this->response(
                true,
                "Course details fetched successfully.",
                $data
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to fetch course details.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }


    // =====================================================
    // CREATE COURSE DETAILS
    //
    // POST /api/admin/course-details
    // =====================================================

    public function create()
    {
        try {

            $data =
                $this->getJsonInput();


            $courseItemId =
                isset($data["course_item_id"])
                    ? (int) $data["course_item_id"]
                    : 0;


            if ($courseItemId <= 0) {

                $this->response(
                    false,
                    "course_item_id is required.",
                    null,
                    400
                );
            }


            // Check if course exists

            $checkSql = "
                SELECT id
                FROM course_menu_items
                WHERE id = ?
                LIMIT 1
            ";


            $checkStmt =
                $this->db->prepare(
                    $checkSql
                );


            $checkStmt->bind_param(
                "i",
                $courseItemId
            );


            $checkStmt->execute();


            $checkResult =
                $checkStmt->get_result();


            if ($checkResult->num_rows === 0) {

                $checkStmt->close();

                $this->response(
                    false,
                    "Course menu item does not exist.",
                    null,
                    404
                );
            }


            $checkStmt->close();


            // Check duplicate details

            $duplicateSql = "
                SELECT id
                FROM course_details
                WHERE course_item_id = ?
                LIMIT 1
            ";


            $duplicateStmt =
                $this->db->prepare(
                    $duplicateSql
                );


            $duplicateStmt->bind_param(
                "i",
                $courseItemId
            );


            $duplicateStmt->execute();


            $duplicateResult =
                $duplicateStmt->get_result();


            if ($duplicateResult->num_rows > 0) {

                $existing =
                    $duplicateResult->fetch_assoc();

                $duplicateStmt->close();

                $this->response(
                    false,
                    "Course details already exist for this course.",
                    [
                        "id" =>
                            (int) $existing["id"]
                    ],
                    409
                );
            }


            $duplicateStmt->close();


            $shortDescription =
                $data["short_description"] ?? null;

            $overview =
                $data["overview"] ?? null;

            $courseImage =
                $data["course_image"] ?? null;

            $duration =
                $data["duration"] ?? null;

            $level =
                $data["level"] ?? null;

            $language =
                $data["language"] ?? null;

            $certification =
                $data["certification"] ?? null;

            $learningObjectives =
                $data["learning_objectives"] ?? null;

            $courseContent =
                $data["course_content"] ?? null;

            $targetAudience =
                $data["target_audience"] ?? null;

            $prerequisites =
                $data["prerequisites"] ?? null;

            $benefits =
                $data["benefits"] ?? null;

            $assessment =
                $data["assessment"] ?? null;

            $certificationDetails =
                $data["certification_details"] ?? null;

            $metaTitle =
                $data["meta_title"] ?? null;

            $metaDescription =
                $data["meta_description"] ?? null;

            $status =
                isset($data["status"])
                    ? (int) $data["status"]
                    : 1;

            // Convert any React arrays/objects to JSON strings
            // before sending them to MySQL TEXT/LONGTEXT fields.
            $shortDescription =
                $this->normalizeValue($shortDescription);

            $overview =
                $this->normalizeValue($overview);

            $courseImage =
                $this->normalizeValue($courseImage);

            $duration =
                $this->normalizeValue($duration);

            $level =
                $this->normalizeValue($level);

            $language =
                $this->normalizeValue($language);

            $certification =
                $this->normalizeValue($certification);

            $learningObjectives =
                $this->normalizeValue($learningObjectives);

            $courseContent =
                $this->normalizeValue($courseContent);

            $targetAudience =
                $this->normalizeValue($targetAudience);

            $prerequisites =
                $this->normalizeValue($prerequisites);

            $benefits =
                $this->normalizeValue($benefits);

            $assessment =
                $this->normalizeValue($assessment);

            $certificationDetails =
                $this->normalizeValue($certificationDetails);

            $metaTitle =
                $this->normalizeValue($metaTitle);

            $metaDescription =
                $this->normalizeValue($metaDescription);


            $sql = "
                INSERT INTO course_details (

                    course_item_id,
                    short_description,
                    overview,
                    course_image,
                    duration,
                    level,
                    language,
                    certification,
                    learning_objectives,
                    course_content,
                    target_audience,
                    prerequisites,
                    benefits,
                    assessment,
                    certification_details,
                    meta_title,
                    meta_description,
                    status

                )

                VALUES (

                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?

                )
            ";


            $stmt =
                $this->db->prepare($sql);


            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare insert query.",
                    null,
                    500
                );
            }


            $stmt->bind_param(
                "issssssssssssssssi",
                $courseItemId,
                $shortDescription,
                $overview,
                $courseImage,
                $duration,
                $level,
                $language,
                $certification,
                $learningObjectives,
                $courseContent,
                $targetAudience,
                $prerequisites,
                $benefits,
                $assessment,
                $certificationDetails,
                $metaTitle,
                $metaDescription,
                $status
            );


            if (!$stmt->execute()) {

                $error =
                    $stmt->error;

                $stmt->close();

                $this->response(
                    false,
                    "Failed to create course details.",
                    [
                        "error" => $error
                    ],
                    500
                );
            }


            $newId =
                $stmt->insert_id;


            $stmt->close();


            $this->response(
                true,
                "Course details created successfully.",
                [
                    "id" => $newId
                ],
                201
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to create course details.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }


    // =====================================================
    // UPDATE COURSE DETAILS
    //
    // PUT /api/admin/course-details/1
    // =====================================================

    public function update($id = null)
    {
        try {

            if ($id === null) {

                $id =
                    isset($_GET["id"])
                        ? (int) $_GET["id"]
                        : 0;
            }


            $id = (int) $id;


            if ($id <= 0) {

                $this->response(
                    false,
                    "Valid course details ID is required.",
                    null,
                    400
                );
            }


            $data =
                $this->getJsonInput();


            $fields = [

                "course_item_id",
                "short_description",
                "overview",
                "course_image",
                "duration",
                "level",
                "language",
                "certification",
                "learning_objectives",
                "course_content",
                "target_audience",
                "prerequisites",
                "benefits",
                "assessment",
                "certification_details",
                "meta_title",
                "meta_description",
                "status"

            ];


            $setParts = [];

            $values = [];

            $types = "";


            foreach ($fields as $field) {

                if (array_key_exists($field, $data)) {

                    $setParts[] =
                        "`$field` = ?";


                    $value =
                        $data[$field];


                    if (
                        $field === "course_item_id" ||
                        $field === "status"
                    ) {

                        $values[] =
                            (int) $value;

                        $types .= "i";

                    } else {

                        $values[] =
                            $this->normalizeValue($value);

                        $types .= "s";
                    }
                }
            }


            if (empty($setParts)) {

                $this->response(
                    false,
                    "No fields provided for update.",
                    null,
                    400
                );
            }


            $types .= "i";

            $values[] = $id;


            $sql = "
                UPDATE course_details
                SET
                    " .
                implode(
                    ", ",
                    $setParts
                ) .
                "
                WHERE id = ?
            ";


            $stmt =
                $this->db->prepare($sql);


            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare update query.",
                    null,
                    500
                );
            }


            $stmt->bind_param(
                $types,
                ...$values
            );


            if (!$stmt->execute()) {

                $error =
                    $stmt->error;

                $stmt->close();

                $this->response(
                    false,
                    "Failed to update course details.",
                    [
                        "error" => $error
                    ],
                    500
                );
            }


            $stmt->close();


            $this->response(
                true,
                "Course details updated successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to update course details.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }


    // =====================================================
    // DELETE COURSE DETAILS
    //
    // DELETE /api/admin/course-details/1
    // =====================================================

    public function delete($id = null)
    {
        try {

            if ($id === null) {

                $id =
                    isset($_GET["id"])
                        ? (int) $_GET["id"]
                        : 0;
            }


            $id = (int) $id;


            if ($id <= 0) {

                $this->response(
                    false,
                    "Valid course details ID is required.",
                    null,
                    400
                );
            }


            $sql = "
                DELETE FROM course_details
                WHERE id = ?
            ";


            $stmt =
                $this->db->prepare($sql);


            if (!$stmt) {

                $this->response(
                    false,
                    "Failed to prepare delete query.",
                    null,
                    500
                );
            }


            $stmt->bind_param(
                "i",
                $id
            );


            if (!$stmt->execute()) {

                $error =
                    $stmt->error;

                $stmt->close();

                $this->response(
                    false,
                    "Failed to delete course details.",
                    [
                        "error" => $error
                    ],
                    500
                );
            }


            if ($stmt->affected_rows === 0) {

                $stmt->close();

                $this->response(
                    false,
                    "Course details not found.",
                    null,
                    404
                );
            }


            $stmt->close();


            $this->response(
                true,
                "Course details deleted successfully.",
                [
                    "id" => $id
                ]
            );

        } catch (Throwable $e) {

            $this->response(
                false,
                "Failed to delete course details.",
                [
                    "error" => $e->getMessage()
                ],
                500
            );
        }
    }
}