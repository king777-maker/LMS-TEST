<?php

require_once __DIR__
    . "/../Models/AdminFreeCertification.php"; 


class AdminFreeCertificationController
{
    private mysqli $db;

    private AdminFreeCertification $model;


    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public function __construct(mysqli $db)
    {
        $this->db = $db;

        $this->model =
            new AdminFreeCertification($db);
    }


    // =====================================================
    // ADMIN AUTH CHECK
    // =====================================================

    private function checkAdmin(): void
    {
        if (
            !isset($_SESSION["admin"])
            ||
            empty($_SESSION["admin"]["id"])
        ) {

            http_response_code(401);

            header(
                "Content-Type: application/json; charset=UTF-8"
            );

            echo json_encode([
                "status" => false,
                "message" => "Unauthorized. Admin login required."
            ]);

            exit;
        }
    }


    // =====================================================
    // GET ALL
    // =====================================================

    public function getAll(): void
    {
        $this->checkAdmin();

        try {

            $data =
                $this->model->getAll();

            http_response_code(200);

            header(
                "Content-Type: application/json; charset=UTF-8"
            );

            echo json_encode([
                "status" => true,

                "message" =>
                    "Free certifications fetched successfully.",

                "data" =>
                    $data
            ]);

        } catch (Throwable $e) {

            http_response_code(500);

            header(
                "Content-Type: application/json; charset=UTF-8"
            );

            echo json_encode([
                "status" => false,

                "message" =>
                    $e->getMessage()
            ]);
        }

        exit;
    }


    // =====================================================
    // GET SINGLE
    // =====================================================

    public function getById(): void
    {
        $this->checkAdmin();

        $id =
            isset($_GET["id"])
                ? (int) $_GET["id"]
                : 0;


        if ($id <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,
                "message" => "Invalid certification ID."
            ]);

            exit;
        }


        try {

            $data =
                $this->model->getById($id);


            if (!$data) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,

                    "message" =>
                        "Certification not found."
                ]);

                exit;
            }


            http_response_code(200);

            echo json_encode([
                "status" => true,

                "message" =>
                    "Certification fetched successfully.",

                "data" =>
                    $data
            ]);

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,

                "message" =>
                    $e->getMessage()
            ]);
        }

        exit;
    }


    // =====================================================
    // CREATE
    // =====================================================

    public function create(): void
    {
        $this->checkAdmin();

        $input =
            json_decode(
                file_get_contents("php://input"),
                true
            );


        if (!is_array($input)) {

            http_response_code(400);

            echo json_encode([
                "status" => false,

                "message" =>
                    "Invalid request data."
            ]);

            exit;
        }


        try {

            $id =
                $this->model->create($input);


            http_response_code(201);

            echo json_encode([
                "status" => true,

                "message" =>
                    "Free certification created successfully.",

                "id" =>
                    $id
            ]);

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,

                "message" =>
                    $e->getMessage()
            ]);
        }

        exit;
    }


    // =====================================================
    // UPDATE
    // =====================================================

    public function update(): void
    {
        $this->checkAdmin();

        $input =
            json_decode(
                file_get_contents("php://input"),
                true
            );


        if (!is_array($input)) {

            http_response_code(400);

            echo json_encode([
                "status" => false,

                "message" =>
                    "Invalid request data."
            ]);

            exit;
        }


        if (
            !isset($input["id"])
            ||
            (int) $input["id"] <= 0
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => false,

                "message" =>
                    "Certification ID is required."
            ]);

            exit;
        }


        try {

            $updated =
                $this->model->update($input);


            if (!$updated) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,

                    "message" =>
                        "Certification not found."
                ]);

                exit;
            }


            http_response_code(200);

            echo json_encode([
                "status" => true,

                "message" =>
                    "Free certification updated successfully."
            ]);

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,

                "message" =>
                    $e->getMessage()
            ]);
        }

        exit;
    }


    // =====================================================
    // DELETE
    // =====================================================

    public function delete(): void
    {
        $this->checkAdmin();

        $input =
            json_decode(
                file_get_contents("php://input"),
                true
            );


        $id =
            isset($input["id"])
                ? (int) $input["id"]
                : 0;


        if ($id <= 0) {

            http_response_code(400);

            echo json_encode([
                "status" => false,

                "message" =>
                    "Certification ID is required."
            ]);

            exit;
        }


        try {

            $deleted =
                $this->model->delete($id);


            if (!$deleted) {

                http_response_code(404);

                echo json_encode([
                    "status" => false,

                    "message" =>
                        "Certification not found."
                ]);

                exit;
            }


            http_response_code(200);

            echo json_encode([
                "status" => true,

                "message" =>
                    "Free certification deleted successfully."
            ]);

        } catch (Throwable $e) {

            http_response_code(500);

            echo json_encode([
                "status" => false,

                "message" =>
                    $e->getMessage()
            ]);
        }

        exit;
    }
}