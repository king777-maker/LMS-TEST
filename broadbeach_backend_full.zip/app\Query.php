<?php

class Query
{
    private mysqli $conn;


    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }


    // ==========================================
    // GET ALL
    // ==========================================

    public function getAll(
        string $table,
        string $orderBy = "id",
        string $order = "ASC"
    ): array {

        $sql = "
            SELECT *
            FROM `$table`
            ORDER BY `$orderBy` $order
        ";

        $result = $this->conn->query($sql);

        $data = [];

        if ($result) {

            while ($row = $result->fetch_assoc()) {

                $data[] = $row;
            }
        }

        return $data;
    }


    // ==========================================
    // GET BY ID
    // ==========================================

    public function getById(
        string $table,
        int $id
    ): ?array {

        $sql = "
            SELECT *
            FROM `$table`
            WHERE `id` = ?
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        $stmt->bind_param(
            "i",
            $id
        );

        $stmt->execute();

        $result = $stmt->get_result();

        $data = $result->fetch_assoc();

        $stmt->close();

        return $data ?: null;
    }


    // ==========================================
    // GET ONE BY COLUMN
    // ==========================================

    public function getOne(
        string $table,
        string $column,
        string $value
    ): ?array {

        $sql = "
            SELECT *
            FROM `$table`
            WHERE `$column` = ?
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        $stmt->bind_param(
            "s",
            $value
        );

        $stmt->execute();

        $result = $stmt->get_result();

        $data = $result->fetch_assoc();

        $stmt->close();

        return $data ?: null;
    }


    // ==========================================
    // GET WHERE
    // ==========================================

    public function getWhere(
        string $table,
        string $column,
        string $value,
        string $orderBy = "id",
        string $order = "ASC"
    ): array {

        $sql = "
            SELECT *
            FROM `$table`
            WHERE `$column` = ?
            ORDER BY `$orderBy` $order
        ";

        $stmt = $this->conn->prepare($sql);

        $stmt->bind_param(
            "s",
            $value
        );

        $stmt->execute();

        $result = $stmt->get_result();

        $data = [];

        while ($row = $result->fetch_assoc()) {

            $data[] = $row;
        }

        $stmt->close();

        return $data;
    }


    // ==========================================
    // CHECK EXISTS
    // ==========================================

    public function exists(
        string $table,
        string $column,
        string $value
    ): bool {

        $sql = "
            SELECT `id`
            FROM `$table`
            WHERE `$column` = ?
            LIMIT 1
        ";

        $stmt = $this->conn->prepare($sql);

        $stmt->bind_param(
            "s",
            $value
        );

        $stmt->execute();

        $result = $stmt->get_result();

        $exists =
            $result->num_rows > 0;

        $stmt->close();

        return $exists;
    }


    // ==========================================
    // INSERT
    // ==========================================

    public function insert(
        string $table,
        array $data
    ): int {

        $columns =
            array_keys($data);

        $values =
            array_values($data);


        $columnNames =
            "`" .
            implode(
                "`, `",
                $columns
            ) .
            "`";


        $placeholders =
            implode(
                ", ",
                array_fill(
                    0,
                    count($values),
                    "?"
                )
            );


        $sql = "
            INSERT INTO `$table`
            ($columnNames)
            VALUES ($placeholders)
        ";


        $stmt =
            $this->conn->prepare($sql);


        $types =
            $this->getTypes($values);


        $stmt->bind_param(
            $types,
            ...$values
        );


        $stmt->execute();


        $insertId =
            $this->conn->insert_id;


        $stmt->close();


        return $insertId;
    }


    // ==========================================
    // UPDATE
    // ==========================================

    public function update(
        string $table,
        int $id,
        array $data
    ): bool {

        $fields = [];

        $values = [];


        foreach ($data as $column => $value) {

            $fields[] =
                "`$column` = ?";

            $values[] =
                $value;
        }


        $fieldString =
            implode(
                ", ",
                $fields
            );


        $values[] = $id;


        $sql = "
            UPDATE `$table`
            SET $fieldString
            WHERE `id` = ?
        ";


        $stmt =
            $this->conn->prepare($sql);


        $types =
            $this->getTypes($values);


        $stmt->bind_param(
            $types,
            ...$values
        );


        $result =
            $stmt->execute();


        $stmt->close();


        return $result;
    }


    // ==========================================
    // DELETE
    // ==========================================

    public function delete(
        string $table,
        int $id
    ): bool {

        $sql = "
            DELETE FROM `$table`
            WHERE `id` = ?
        ";


        $stmt =
            $this->conn->prepare($sql);


        $stmt->bind_param(
            "i",
            $id
        );


        $result =
            $stmt->execute();


        $stmt->close();


        return $result;
    }


    // ==========================================
    // CUSTOM SELECT
    // ==========================================

    public function select(
        string $sql,
        string $types = "",
        array $params = []
    ): array {

        $stmt =
            $this->conn->prepare($sql);


        if (
            !empty($params) &&
            $types !== ""
        ) {

            $stmt->bind_param(
                $types,
                ...$params
            );
        }


        $stmt->execute();


        $result =
            $stmt->get_result();


        $data = [];


        while ($row = $result->fetch_assoc()) {

            $data[] = $row;
        }


        $stmt->close();


        return $data;
    }


    // ==========================================
    // CUSTOM SELECT ONE
    // ==========================================

    public function selectOne(
        string $sql,
        string $types = "",
        array $params = []
    ): ?array {

        $data =
            $this->select(
                $sql,
                $types,
                $params
            );


        return $data[0] ?? null;
    }


    // ==========================================
    // GET BIND TYPES
    // ==========================================

    private function getTypes(
        array $values
    ): string {

        $types = "";


        foreach ($values as $value) {

            if (is_int($value)) {

                $types .= "i";

            } elseif (is_float($value)) {

                $types .= "d";

            } else {

                $types .= "s";
            }
        }


        return $types;
    }
}